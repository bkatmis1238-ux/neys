<?php
/**
 * Proje Yönetimi
 */
require_once dirname(__DIR__) . '/config/bootstrap.php';
require_once __DIR__ . '/includes/helpers.php';

require_admin();

$pageTitle = 'Proje Yönetimi';
$currentAdminPage = 'projects';
$languages = admin_languages($pdo);
$action = get_param('action', 'list');
$id = (int) get_param('id', 0);

if (is_post()) {
    if (!verify_csrf(post_param('csrf_token'))) {
        set_flash('danger', 'Güvenlik doğrulaması başarısız.');
        redirect('projects.php');
    }

    $postAction = post_param('action');

    if ($postAction === 'delete' && $id > 0) {
        $project = db_fetch($pdo, 'SELECT * FROM projects WHERE id = ?', [$id]);
        if ($project) {
            admin_delete_file($project['cover_image']);
            admin_delete_file($project['pdf_brochure']);
            $images = db_fetch_all($pdo, 'SELECT image FROM project_images WHERE project_id = ?', [$id]);
            foreach ($images as $img) {
                admin_delete_file($img['image']);
            }
            db_execute($pdo, 'DELETE FROM projects WHERE id = ?', [$id]);
            admin_log($pdo, 'delete_project', 'Proje silindi: #' . $id);
            set_flash('success', 'Proje başarıyla silindi.');
        }
        redirect('projects.php');
    }

    if ($postAction === 'delete_image') {
        $imageId = (int) post_param('image_id', 0);
        $img = db_fetch($pdo, 'SELECT * FROM project_images WHERE id = ?', [$imageId]);
        if ($img) {
            admin_delete_file($img['image']);
            db_execute($pdo, 'DELETE FROM project_images WHERE id = ?', [$imageId]);
            set_flash('success', 'Galeri görseli silindi.');
        }
        redirect('projects.php?action=edit&id=' . (int) post_param('project_id', 0));
    }

    if ($postAction === 'save') {
        $category = post_param('category', 'ongoing');
        $location = post_param('location', '');
        $mapEmbed = $_POST['map_embed'] ?? '';
        $startDate = post_param('start_date', '') ?: null;
        $endDate = post_param('end_date', '') ?: null;
        $areaSqm = post_param('area_sqm', '') ?: null;
        $videoUrl = post_param('video_url', '');
        $sortOrder = (int) post_param('sort_order', 0);
        $isActive = isset($_POST['is_active']) ? 1 : 0;
        $isFeatured = isset($_POST['is_featured']) ? 1 : 0;
        $showHomepage = isset($_POST['show_homepage']) ? 1 : 0;
        $editId = (int) post_param('id', 0);

        if (!in_array($category, ['ongoing', 'completed'], true)) {
            $category = 'ongoing';
        }

        try {
            $coverPath = null;
            if (!empty($_FILES['cover_image']['name'])) {
                $coverPath = admin_upload_file($_FILES['cover_image'], 'projects', $appConfig['allowed_images'], $appConfig['max_upload']);
            }

            $pdfPath = null;
            if (!empty($_FILES['pdf_brochure']['name'])) {
                $pdfPath = admin_upload_file($_FILES['pdf_brochure'], 'documents', $appConfig['allowed_docs'], $appConfig['max_upload']);
            }

            if ($editId > 0) {
                $existing = db_fetch($pdo, 'SELECT * FROM projects WHERE id = ?', [$editId]);
                if (!$existing) {
                    set_flash('danger', 'Proje bulunamadı.');
                    redirect('projects.php');
                }

                $finalCover = $coverPath ?? $existing['cover_image'];
                $finalPdf = $pdfPath ?? $existing['pdf_brochure'];
                if ($coverPath && $existing['cover_image']) admin_delete_file($existing['cover_image']);
                if ($pdfPath && $existing['pdf_brochure']) admin_delete_file($existing['pdf_brochure']);

                db_execute($pdo,
                    'UPDATE projects SET cover_image = ?, category = ?, location = ?, map_embed = ?,
                     start_date = ?, end_date = ?, area_sqm = ?, video_url = ?, pdf_brochure = ?,
                     sort_order = ?, is_active = ?, is_featured = ?, show_homepage = ? WHERE id = ?',
                    [$finalCover, $category, $location, $mapEmbed, $startDate, $endDate, $areaSqm,
                     $videoUrl, $finalPdf, $sortOrder, $isActive, $isFeatured, $showHomepage, $editId]
                );
                $projectId = $editId;
            } else {
                if (!$coverPath) {
                    set_flash('danger', 'Kapak görseli zorunludur.');
                    redirect('projects.php?action=add');
                }
                db_execute($pdo,
                    'INSERT INTO projects (cover_image, category, location, map_embed, start_date, end_date,
                     area_sqm, video_url, pdf_brochure, sort_order, is_active, is_featured, show_homepage)
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
                    [$coverPath, $category, $location, $mapEmbed, $startDate, $endDate, $areaSqm,
                     $videoUrl, $pdfPath, $sortOrder, $isActive, $isFeatured, $showHomepage]
                );
                $projectId = (int) db_last_id($pdo);
            }

            // Galeri yükleme
            if (!empty($_FILES['gallery']['name'][0])) {
                $galleryFiles = $_FILES['gallery'];
                $fileCount = count($galleryFiles['name']);
                $maxSort = db_count($pdo, 'SELECT COALESCE(MAX(sort_order), 0) FROM project_images WHERE project_id = ?', [$projectId]);

                for ($i = 0; $i < $fileCount; $i++) {
                    if ($galleryFiles['error'][$i] !== UPLOAD_ERR_OK) continue;

                    $file = [
                        'name'     => $galleryFiles['name'][$i],
                        'type'     => $galleryFiles['type'][$i],
                        'tmp_name' => $galleryFiles['tmp_name'][$i],
                        'error'    => $galleryFiles['error'][$i],
                        'size'     => $galleryFiles['size'][$i],
                    ];

                    $galleryPath = admin_upload_file($file, 'projects/gallery', $appConfig['allowed_images'], $appConfig['max_upload']);
                    $maxSort++;
                    db_execute($pdo,
                        'INSERT INTO project_images (project_id, image, sort_order) VALUES (?, ?, ?)',
                        [$projectId, $galleryPath, $maxSort]
                    );
                }
            }

            foreach ($languages as $lang) {
                $langId = (int) $lang['id'];
                $title = post_param('title_' . $langId, '');
                $slug = post_param('slug_' . $langId, '') ?: create_slug($title);
                $shortDesc = post_param('short_description_' . $langId, '');
                $description = post_param('description_' . $langId, '');
                $metaTitle = post_param('meta_title_' . $langId, '');
                $metaDesc = post_param('meta_description_' . $langId, '');
                $metaKeywords = post_param('meta_keywords_' . $langId, '');

                $trans = db_fetch($pdo,
                    'SELECT id FROM project_translations WHERE project_id = ? AND language_id = ?',
                    [$projectId, $langId]
                );

                if ($trans) {
                    db_execute($pdo,
                        'UPDATE project_translations SET title = ?, slug = ?, short_description = ?, description = ?,
                         meta_title = ?, meta_description = ?, meta_keywords = ? WHERE id = ?',
                        [$title, $slug, $shortDesc, $description, $metaTitle, $metaDesc, $metaKeywords, $trans['id']]
                    );
                } else {
                    db_execute($pdo,
                        'INSERT INTO project_translations (project_id, language_id, title, slug, short_description,
                         description, meta_title, meta_description, meta_keywords) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
                        [$projectId, $langId, $title, $slug, $shortDesc, $description, $metaTitle, $metaDesc, $metaKeywords]
                    );
                }
            }

            admin_log($pdo, 'save_project', 'Proje kaydedildi: #' . $projectId);
            set_flash('success', 'Proje başarıyla kaydedildi.');
            redirect('projects.php');
        } catch (RuntimeException $e) {
            set_flash('danger', $e->getMessage());
            redirect('projects.php?action=' . ($editId ? 'edit&id=' . $editId : 'add'));
        }
    }
}

$project = null;
$translations = [];
$galleryImages = [];
if ($action === 'edit' && $id > 0) {
    $project = db_fetch($pdo, 'SELECT * FROM projects WHERE id = ?', [$id]);
    if (!$project) {
        set_flash('danger', 'Proje bulunamadı.');
        redirect('projects.php');
    }
    $transRows = db_fetch_all($pdo, 'SELECT * FROM project_translations WHERE project_id = ?', [$id]);
    foreach ($transRows as $row) {
        $translations[$row['language_id']] = $row;
    }
    $galleryImages = db_fetch_all($pdo,
        'SELECT * FROM project_images WHERE project_id = ? ORDER BY sort_order ASC', [$id]
    );
}

$projects = db_fetch_all($pdo,
    'SELECT p.*, pt.title FROM projects p
     LEFT JOIN project_translations pt ON pt.project_id = p.id AND pt.language_id = 1
     ORDER BY p.sort_order ASC, p.id DESC'
);

require __DIR__ . '/includes/header.php';
?>

<?php if ($action === 'add' || $action === 'edit'): ?>
<div class="admin-card">
    <div class="admin-card-header d-flex justify-content-between align-items-center">
        <h2 class="h6 mb-0"><?= $action === 'edit' ? 'Proje Düzenle' : 'Yeni Proje' ?></h2>
        <a href="projects.php" class="btn btn-sm btn-outline-secondary"><i class="bi bi-arrow-left"></i> Geri</a>
    </div>
    <div class="admin-card-body">
        <form method="post" enctype="multipart/form-data">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="save">
            <input type="hidden" name="id" value="<?= (int) ($project['id'] ?? 0) ?>">

            <div class="row g-3 mb-4">
                <div class="col-md-3">
                    <label class="form-label">Kapak Görseli <?= $action === 'add' ? '*' : '' ?></label>
                    <?php if (!empty($project['cover_image'])): ?>
                    <div class="mb-2"><img src="<?= e(asset_url($project['cover_image'])) ?>" class="img-preview" alt=""></div>
                    <?php endif; ?>
                    <input type="file" class="form-control" name="cover_image" accept="image/*" <?= $action === 'add' ? 'required' : '' ?>>
                </div>
                <div class="col-md-3">
                    <label class="form-label">Kategori</label>
                    <select class="form-select" name="category">
                        <option value="ongoing" <?= ($project['category'] ?? '') === 'ongoing' ? 'selected' : '' ?>>Devam Eden</option>
                        <option value="completed" <?= ($project['category'] ?? '') === 'completed' ? 'selected' : '' ?>>Tamamlanan</option>
                    </select>
                </div>
                <div class="col-md-3">
                    <label class="form-label">Lokasyon</label>
                    <input type="text" class="form-control" name="location" value="<?= e($project['location'] ?? '') ?>">
                </div>
                <div class="col-md-3">
                    <label class="form-label">Metrekare</label>
                    <input type="number" step="0.01" class="form-control" name="area_sqm" value="<?= e($project['area_sqm'] ?? '') ?>">
                </div>
                <div class="col-md-3">
                    <label class="form-label">Başlangıç Tarihi</label>
                    <input type="date" class="form-control" name="start_date" value="<?= e($project['start_date'] ?? '') ?>">
                </div>
                <div class="col-md-3">
                    <label class="form-label">Bitiş Tarihi</label>
                    <input type="date" class="form-control" name="end_date" value="<?= e($project['end_date'] ?? '') ?>">
                </div>
                <div class="col-md-3">
                    <label class="form-label">Video URL</label>
                    <input type="url" class="form-control" name="video_url" value="<?= e($project['video_url'] ?? '') ?>">
                </div>
                <div class="col-md-3">
                    <label class="form-label">Sıra</label>
                    <input type="number" class="form-control" name="sort_order" value="<?= (int) ($project['sort_order'] ?? 0) ?>">
                </div>
                <div class="col-md-6">
                    <label class="form-label">PDF Broşür</label>
                    <?php if (!empty($project['pdf_brochure'])): ?>
                    <p class="small text-muted mb-1"><a href="<?= e(asset_url($project['pdf_brochure'])) ?>" target="_blank">Mevcut PDF</a></p>
                    <?php endif; ?>
                    <input type="file" class="form-control" name="pdf_brochure" accept=".pdf">
                </div>
                <div class="col-md-6">
                    <label class="form-label">Harita Embed</label>
                    <textarea class="form-control" name="map_embed" rows="2"><?= e($project['map_embed'] ?? '') ?></textarea>
                </div>
                <div class="col-12">
                    <div class="d-flex gap-4">
                        <div class="form-check form-switch">
                            <input class="form-check-input" type="checkbox" name="is_active" id="is_active" <?= ($project['is_active'] ?? 1) ? 'checked' : '' ?>>
                            <label class="form-check-label" for="is_active">Aktif</label>
                        </div>
                        <div class="form-check form-switch">
                            <input class="form-check-input" type="checkbox" name="is_featured" id="is_featured" <?= ($project['is_featured'] ?? 0) ? 'checked' : '' ?>>
                            <label class="form-check-label" for="is_featured">Öne Çıkan</label>
                        </div>
                        <div class="form-check form-switch">
                            <input class="form-check-input" type="checkbox" name="show_homepage" id="show_homepage" <?= ($project['show_homepage'] ?? 0) ? 'checked' : '' ?>>
                            <label class="form-check-label" for="show_homepage">Ana Sayfada Göster</label>
                        </div>
                    </div>
                </div>
            </div>

            <ul class="nav nav-tabs lang-tabs mb-3" role="tablist">
                <?php foreach ($languages as $i => $lang): ?>
                <li class="nav-item">
                    <button class="nav-link <?= $i === 0 ? 'active' : '' ?>" data-bs-toggle="tab" data-bs-target="#lang-<?= $lang['id'] ?>" type="button">
                        <?= e($lang['flag']) ?> <?= e($lang['native_name']) ?>
                    </button>
                </li>
                <?php endforeach; ?>
            </ul>

            <div class="tab-content mb-4">
                <?php foreach ($languages as $i => $lang): ?>
                <?php $t = $translations[$lang['id']] ?? []; ?>
                <div class="tab-pane fade <?= $i === 0 ? 'show active' : '' ?>" id="lang-<?= $lang['id'] ?>">
                    <div class="row g-3">
                        <div class="col-md-8">
                            <label class="form-label">Başlık *</label>
                            <input type="text" class="form-control" name="title_<?= $lang['id'] ?>" value="<?= e($t['title'] ?? '') ?>" required>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Slug</label>
                            <input type="text" class="form-control" name="slug_<?= $lang['id'] ?>" value="<?= e($t['slug'] ?? '') ?>">
                        </div>
                        <div class="col-12">
                            <label class="form-label">Kısa Açıklama</label>
                            <textarea class="form-control" name="short_description_<?= $lang['id'] ?>" rows="2"><?= e($t['short_description'] ?? '') ?></textarea>
                        </div>
                        <div class="col-12">
                            <label class="form-label">Detaylı Açıklama</label>
                            <textarea class="form-control" name="description_<?= $lang['id'] ?>" rows="5"><?= e($t['description'] ?? '') ?></textarea>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Meta Başlık</label>
                            <input type="text" class="form-control" name="meta_title_<?= $lang['id'] ?>" value="<?= e($t['meta_title'] ?? '') ?>">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Meta Açıklama</label>
                            <input type="text" class="form-control" name="meta_description_<?= $lang['id'] ?>" value="<?= e($t['meta_description'] ?? '') ?>">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Meta Anahtar Kelimeler</label>
                            <input type="text" class="form-control" name="meta_keywords_<?= $lang['id'] ?>" value="<?= e($t['meta_keywords'] ?? '') ?>">
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>

            <div class="mb-4">
                <label class="form-label">Galeri Görselleri</label>
                <?php if (!empty($galleryImages)): ?>
                <div class="gallery-grid mb-3">
                    <?php foreach ($galleryImages as $img): ?>
                    <div class="gallery-item">
                        <img src="<?= e(asset_url($img['image'])) ?>" alt="">
                        <form method="post" class="gallery-remove">
                            <?= csrf_field() ?>
                            <input type="hidden" name="action" value="delete_image">
                            <input type="hidden" name="image_id" value="<?= $img['id'] ?>">
                            <input type="hidden" name="project_id" value="<?= $project['id'] ?>">
                            <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Görsel silinsin mi?')"><i class="bi bi-x"></i></button>
                        </form>
                    </div>
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>
                <input type="file" class="form-control" name="gallery[]" accept="image/*" multiple>
                <small class="text-muted">Birden fazla görsel seçebilirsiniz.</small>
            </div>

            <button type="submit" class="btn btn-primary"><i class="bi bi-check-lg"></i> Kaydet</button>
        </form>
    </div>
</div>

<?php else: ?>
<div class="admin-card">
    <div class="admin-card-header d-flex justify-content-between align-items-center">
        <h2 class="h6 mb-0">Proje Listesi</h2>
        <a href="projects.php?action=add" class="btn btn-sm btn-primary"><i class="bi bi-plus-lg"></i> Yeni Proje</a>
    </div>
    <div class="admin-card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover mb-0">
                <thead>
                    <tr>
                        <th>Görsel</th>
                        <th>Başlık</th>
                        <th>Kategori</th>
                        <th>Lokasyon</th>
                        <th>Durum</th>
                        <th width="120">İşlemler</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($projects as $p): ?>
                    <tr>
                        <td><img src="<?= e(asset_url($p['cover_image'])) ?>" class="img-preview-sm" alt=""></td>
                        <td><?= e($p['title'] ?? '-') ?></td>
                        <td><?= $p['category'] === 'ongoing' ? '<span class="badge bg-warning text-dark">Devam Eden</span>' : '<span class="badge bg-success">Tamamlanan</span>' ?></td>
                        <td><?= e($p['location'] ?? '-') ?></td>
                        <td><?= $p['is_active'] ? '<span class="badge bg-success">Aktif</span>' : '<span class="badge bg-secondary">Pasif</span>' ?></td>
                        <td>
                            <a href="projects.php?action=edit&id=<?= $p['id'] ?>" class="btn btn-sm btn-outline-primary btn-action"><i class="bi bi-pencil"></i></a>
                            <form method="post" action="projects.php?action=delete&id=<?= $p['id'] ?>" class="d-inline" onsubmit="return confirm('Bu proje silinsin mi?')">
                                <?= csrf_field() ?>
                                <input type="hidden" name="action" value="delete">
                                <button type="submit" class="btn btn-sm btn-outline-danger btn-action"><i class="bi bi-trash"></i></button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php endif; ?>

<?php require __DIR__ . '/includes/footer.php'; ?>
