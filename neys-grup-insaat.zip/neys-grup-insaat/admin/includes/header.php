<?php
/**
 * Admin panel header
 */
$adminUser = admin_user($pdo);
$pageTitle = $pageTitle ?? 'Yönetim Paneli';
$flash = get_flash();
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="robots" content="noindex, nofollow">
    <title><?= e(admin_page_title($pageTitle)) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <link href="assets/css/admin.css" rel="stylesheet">
</head>
<body class="admin-body">
<div class="admin-wrapper">
    <?php require __DIR__ . '/sidebar.php'; ?>
    <div class="admin-main">
        <header class="admin-topbar">
            <button class="btn btn-link sidebar-toggle d-lg-none" type="button" id="sidebarToggle" aria-label="Menü">
                <i class="bi bi-list fs-4"></i>
            </button>
            <div class="admin-topbar-title d-none d-sm-block">
                <h1 class="h5 mb-0"><?= e($pageTitle) ?></h1>
            </div>
            <div class="admin-topbar-actions ms-auto d-flex align-items-center gap-3">
                <a href="<?= e(rtrim($appConfig['url'], '/')) ?>" target="_blank" class="btn btn-sm btn-outline-secondary">
                    <i class="bi bi-box-arrow-up-right"></i> Siteyi Gör
                </a>
                <div class="dropdown">
                    <button class="btn btn-sm btn-light dropdown-toggle admin-user-btn" type="button" data-bs-toggle="dropdown">
                        <i class="bi bi-person-circle"></i>
                        <?= e($adminUser['full_name'] ?? 'Admin') ?>
                    </button>
                    <ul class="dropdown-menu dropdown-menu-end">
                        <li><span class="dropdown-item-text text-muted small"><?= e($adminUser['email'] ?? '') ?></span></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item" href="logout.php"><i class="bi bi-box-arrow-right"></i> Çıkış Yap</a></li>
                    </ul>
                </div>
            </div>
        </header>
        <main class="admin-content">
            <?php if ($flash): ?>
            <div class="alert alert-<?= e($flash['type']) ?> alert-dismissible fade show" role="alert">
                <?= e($flash['message']) ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
            <?php endif; ?>
