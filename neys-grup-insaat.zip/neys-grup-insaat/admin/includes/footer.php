        </main>
        <footer class="admin-footer">
            <p class="mb-0 text-muted small">&copy; <?= date('Y') ?> Neys Grup İnşaat — Yönetim Paneli</p>
        </footer>
    </div>
</div>
<div class="sidebar-overlay" id="sidebarOverlay"></div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="assets/js/admin.js"></script>
</body>
</html>
