<?php
/**
 * Admin panel yardımcı fonksiyonları
 */

declare(strict_types=1);

/**
 * Aktif dilleri getir
 */
function admin_languages(PDO $pdo): array
{
    return db_fetch_all($pdo,
        'SELECT * FROM languages WHERE is_active = 1 ORDER BY sort_order ASC, id ASC'
    );
}

/**
 * Süper admin kontrolü
 */
function is_super_admin(): bool
{
    return is_admin_logged_in() && ($_SESSION['admin_role'] ?? '') === 'super_admin';
}

/**
 * Süper admin zorunluluğu
 */
function require_super_admin(): void
{
    require_admin();
    if (!is_super_admin()) {
        set_flash('danger', 'Bu sayfaya erişim yetkiniz yok.');
        redirect('index.php');
    }
}

/**
 * Admin kullanıcı bilgisi
 */
function admin_user(PDO $pdo): ?array
{
    if (!is_admin_logged_in()) {
        return null;
    }
    return db_fetch($pdo, 'SELECT * FROM admins WHERE id = ? AND is_active = 1', [$_SESSION['admin_id']]);
}

/**
 * Dosya yükle ve yol döndür
 */
function admin_upload_file(array $file, string $subdir, array $allowed, int $maxSize): ?string
{
    global $appConfig;

    if ($file['error'] === UPLOAD_ERR_NO_FILE) {
        return null;
    }

    $errors = validate_upload($file, $allowed, $maxSize);
    if (!empty($errors)) {
        throw new RuntimeException(implode(' ', $errors));
    }

    $uploadDir = UPLOAD_PATH . '/' . trim($subdir, '/');
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0755, true);
    }

    $filename = safe_filename($file['name']);
    $destPath = $uploadDir . '/' . $filename;

    if (!move_uploaded_file($file['tmp_name'], $destPath)) {
        throw new RuntimeException('Dosya kaydedilemedi.');
    }

    return 'assets/uploads/' . trim($subdir, '/') . '/' . $filename;
}

/**
 * Eski dosyayı sil
 */
function admin_delete_file(?string $path): void
{
    if (!$path || !str_starts_with($path, 'assets/uploads/')) {
        return;
    }
    $fullPath = ROOT_PATH . '/' . $path;
    if (is_file($fullPath)) {
        unlink($fullPath);
    }
}

/**
 * Çeviri kaydet (upsert)
 */
function admin_save_translation(PDO $pdo, int $keyId, int $langId, string $value): void
{
    $existing = db_fetch($pdo,
        'SELECT id FROM translations WHERE key_id = ? AND language_id = ?',
        [$keyId, $langId]
    );

    if ($existing) {
        db_execute($pdo,
            'UPDATE translations SET value = ? WHERE id = ?',
            [$value, $existing['id']]
        );
    } else {
        db_execute($pdo,
            'INSERT INTO translations (key_id, language_id, value) VALUES (?, ?, ?)',
            [$keyId, $langId, $value]
        );
    }
}

/**
 * Sayfa başlığı ve aktif menü
 */
function admin_page_title(string $title): string
{
    return $title . ' | Neys Grup Admin';
}
