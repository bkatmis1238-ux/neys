<?php
/**
 * Admin sidebar navigasyon
 */
$currentAdminPage = $currentAdminPage ?? basename($_SERVER['PHP_SELF'], '.php');
$unreadMessages = db_count($pdo, 'SELECT COUNT(*) FROM messages WHERE is_read = 0');

$menuItems = [
    ['page' => 'index', 'icon' => 'bi-speedometer2', 'label' => 'Dashboard', 'file' => 'index.php'],
    ['page' => 'sliders', 'icon' => 'bi-images', 'label' => 'Slider', 'file' => 'sliders.php'],
    ['page' => 'services', 'icon' => 'bi-briefcase', 'label' => 'Hizmetler', 'file' => 'services.php'],
    ['page' => 'projects', 'icon' => 'bi-building', 'label' => 'Projeler', 'file' => 'projects.php'],
    ['page' => 'about', 'icon' => 'bi-info-circle', 'label' => 'Hakkımızda', 'file' => 'about.php'],
    ['page' => 'gallery', 'icon' => 'bi-collection', 'label' => 'Galeri', 'file' => 'gallery.php'],
    ['page' => 'statistics', 'icon' => 'bi-bar-chart', 'label' => 'İstatistikler', 'file' => 'statistics.php'],
    ['page' => 'messages', 'icon' => 'bi-envelope', 'label' => 'Mesajlar', 'file' => 'messages.php', 'badge' => $unreadMessages],
    ['page' => 'pages', 'icon' => 'bi-file-text', 'label' => 'Yasal Sayfalar', 'file' => 'pages.php'],
    ['page' => 'seo', 'icon' => 'bi-search', 'label' => 'SEO', 'file' => 'seo.php'],
    ['page' => 'translations', 'icon' => 'bi-translate', 'label' => 'Çeviriler', 'file' => 'translations.php'],
    ['page' => 'languages', 'icon' => 'bi-globe', 'label' => 'Diller', 'file' => 'languages.php'],
    ['page' => 'settings', 'icon' => 'bi-gear', 'label' => 'Site Ayarları', 'file' => 'settings.php'],
];

if (is_super_admin()) {
    $menuItems[] = ['page' => 'admins', 'icon' => 'bi-shield-lock', 'label' => 'Yöneticiler', 'file' => 'admins.php'];
}
?>
<aside class="admin-sidebar" id="adminSidebar">
    <div class="sidebar-brand">
        <a href="index.php">
            <i class="bi bi-building-fill-gear"></i>
            <span>Neys Grup</span>
        </a>
    </div>
    <nav class="sidebar-nav">
        <ul class="nav flex-column">
            <?php foreach ($menuItems as $item): ?>
            <li class="nav-item">
                <a class="nav-link <?= $currentAdminPage === $item['page'] ? 'active' : '' ?>" href="<?= e($item['file']) ?>">
                    <i class="bi <?= e($item['icon']) ?>"></i>
                    <span><?= e($item['label']) ?></span>
                    <?php if (!empty($item['badge']) && $item['badge'] > 0): ?>
                    <span class="badge bg-danger ms-auto"><?= (int) $item['badge'] ?></span>
                    <?php endif; ?>
                </a>
            </li>
            <?php endforeach; ?>
        </ul>
    </nav>
    <div class="sidebar-footer">
        <a href="logout.php" class="nav-link text-danger">
            <i class="bi bi-box-arrow-right"></i>
            <span>Çıkış Yap</span>
        </a>
    </div>
</aside>
