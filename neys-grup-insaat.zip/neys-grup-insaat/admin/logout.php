<?php
/**
 * Admin Çıkış
 */
require_once dirname(__DIR__) . '/config/bootstrap.php';

if (is_admin_logged_in()) {
    admin_log($pdo, 'logout', 'Admin çıkışı: ' . ($_SESSION['admin_username'] ?? ''));
}

$_SESSION['admin_id'] = null;
$_SESSION['admin_logged_in'] = false;
unset($_SESSION['admin_username'], $_SESSION['admin_role'], $_SESSION['admin_name']);

session_regenerate_id(true);

header('Location: login.php');
exit;
