<?php
/**
 * Admin Dashboard
 */
require_once dirname(__DIR__) . '/config/bootstrap.php';
require_once __DIR__ . '/includes/helpers.php';

require_admin();

$pageTitle = 'Dashboard';
$currentAdminPage = 'index';

$stats = [
    'projects'   => db_count($pdo, 'SELECT COUNT(*) FROM projects'),
    'services'   => db_count($pdo, 'SELECT COUNT(*) FROM services'),
    'sliders'    => db_count($pdo, 'SELECT COUNT(*) FROM sliders'),
    'messages'   => db_count($pdo, 'SELECT COUNT(*) FROM messages'),
    'unread'     => db_count($pdo, 'SELECT COUNT(*) FROM messages WHERE is_read = 0'),
    'ongoing'    => db_count($pdo, "SELECT COUNT(*) FROM projects WHERE category = 'ongoing'"),
    'completed'  => db_count($pdo, "SELECT COUNT(*) FROM projects WHERE category = 'completed'"),
];

$recentMessages = db_fetch_all($pdo,
    'SELECT * FROM messages ORDER BY created_at DESC LIMIT 5'
);

$recentProjects = db_fetch_all($pdo,
    'SELECT p.*, pt.title FROM projects p
     LEFT JOIN project_translations pt ON pt.project_id = p.id AND pt.language_id = 1
     ORDER BY p.created_at DESC LIMIT 5'
);

require __DIR__ . '/includes/header.php';
?>

<div class="row g-4 mb-4">
    <div class="col-sm-6 col-xl-3">
        <div class="stat-card stat-primary">
            <div class="stat-icon"><i class="bi bi-building"></i></div>
            <div class="stat-info">
                <span class="stat-value"><?= $stats['projects'] ?></span>
                <span class="stat-label">Toplam Proje</span>
            </div>
        </div>
    </div>
    <div class="col-sm-6 col-xl-3">
        <div class="stat-card stat-success">
            <div class="stat-icon"><i class="bi bi-envelope"></i></div>
            <div class="stat-info">
                <span class="stat-value"><?= $stats['messages'] ?></span>
                <span class="stat-label">Toplam Mesaj</span>
            </div>
        </div>
    </div>
    <div class="col-sm-6 col-xl-3">
        <div class="stat-card stat-warning">
            <div class="stat-icon"><i class="bi bi-envelope-exclamation"></i></div>
            <div class="stat-info">
                <span class="stat-value"><?= $stats['unread'] ?></span>
                <span class="stat-label">Okunmamış Mesaj</span>
            </div>
        </div>
    </div>
    <div class="col-sm-6 col-xl-3">
        <div class="stat-card stat-info">
            <div class="stat-icon"><i class="bi bi-images"></i></div>
            <div class="stat-info">
                <span class="stat-value"><?= $stats['sliders'] ?></span>
                <span class="stat-label">Slider</span>
            </div>
        </div>
    </div>
</div>

<div class="row g-4 mb-4">
    <div class="col-md-4">
        <div class="admin-card">
            <div class="admin-card-header">
                <h2 class="h6 mb-0">Proje Durumu</h2>
            </div>
            <div class="admin-card-body">
                <div class="d-flex justify-content-between mb-2">
                    <span>Devam Eden</span>
                    <strong><?= $stats['ongoing'] ?></strong>
                </div>
                <div class="d-flex justify-content-between mb-2">
                    <span>Tamamlanan</span>
                    <strong><?= $stats['completed'] ?></strong>
                </div>
                <div class="d-flex justify-content-between">
                    <span>Hizmetler</span>
                    <strong><?= $stats['services'] ?></strong>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-8">
        <div class="admin-card">
            <div class="admin-card-header d-flex justify-content-between align-items-center">
                <h2 class="h6 mb-0">Son Mesajlar</h2>
                <a href="messages.php" class="btn btn-sm btn-outline-primary">Tümünü Gör</a>
            </div>
            <div class="admin-card-body p-0">
                <?php if (empty($recentMessages)): ?>
                <p class="text-muted p-3 mb-0">Henüz mesaj yok.</p>
                <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-hover mb-0">
                        <thead>
                            <tr>
                                <th>Ad</th>
                                <th>Konu</th>
                                <th>Tarih</th>
                                <th>Durum</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($recentMessages as $msg): ?>
                            <tr>
                                <td><?= e($msg['name']) ?></td>
                                <td><?= e(truncate($msg['subject'] ?? '-', 40)) ?></td>
                                <td><?= format_date($msg['created_at'], 'd.m.Y H:i') ?></td>
                                <td>
                                    <?php if ($msg['is_read']): ?>
                                    <span class="badge bg-secondary">Okundu</span>
                                    <?php else: ?>
                                    <span class="badge bg-primary">Yeni</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<div class="admin-card">
    <div class="admin-card-header d-flex justify-content-between align-items-center">
        <h2 class="h6 mb-0">Son Projeler</h2>
        <a href="projects.php" class="btn btn-sm btn-outline-primary">Tümünü Gör</a>
    </div>
    <div class="admin-card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover mb-0">
                <thead>
                    <tr>
                        <th>Proje</th>
                        <th>Kategori</th>
                        <th>Lokasyon</th>
                        <th>Durum</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($recentProjects as $proj): ?>
                    <tr>
                        <td><?= e($proj['title'] ?? 'Proje #' . $proj['id']) ?></td>
                        <td>
                            <?php if ($proj['category'] === 'ongoing'): ?>
                            <span class="badge bg-warning text-dark">Devam Eden</span>
                            <?php else: ?>
                            <span class="badge bg-success">Tamamlandı</span>
                            <?php endif; ?>
                        </td>
                        <td><?= e($proj['location'] ?? '-') ?></td>
                        <td>
                            <?php if ($proj['is_active']): ?>
                            <span class="badge bg-success">Aktif</span>
                            <?php else: ?>
                            <span class="badge bg-secondary">Pasif</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php require __DIR__ . '/includes/footer.php'; ?>
