<?php
/**
 * Galeri Yönetimi
 */
require_once dirname(__DIR__) . '/config/bootstrap.php';
require_once __DIR__ . '/includes/helpers.php';
require_admin();

$pageTitle = 'Galeri Yönetimi';
$languages = get_active_languages($pdo);

// Silme
if (is_post() && post_param('action') === 'delete') {
    if (verify_csrf(post_param('csrf_token'))) {
        $id = (int) post_param('id');
        $item = db_fetch($pdo, 'SELECT image FROM gallery WHERE id = ?', [$id]);
        if ($item) {
            $filePath = ROOT_PATH . '/' . $item['image'];
            if (file_exists($filePath)) @unlink($filePath);
            db_execute($pdo, 'DELETE FROM gallery WHERE id = ?', [$id]);
            admin_log($pdo, 'gallery_delete', 'Galeri silindi ID: ' . $id);
            set_flash('success', 'Galeri öğesi silindi.');
        }
    }
    redirect('gallery.php');
}

// Ekleme
if (is_post() && post_param('action') === 'add') {
    if (verify_csrf(post_param('csrf_token')) && !empty($_FILES['image']['name'])) {
        $errors = validate_upload($_FILES['image'], $appConfig['allowed_images'], $appConfig['max_upload']);
        if (empty($errors)) {
            $filename = safe_filename($_FILES['image']['name']);
            $dest = UPLOAD_PATH . '/gallery/' . $filename;
            if (!is_dir(dirname($dest))) mkdir(dirname($dest), 0755, true);
            if (move_uploaded_file($_FILES['image']['tmp_name'], $dest)) {
                $imagePath = 'assets/uploads/gallery/' . $filename;
                db_execute($pdo, 'INSERT INTO gallery (image, sort_order) VALUES (?, ?)', [$imagePath, (int) post_param('sort_order', 0)]);
                $galleryId = (int) db_last_id($pdo);
                foreach ($languages as $lang) {
                    $title = post_param('title_' . $lang['code'], '');
                    $desc  = post_param('description_' . $lang['code'], '');
                    db_execute($pdo,
                        'INSERT INTO gallery_translations (gallery_id, language_id, title, description) VALUES (?, ?, ?, ?)',
                        [$galleryId, $lang['id'], $title, $desc]
                    );
                }
                admin_log($pdo, 'gallery_add', 'Galeri eklendi');
                set_flash('success', 'Galeri öğesi eklendi.');
            }
        } else {
            set_flash('error', implode(' ', $errors));
        }
    }
    redirect('gallery.php');
}

$items = db_fetch_all($pdo,
    'SELECT g.*, gt.title
     FROM gallery g
     LEFT JOIN gallery_translations gt ON g.id = gt.gallery_id AND gt.language_id = 1
     ORDER BY g.sort_order ASC, g.id DESC'
);

require __DIR__ . '/includes/header.php';
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h1 class="h3 mb-0">Galeri Yönetimi</h1>
</div>

<?php $flash = get_flash(); if ($flash): ?>
<div class="alert alert-<?= $flash['type'] === 'success' ? 'success' : 'danger' ?>"><?= e($flash['message']) ?></div>
<?php endif; ?>

<div class="row g-4">
    <div class="col-lg-4">
        <div class="card">
            <div class="card-header">Yeni Fotoğraf Ekle</div>
            <div class="card-body">
                <form method="post" enctype="multipart/form-data">
                    <?= csrf_field() ?>
                    <input type="hidden" name="action" value="add">
                    <div class="mb-3">
                        <label class="form-label">Fotoğraf *</label>
                        <input type="file" name="image" class="form-control" accept="image/*" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Sıra</label>
                        <input type="number" name="sort_order" class="form-control" value="0">
                    </div>
                    <?php foreach ($languages as $lang): ?>
                    <div class="mb-2">
                        <label class="form-label"><?= e($lang['native_name']) ?> Başlık</label>
                        <input type="text" name="title_<?= e($lang['code']) ?>" class="form-control">
                    </div>
                    <?php endforeach; ?>
                    <button type="submit" class="btn btn-primary w-100">Ekle</button>
                </form>
            </div>
        </div>
    </div>
    <div class="col-lg-8">
        <div class="card">
            <div class="card-header">Galeri (<?= count($items) ?>)</div>
            <div class="card-body">
                <div class="row g-3">
                    <?php foreach ($items as $item): ?>
                    <div class="col-md-4">
                        <div class="gallery-admin-item">
                            <img src="<?= asset_url($item['image']) ?>" alt="" class="img-fluid rounded">
                            <p class="small mt-1 mb-2"><?= e($item['title'] ?? 'Başlıksız') ?></p>
                            <form method="post" onsubmit="return confirm('Silmek istediğinize emin misiniz?')">
                                <?= csrf_field() ?>
                                <input type="hidden" name="action" value="delete">
                                <input type="hidden" name="id" value="<?= $item['id'] ?>">
                                <button type="submit" class="btn btn-sm btn-danger w-100">Sil</button>
                            </form>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require __DIR__ . '/includes/footer.php'; ?>
