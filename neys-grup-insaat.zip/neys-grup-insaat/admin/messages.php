<?php
/**
 * İletişim Mesajları
 */
require_once dirname(__DIR__) . '/config/bootstrap.php';
require_once __DIR__ . '/includes/helpers.php';

require_admin();

$pageTitle = 'Mesajlar';
$currentAdminPage = 'messages';
$action = get_param('action', 'list');
$id = (int) get_param('id', 0);
$filter = get_param('filter', 'all');

if (is_post()) {
    if (!verify_csrf(post_param('csrf_token'))) {
        set_flash('danger', 'Güvenlik doğrulaması başarısız.');
        redirect('messages.php');
    }

    $postAction = post_param('action');
    $msgId = (int) post_param('id', $id);

    if ($postAction === 'mark_read' && $msgId > 0) {
        db_execute($pdo, 'UPDATE messages SET is_read = 1 WHERE id = ?', [$msgId]);
        set_flash('success', 'Mesaj okundu olarak işaretlendi.');
        redirect('messages.php?action=view&id=' . $msgId);
    }

    if ($postAction === 'mark_unread' && $msgId > 0) {
        db_execute($pdo, 'UPDATE messages SET is_read = 0 WHERE id = ?', [$msgId]);
        set_flash('success', 'Mesaj okunmadı olarak işaretlendi.');
        redirect('messages.php?action=view&id=' . $msgId);
    }

    if ($postAction === 'delete' && $msgId > 0) {
        db_execute($pdo, 'DELETE FROM messages WHERE id = ?', [$msgId]);
        admin_log($pdo, 'delete_message', 'Mesaj silindi: #' . $msgId);
        set_flash('success', 'Mesaj silindi.');
        redirect('messages.php');
    }

    if ($postAction === 'mark_all_read') {
        db_execute($pdo, 'UPDATE messages SET is_read = 1 WHERE is_read = 0');
        set_flash('success', 'Tüm mesajlar okundu olarak işaretlendi.');
        redirect('messages.php');
    }
}

$message = null;
if ($action === 'view' && $id > 0) {
    $message = db_fetch($pdo, 'SELECT * FROM messages WHERE id = ?', [$id]);
    if (!$message) {
        set_flash('danger', 'Mesaj bulunamadı.');
        redirect('messages.php');
    }
    if (!$message['is_read']) {
        db_execute($pdo, 'UPDATE messages SET is_read = 1 WHERE id = ?', [$id]);
        $message['is_read'] = 1;
    }
}

$where = '1=1';
$params = [];
if ($filter === 'unread') {
    $where = 'is_read = 0';
} elseif ($filter === 'read') {
    $where = 'is_read = 1';
}

$messages = db_fetch_all($pdo,
    "SELECT * FROM messages WHERE {$where} ORDER BY created_at DESC",
    $params
);

$unreadCount = db_count($pdo, 'SELECT COUNT(*) FROM messages WHERE is_read = 0');

require __DIR__ . '/includes/header.php';
?>

<?php if ($action === 'view' && $message): ?>
<div class="admin-card">
    <div class="admin-card-header d-flex justify-content-between align-items-center">
        <h2 class="h6 mb-0">Mesaj Detayı</h2>
        <a href="messages.php" class="btn btn-sm btn-outline-secondary"><i class="bi bi-arrow-left"></i> Geri</a>
    </div>
    <div class="admin-card-body">
        <div class="row g-3 mb-4">
            <div class="col-md-6">
                <strong>Gönderen:</strong> <?= e($message['name']) ?>
            </div>
            <div class="col-md-6">
                <strong>E-posta:</strong> <a href="mailto:<?= e($message['email']) ?>"><?= e($message['email']) ?></a>
            </div>
            <div class="col-md-6">
                <strong>Telefon:</strong> <?= e($message['phone'] ?? '-') ?>
            </div>
            <div class="col-md-6">
                <strong>Tarih:</strong> <?= format_date($message['created_at'], 'd.m.Y H:i') ?>
            </div>
            <div class="col-md-6">
                <strong>Konu:</strong> <?= e($message['subject'] ?? '-') ?>
            </div>
            <div class="col-md-6">
                <strong>IP:</strong> <?= e($message['ip_address'] ?? '-') ?>
            </div>
        </div>
        <div class="border rounded p-3 bg-light mb-4">
            <?= nl2br(e($message['message'])) ?>
        </div>
        <div class="d-flex gap-2">
            <?php if ($message['is_read']): ?>
            <form method="post">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="mark_unread">
                <input type="hidden" name="id" value="<?= $message['id'] ?>">
                <button type="submit" class="btn btn-outline-secondary btn-sm"><i class="bi bi-envelope"></i> Okunmadı İşaretle</button>
            </form>
            <?php else: ?>
            <form method="post">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="mark_read">
                <input type="hidden" name="id" value="<?= $message['id'] ?>">
                <button type="submit" class="btn btn-outline-primary btn-sm"><i class="bi bi-envelope-open"></i> Okundu İşaretle</button>
            </form>
            <?php endif; ?>
            <form method="post" onsubmit="return confirm('Mesaj silinsin mi?')">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="delete">
                <input type="hidden" name="id" value="<?= $message['id'] ?>">
                <button type="submit" class="btn btn-outline-danger btn-sm"><i class="bi bi-trash"></i> Sil</button>
            </form>
        </div>
    </div>
</div>

<?php else: ?>
<div class="admin-card">
    <div class="admin-card-header d-flex justify-content-between align-items-center flex-wrap gap-2">
        <h2 class="h6 mb-0">Mesaj Listesi <?php if ($unreadCount > 0): ?><span class="badge bg-danger"><?= $unreadCount ?> yeni</span><?php endif; ?></h2>
        <div class="d-flex gap-2">
            <div class="btn-group btn-group-sm">
                <a href="messages.php" class="btn btn-outline-secondary <?= $filter === 'all' ? 'active' : '' ?>">Tümü</a>
                <a href="messages.php?filter=unread" class="btn btn-outline-secondary <?= $filter === 'unread' ? 'active' : '' ?>">Okunmamış</a>
                <a href="messages.php?filter=read" class="btn btn-outline-secondary <?= $filter === 'read' ? 'active' : '' ?>">Okunmuş</a>
            </div>
            <?php if ($unreadCount > 0): ?>
            <form method="post" class="d-inline">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="mark_all_read">
                <button type="submit" class="btn btn-sm btn-outline-primary">Tümünü Okundu İşaretle</button>
            </form>
            <?php endif; ?>
        </div>
    </div>
    <div class="admin-card-body p-0">
        <?php if (empty($messages)): ?>
        <div class="empty-state"><i class="bi bi-envelope d-block"></i><p>Henüz mesaj yok.</p></div>
        <?php else: ?>
        <div class="table-responsive">
            <table class="table table-hover mb-0">
                <thead>
                    <tr>
                        <th>Durum</th>
                        <th>Ad</th>
                        <th>E-posta</th>
                        <th>Konu</th>
                        <th>Tarih</th>
                        <th width="100">İşlemler</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($messages as $msg): ?>
                    <tr class="<?= !$msg['is_read'] ? 'table-primary' : '' ?>">
                        <td><?= $msg['is_read'] ? '<span class="badge bg-secondary">Okundu</span>' : '<span class="badge bg-primary">Yeni</span>' ?></td>
                        <td><?= e($msg['name']) ?></td>
                        <td><?= e($msg['email']) ?></td>
                        <td><?= e(truncate($msg['subject'] ?? '-', 40)) ?></td>
                        <td><?= format_date($msg['created_at'], 'd.m.Y H:i') ?></td>
                        <td>
                            <a href="messages.php?action=view&id=<?= $msg['id'] ?>" class="btn btn-sm btn-outline-primary btn-action"><i class="bi bi-eye"></i></a>
                            <form method="post" class="d-inline" onsubmit="return confirm('Mesaj silinsin mi?')">
                                <?= csrf_field() ?>
                                <input type="hidden" name="action" value="delete">
                                <input type="hidden" name="id" value="<?= $msg['id'] ?>">
                                <button type="submit" class="btn btn-sm btn-outline-danger btn-action"><i class="bi bi-trash"></i></button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php endif; ?>
    </div>
</div>
<?php endif; ?>

<?php require __DIR__ . '/includes/footer.php'; ?>
