<?php
/**
 * SEO Meta Yönetimi
 */
require_once dirname(__DIR__) . '/config/bootstrap.php';
require_once __DIR__ . '/includes/helpers.php';

require_admin();

$pageTitle = 'SEO Yönetimi';
$currentAdminPage = 'seo';
$languages = admin_languages($pdo);
$pageKey = get_param('page', 'home');

$pageKeys = [
    'home'     => 'Ana Sayfa',
    'about'    => 'Hakkımızda',
    'services' => 'Hizmetler',
    'projects' => 'Projeler',
    'contact'  => 'İletişim',
];

if (is_post()) {
    if (!verify_csrf(post_param('csrf_token'))) {
        set_flash('danger', 'Güvenlik doğrulaması başarısız.');
        redirect('seo.php?page=' . urlencode($pageKey));
    }

    $postPageKey = post_param('page_key', 'home');

    foreach ($languages as $lang) {
        $langId = (int) $lang['id'];
        $metaTitle = post_param('meta_title_' . $langId, '');
        $metaDesc = post_param('meta_description_' . $langId, '');
        $metaKeywords = post_param('meta_keywords_' . $langId, '');
        $ogTitle = post_param('og_title_' . $langId, '');
        $ogDesc = post_param('og_description_' . $langId, '');
        $ogImage = post_param('og_image_' . $langId, '');
        $canonical = post_param('canonical_url_' . $langId, '');

        $existing = db_fetch($pdo,
            'SELECT id FROM seo WHERE page_key = ? AND language_id = ?',
            [$postPageKey, $langId]
        );

        if ($existing) {
            db_execute($pdo,
                'UPDATE seo SET meta_title = ?, meta_description = ?, meta_keywords = ?,
                 og_title = ?, og_description = ?, og_image = ?, canonical_url = ? WHERE id = ?',
                [$metaTitle, $metaDesc, $metaKeywords, $ogTitle, $ogDesc, $ogImage, $canonical, $existing['id']]
            );
        } else {
            db_execute($pdo,
                'INSERT INTO seo (page_key, language_id, meta_title, meta_description, meta_keywords,
                 og_title, og_description, og_image, canonical_url) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
                [$postPageKey, $langId, $metaTitle, $metaDesc, $metaKeywords, $ogTitle, $ogDesc, $ogImage, $canonical]
            );
        }
    }

    admin_log($pdo, 'save_seo', 'SEO güncellendi: ' . $postPageKey);
    set_flash('success', 'SEO bilgileri kaydedildi.');
    redirect('seo.php?page=' . urlencode($postPageKey));
}

$seoData = [];
$rows = db_fetch_all($pdo, 'SELECT * FROM seo WHERE page_key = ?', [$pageKey]);
foreach ($rows as $row) {
    $seoData[$row['language_id']] = $row;
}

require __DIR__ . '/includes/header.php';
?>

<div class="admin-card mb-3">
    <div class="admin-card-body">
        <div class="btn-group flex-wrap">
            <?php foreach ($pageKeys as $key => $label): ?>
            <a href="seo.php?page=<?= e($key) ?>" class="btn btn-sm <?= $pageKey === $key ? 'btn-primary' : 'btn-outline-secondary' ?>">
                <?= e($label) ?>
            </a>
            <?php endforeach; ?>
        </div>
    </div>
</div>

<div class="admin-card">
    <div class="admin-card-header">
        <h2 class="h6 mb-0"><?= e($pageKeys[$pageKey] ?? $pageKey) ?> — SEO Ayarları</h2>
    </div>
    <div class="admin-card-body">
        <form method="post">
            <?= csrf_field() ?>
            <input type="hidden" name="page_key" value="<?= e($pageKey) ?>">

            <ul class="nav nav-tabs lang-tabs mb-3" role="tablist">
                <?php foreach ($languages as $i => $lang): ?>
                <li class="nav-item">
                    <button class="nav-link <?= $i === 0 ? 'active' : '' ?>" data-bs-toggle="tab" data-bs-target="#lang-<?= $lang['id'] ?>" type="button">
                        <?= e($lang['flag']) ?> <?= e($lang['native_name']) ?>
                    </button>
                </li>
                <?php endforeach; ?>
            </ul>

            <div class="tab-content">
                <?php foreach ($languages as $i => $lang): ?>
                <?php $s = $seoData[$lang['id']] ?? []; ?>
                <div class="tab-pane fade <?= $i === 0 ? 'show active' : '' ?>" id="lang-<?= $lang['id'] ?>">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label">Meta Başlık</label>
                            <input type="text" class="form-control" name="meta_title_<?= $lang['id'] ?>" value="<?= e($s['meta_title'] ?? '') ?>">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Meta Anahtar Kelimeler</label>
                            <input type="text" class="form-control" name="meta_keywords_<?= $lang['id'] ?>" value="<?= e($s['meta_keywords'] ?? '') ?>">
                        </div>
                        <div class="col-12">
                            <label class="form-label">Meta Açıklama</label>
                            <textarea class="form-control" name="meta_description_<?= $lang['id'] ?>" rows="2"><?= e($s['meta_description'] ?? '') ?></textarea>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">OG Başlık</label>
                            <input type="text" class="form-control" name="og_title_<?= $lang['id'] ?>" value="<?= e($s['og_title'] ?? '') ?>">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">OG Görsel URL</label>
                            <input type="text" class="form-control" name="og_image_<?= $lang['id'] ?>" value="<?= e($s['og_image'] ?? '') ?>">
                        </div>
                        <div class="col-12">
                            <label class="form-label">OG Açıklama</label>
                            <textarea class="form-control" name="og_description_<?= $lang['id'] ?>" rows="2"><?= e($s['og_description'] ?? '') ?></textarea>
                        </div>
                        <div class="col-12">
                            <label class="form-label">Canonical URL</label>
                            <input type="url" class="form-control" name="canonical_url_<?= $lang['id'] ?>" value="<?= e($s['canonical_url'] ?? '') ?>">
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>

            <button type="submit" class="btn btn-primary mt-4"><i class="bi bi-check-lg"></i> Kaydet</button>
        </form>
    </div>
</div>

<?php require __DIR__ . '/includes/footer.php'; ?>
