<?php
/**
 * Çeviri Yönetimi
 */
require_once dirname(__DIR__) . '/config/bootstrap.php';
require_once __DIR__ . '/includes/helpers.php';

require_admin();

$pageTitle = 'Çeviriler';
$currentAdminPage = 'translations';
$languages = admin_languages($pdo);
$groupFilter = get_param('group', '');
$search = get_param('search', '');
$action = get_param('action', 'list');
$keyId = (int) get_param('id', 0);

if (is_post()) {
    if (!verify_csrf(post_param('csrf_token'))) {
        set_flash('danger', 'Güvenlik doğrulaması başarısız.');
        redirect('translations.php');
    }

    $postAction = post_param('action');

    if ($postAction === 'delete' && $keyId > 0) {
        db_execute($pdo, 'DELETE FROM translation_keys WHERE id = ?', [$keyId]);
        admin_log($pdo, 'delete_translation', 'Çeviri anahtarı silindi: #' . $keyId);
        set_flash('success', 'Çeviri anahtarı silindi.');
        redirect('translations.php' . ($groupFilter ? '?group=' . urlencode($groupFilter) : ''));
    }

    if ($postAction === 'save') {
        $editKeyId = (int) post_param('id', 0);
        $key = post_param('key', '');
        $groupName = post_param('group_name', 'general');
        $description = post_param('description', '');

        if (empty($key)) {
            set_flash('danger', 'Anahtar adı zorunludur.');
            redirect('translations.php?action=' . ($editKeyId ? 'edit&id=' . $editKeyId : 'add'));
        }

        if ($editKeyId > 0) {
            db_execute($pdo,
                'UPDATE translation_keys SET `key` = ?, group_name = ?, description = ? WHERE id = ?',
                [$key, $groupName, $description, $editKeyId]
            );
            $saveKeyId = $editKeyId;
        } else {
            $existing = db_fetch($pdo, 'SELECT id FROM translation_keys WHERE `key` = ?', [$key]);
            if ($existing) {
                set_flash('danger', 'Bu anahtar zaten mevcut.');
                redirect('translations.php?action=add');
            }
            db_execute($pdo,
                'INSERT INTO translation_keys (`key`, group_name, description) VALUES (?, ?, ?)',
                [$key, $groupName, $description]
            );
            $saveKeyId = (int) db_last_id($pdo);
        }

        foreach ($languages as $lang) {
            $langId = (int) $lang['id'];
            $value = post_param('value_' . $langId, '');
            admin_save_translation($pdo, $saveKeyId, $langId, $value);
        }

        admin_log($pdo, 'save_translation', 'Çeviri kaydedildi: ' . $key);
        set_flash('success', 'Çeviri başarıyla kaydedildi.');
        redirect('translations.php' . ($groupFilter ? '?group=' . urlencode($groupFilter) : ''));
    }

    if ($postAction === 'bulk_save') {
        $values = $_POST['values'] ?? [];
        foreach ($values as $tid => $val) {
            db_execute($pdo, 'UPDATE translations SET value = ? WHERE id = ?', [sanitize_input($val), (int) $tid]);
        }
        admin_log($pdo, 'bulk_save_translations', 'Toplu çeviri güncellendi');
        set_flash('success', 'Çeviriler güncellendi.');
        redirect('translations.php' . ($groupFilter ? '?group=' . urlencode($groupFilter) : '') . ($search ? '&search=' . urlencode($search) : ''));
    }
}

$translationKey = null;
$keyTranslations = [];
if ($action === 'edit' && $keyId > 0) {
    $translationKey = db_fetch($pdo, 'SELECT * FROM translation_keys WHERE id = ?', [$keyId]);
    if (!$translationKey) {
        set_flash('danger', 'Çeviri anahtarı bulunamadı.');
        redirect('translations.php');
    }
    $transRows = db_fetch_all($pdo, 'SELECT * FROM translations WHERE key_id = ?', [$keyId]);
    foreach ($transRows as $row) {
        $keyTranslations[$row['language_id']] = $row;
    }
}

$groups = db_fetch_all($pdo, 'SELECT DISTINCT group_name FROM translation_keys ORDER BY group_name');

$sql = 'SELECT tk.*, t.id as trans_id, t.language_id, t.value, l.code as lang_code, l.native_name
        FROM translation_keys tk
        CROSS JOIN languages l
        LEFT JOIN translations t ON t.key_id = tk.id AND t.language_id = l.id
        WHERE l.is_active = 1';
$params = [];

if ($groupFilter) {
    $sql .= ' AND tk.group_name = ?';
    $params[] = $groupFilter;
}
if ($search) {
    $sql .= ' AND (tk.`key` LIKE ? OR tk.description LIKE ? OR t.value LIKE ?)';
    $params[] = "%{$search}%";
    $params[] = "%{$search}%";
    $params[] = "%{$search}%";
}

$sql .= ' ORDER BY tk.group_name, tk.`key`, l.sort_order';
$rows = db_fetch_all($pdo, $sql, $params);

$grouped = [];
foreach ($rows as $row) {
    $grouped[$row['id']]['key'] = $row;
    $grouped[$row['id']]['translations'][$row['language_id']] = $row;
}

require __DIR__ . '/includes/header.php';
?>

<?php if ($action === 'add' || $action === 'edit'): ?>
<div class="admin-card">
    <div class="admin-card-header d-flex justify-content-between align-items-center">
        <h2 class="h6 mb-0"><?= $action === 'edit' ? 'Çeviri Düzenle' : 'Yeni Çeviri Anahtarı' ?></h2>
        <a href="translations.php" class="btn btn-sm btn-outline-secondary"><i class="bi bi-arrow-left"></i> Geri</a>
    </div>
    <div class="admin-card-body">
        <form method="post">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="save">
            <input type="hidden" name="id" value="<?= (int) ($translationKey['id'] ?? 0) ?>">

            <div class="row g-3 mb-4">
                <div class="col-md-4">
                    <label class="form-label">Anahtar *</label>
                    <input type="text" class="form-control" name="key" value="<?= e($translationKey['key'] ?? '') ?>" required pattern="[a-z0-9_]+" placeholder="nav_home">
                </div>
                <div class="col-md-4">
                    <label class="form-label">Grup</label>
                    <input type="text" class="form-control" name="group_name" value="<?= e($translationKey['group_name'] ?? 'general') ?>" list="groups">
                    <datalist id="groups">
                        <?php foreach ($groups as $g): ?>
                        <option value="<?= e($g['group_name']) ?>">
                        <?php endforeach; ?>
                    </datalist>
                </div>
                <div class="col-md-4">
                    <label class="form-label">Açıklama</label>
                    <input type="text" class="form-control" name="description" value="<?= e($translationKey['description'] ?? '') ?>">
                </div>
            </div>

            <?php foreach ($languages as $lang): ?>
            <?php $t = $keyTranslations[$lang['id']] ?? []; ?>
            <div class="mb-3">
                <label class="form-label"><?= e($lang['flag']) ?> <?= e($lang['native_name']) ?></label>
                <textarea class="form-control" name="value_<?= $lang['id'] ?>" rows="2"><?= e($t['value'] ?? '') ?></textarea>
            </div>
            <?php endforeach; ?>

            <button type="submit" class="btn btn-primary"><i class="bi bi-check-lg"></i> Kaydet</button>
        </form>
    </div>
</div>

<?php else: ?>
<div class="admin-card mb-3">
    <div class="admin-card-body">
        <form method="get" class="row g-2 align-items-end">
            <div class="col-md-3">
                <label class="form-label">Grup</label>
                <select class="form-select" name="group" onchange="this.form.submit()">
                    <option value="">Tüm Gruplar</option>
                    <?php foreach ($groups as $g): ?>
                    <option value="<?= e($g['group_name']) ?>" <?= $groupFilter === $g['group_name'] ? 'selected' : '' ?>><?= e($g['group_name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-6">
                <label class="form-label">Ara</label>
                <input type="text" class="form-control" name="search" value="<?= e($search) ?>" placeholder="Anahtar veya değer ara...">
            </div>
            <div class="col-md-3">
                <button type="submit" class="btn btn-outline-primary"><i class="bi bi-search"></i> Ara</button>
                <a href="translations.php?action=add" class="btn btn-primary"><i class="bi bi-plus-lg"></i> Yeni</a>
            </div>
        </form>
    </div>
</div>

<form method="post">
    <?= csrf_field() ?>
    <input type="hidden" name="action" value="bulk_save">

    <div class="admin-card">
        <div class="admin-card-header d-flex justify-content-between align-items-center">
            <h2 class="h6 mb-0">Çeviri Listesi (<?= count($grouped) ?> anahtar)</h2>
            <button type="submit" class="btn btn-sm btn-primary"><i class="bi bi-check-lg"></i> Toplu Kaydet</button>
        </div>
        <div class="admin-card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover mb-0">
                    <thead>
                        <tr>
                            <th>Anahtar</th>
                            <th>Grup</th>
                            <?php foreach ($languages as $lang): ?>
                            <th><?= e($lang['flag']) ?> <?= e($lang['code']) ?></th>
                            <?php endforeach; ?>
                            <th width="80">İşlem</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($grouped as $kid => $item): ?>
                        <tr>
                            <td><code><?= e($item['key']['key']) ?></code></td>
                            <td><span class="badge bg-secondary"><?= e($item['key']['group_name']) ?></span></td>
                            <?php foreach ($languages as $lang): ?>
                            <?php $tr = $item['translations'][$lang['id']] ?? null; ?>
                            <td>
                                <?php if ($tr && $tr['trans_id']): ?>
                                <input type="text" class="form-control form-control-sm" name="values[<?= $tr['trans_id'] ?>]" value="<?= e($tr['value'] ?? '') ?>">
                                <?php else: ?>
                                <span class="text-muted small">—</span>
                                <?php endif; ?>
                            </td>
                            <?php endforeach; ?>
                            <td>
                                <a href="translations.php?action=edit&id=<?= $kid ?>" class="btn btn-sm btn-outline-primary btn-action"><i class="bi bi-pencil"></i></a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</form>
<?php endif; ?>

<?php require __DIR__ . '/includes/footer.php'; ?>
