<?php
/**
 * Hakkımızda Bölümleri
 */
require_once dirname(__DIR__) . '/config/bootstrap.php';
require_once __DIR__ . '/includes/helpers.php';

require_admin();

$pageTitle = 'Hakkımızda';
$currentAdminPage = 'about';
$languages = admin_languages($pdo);
$action = get_param('action', 'list');
$id = (int) get_param('id', 0);

$sectionLabels = [
    'story'   => 'Hikayemiz',
    'vision'  => 'Vizyon',
    'mission' => 'Misyon',
    'quality' => 'Kalite Politikası',
    'values'  => 'Değerlerimiz',
    'why_us'  => 'Neden Biz',
];

if (is_post()) {
    if (!verify_csrf(post_param('csrf_token'))) {
        set_flash('danger', 'Güvenlik doğrulaması başarısız.');
        redirect('about.php');
    }

    $postAction = post_param('action');
    $editId = (int) post_param('id', 0);

    if ($postAction === 'save' && $editId > 0) {
        $videoUrl = post_param('video_url', '');
        $sortOrder = (int) post_param('sort_order', 0);
        $isActive = isset($_POST['is_active']) ? 1 : 0;

        try {
            $existing = db_fetch($pdo, 'SELECT * FROM about_sections WHERE id = ?', [$editId]);
            if (!$existing) {
                set_flash('danger', 'Bölüm bulunamadı.');
                redirect('about.php');
            }

            $imagePath = null;
            if (!empty($_FILES['image']['name'])) {
                $imagePath = admin_upload_file($_FILES['image'], 'about', $appConfig['allowed_images'], $appConfig['max_upload']);
            }

            $finalImage = $imagePath ?? $existing['image'];
            if ($imagePath && $existing['image']) {
                admin_delete_file($existing['image']);
            }

            db_execute($pdo,
                'UPDATE about_sections SET image = ?, video_url = ?, sort_order = ?, is_active = ? WHERE id = ?',
                [$finalImage, $videoUrl, $sortOrder, $isActive, $editId]
            );

            foreach ($languages as $lang) {
                $langId = (int) $lang['id'];
                $title = post_param('title_' . $langId, '');
                $content = $_POST['content_' . $langId] ?? '';

                $trans = db_fetch($pdo,
                    'SELECT id FROM about_translations WHERE section_id = ? AND language_id = ?',
                    [$editId, $langId]
                );

                if ($trans) {
                    db_execute($pdo,
                        'UPDATE about_translations SET title = ?, content = ? WHERE id = ?',
                        [$title, $content, $trans['id']]
                    );
                } else {
                    db_execute($pdo,
                        'INSERT INTO about_translations (section_id, language_id, title, content) VALUES (?, ?, ?, ?)',
                        [$editId, $langId, $title, $content]
                    );
                }
            }

            admin_log($pdo, 'save_about', 'Hakkımızda bölümü güncellendi: #' . $editId);
            set_flash('success', 'Bölüm başarıyla kaydedildi.');
            redirect('about.php');
        } catch (RuntimeException $e) {
            set_flash('danger', $e->getMessage());
            redirect('about.php?action=edit&id=' . $editId);
        }
    }
}

$section = null;
$translations = [];
if ($action === 'edit' && $id > 0) {
    $section = db_fetch($pdo, 'SELECT * FROM about_sections WHERE id = ?', [$id]);
    if (!$section) {
        set_flash('danger', 'Bölüm bulunamadı.');
        redirect('about.php');
    }
    $transRows = db_fetch_all($pdo, 'SELECT * FROM about_translations WHERE section_id = ?', [$id]);
    foreach ($transRows as $row) {
        $translations[$row['language_id']] = $row;
    }
}

$sections = db_fetch_all($pdo,
    'SELECT a.*, at.title FROM about_sections a
     LEFT JOIN about_translations at ON at.section_id = a.id AND at.language_id = 1
     ORDER BY a.sort_order ASC'
);

require __DIR__ . '/includes/header.php';
?>

<?php if ($action === 'edit' && $section): ?>
<div class="admin-card">
    <div class="admin-card-header d-flex justify-content-between align-items-center">
        <h2 class="h6 mb-0"><?= e($sectionLabels[$section['section_key']] ?? $section['section_key']) ?> — Düzenle</h2>
        <a href="about.php" class="btn btn-sm btn-outline-secondary"><i class="bi bi-arrow-left"></i> Geri</a>
    </div>
    <div class="admin-card-body">
        <form method="post" enctype="multipart/form-data">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="save">
            <input type="hidden" name="id" value="<?= $section['id'] ?>">

            <div class="row g-3 mb-4">
                <div class="col-md-4">
                    <label class="form-label">Görsel</label>
                    <?php if (!empty($section['image'])): ?>
                    <div class="mb-2"><img src="<?= e(asset_url($section['image'])) ?>" class="img-preview" alt=""></div>
                    <?php endif; ?>
                    <input type="file" class="form-control" name="image" accept="image/*">
                </div>
                <div class="col-md-4">
                    <label class="form-label">Video URL</label>
                    <input type="url" class="form-control" name="video_url" value="<?= e($section['video_url'] ?? '') ?>">
                </div>
                <div class="col-md-2">
                    <label class="form-label">Sıra</label>
                    <input type="number" class="form-control" name="sort_order" value="<?= (int) $section['sort_order'] ?>">
                </div>
                <div class="col-md-2 d-flex align-items-end">
                    <div class="form-check form-switch">
                        <input class="form-check-input" type="checkbox" name="is_active" id="is_active" <?= $section['is_active'] ? 'checked' : '' ?>>
                        <label class="form-check-label" for="is_active">Aktif</label>
                    </div>
                </div>
            </div>

            <ul class="nav nav-tabs lang-tabs mb-3" role="tablist">
                <?php foreach ($languages as $i => $lang): ?>
                <li class="nav-item">
                    <button class="nav-link <?= $i === 0 ? 'active' : '' ?>" data-bs-toggle="tab" data-bs-target="#lang-<?= $lang['id'] ?>" type="button">
                        <?= e($lang['flag']) ?> <?= e($lang['native_name']) ?>
                    </button>
                </li>
                <?php endforeach; ?>
            </ul>

            <div class="tab-content">
                <?php foreach ($languages as $i => $lang): ?>
                <?php $t = $translations[$lang['id']] ?? []; ?>
                <div class="tab-pane fade <?= $i === 0 ? 'show active' : '' ?>" id="lang-<?= $lang['id'] ?>">
                    <div class="mb-3">
                        <label class="form-label">Başlık *</label>
                        <input type="text" class="form-control" name="title_<?= $lang['id'] ?>" value="<?= e($t['title'] ?? '') ?>" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">İçerik</label>
                        <textarea class="form-control" name="content_<?= $lang['id'] ?>" rows="8"><?= e($t['content'] ?? '') ?></textarea>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>

            <div class="mt-4">
                <button type="submit" class="btn btn-primary"><i class="bi bi-check-lg"></i> Kaydet</button>
            </div>
        </form>
    </div>
</div>

<?php else: ?>
<div class="admin-card">
    <div class="admin-card-header">
        <h2 class="h6 mb-0">Hakkımızda Bölümleri</h2>
    </div>
    <div class="admin-card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover mb-0">
                <thead>
                    <tr>
                        <th>Bölüm</th>
                        <th>Başlık</th>
                        <th>Sıra</th>
                        <th>Durum</th>
                        <th width="80">İşlem</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($sections as $s): ?>
                    <tr>
                        <td><code><?= e($s['section_key']) ?></code> — <?= e($sectionLabels[$s['section_key']] ?? '') ?></td>
                        <td><?= e($s['title'] ?? '-') ?></td>
                        <td><?= (int) $s['sort_order'] ?></td>
                        <td><?= $s['is_active'] ? '<span class="badge bg-success">Aktif</span>' : '<span class="badge bg-secondary">Pasif</span>' ?></td>
                        <td>
                            <a href="about.php?action=edit&id=<?= $s['id'] ?>" class="btn btn-sm btn-outline-primary btn-action"><i class="bi bi-pencil"></i></a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php endif; ?>

<?php require __DIR__ . '/includes/footer.php'; ?>
