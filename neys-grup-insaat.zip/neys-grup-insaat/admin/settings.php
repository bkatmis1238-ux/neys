<?php
/**
 * Site Ayarları
 */
require_once dirname(__DIR__) . '/config/bootstrap.php';
require_once __DIR__ . '/includes/helpers.php';

require_admin();

$pageTitle = 'Site Ayarları';
$currentAdminPage = 'settings';
$tab = get_param('tab', 'general');

if (is_post()) {
    if (!verify_csrf(post_param('csrf_token'))) {
        set_flash('danger', 'Güvenlik doğrulaması başarısız.');
        redirect('settings.php?tab=' . $tab);
    }

    $postTab = post_param('tab', 'general');

    try {
        if ($postTab === 'general') {
            $keys = ['site_name', 'site_tagline', 'footer_text', 'maintenance_mode', 'cookie_notice'];
            foreach ($keys as $key) {
                $value = in_array($key, ['maintenance_mode', 'cookie_notice'], true)
                    ? (isset($_POST[$key]) ? '1' : '0')
                    : post_param($key, '');
                update_setting($pdo, $key, $value);
            }
        } elseif ($postTab === 'contact') {
            $keys = ['phone', 'phone2', 'whatsapp', 'email', 'address', 'map_embed', 'working_hours'];
            foreach ($keys as $key) {
                $value = $key === 'map_embed' ? ($_POST[$key] ?? '') : post_param($key, '');
                update_setting($pdo, $key, $value);
            }
        } elseif ($postTab === 'social') {
            $keys = ['facebook', 'instagram', 'linkedin', 'youtube', 'twitter'];
            foreach ($keys as $key) {
                update_setting($pdo, $key, post_param($key, ''));
            }
        } elseif ($postTab === 'theme') {
            update_setting($pdo, 'primary_color', post_param('primary_color', '#1e5aa8'));
            update_setting($pdo, 'primary_dark', post_param('primary_dark', '#0d3d7a'));

            if (!empty($_FILES['logo']['name'])) {
                $path = admin_upload_file($_FILES['logo'], 'logos', $appConfig['allowed_images'], $appConfig['max_upload']);
                admin_delete_file($settings['logo'] ?? null);
                update_setting($pdo, 'logo', $path);
            }
            if (!empty($_FILES['logo_dark']['name'])) {
                $path = admin_upload_file($_FILES['logo_dark'], 'logos', $appConfig['allowed_images'], $appConfig['max_upload']);
                admin_delete_file($settings['logo_dark'] ?? null);
                update_setting($pdo, 'logo_dark', $path);
            }
            if (!empty($_FILES['favicon']['name'])) {
                $path = admin_upload_file($_FILES['favicon'], 'logos', array_merge($appConfig['allowed_images'], ['ico']), $appConfig['max_upload']);
                admin_delete_file($settings['favicon'] ?? null);
                update_setting($pdo, 'favicon', $path);
            }
        } elseif ($postTab === 'seo') {
            update_setting($pdo, 'google_analytics', post_param('google_analytics', ''));
        }

        $settings = load_settings($pdo);
        admin_log($pdo, 'update_settings', 'Ayarlar güncellendi: ' . $postTab);
        set_flash('success', 'Ayarlar başarıyla kaydedildi.');
    } catch (RuntimeException $e) {
        set_flash('danger', $e->getMessage());
    }

    redirect('settings.php?tab=' . $postTab);
}

require __DIR__ . '/includes/header.php';
?>

<ul class="nav nav-tabs mb-4">
    <li class="nav-item"><a class="nav-link <?= $tab === 'general' ? 'active' : '' ?>" href="?tab=general">Genel</a></li>
    <li class="nav-item"><a class="nav-link <?= $tab === 'contact' ? 'active' : '' ?>" href="?tab=contact">İletişim</a></li>
    <li class="nav-item"><a class="nav-link <?= $tab === 'social' ? 'active' : '' ?>" href="?tab=social">Sosyal Medya</a></li>
    <li class="nav-item"><a class="nav-link <?= $tab === 'theme' ? 'active' : '' ?>" href="?tab=theme">Tema & Logo</a></li>
    <li class="nav-item"><a class="nav-link <?= $tab === 'seo' ? 'active' : '' ?>" href="?tab=seo">SEO</a></li>
</ul>

<div class="admin-card">
    <div class="admin-card-body">
        <?php if ($tab === 'general'): ?>
        <form method="post">
            <?= csrf_field() ?>
            <input type="hidden" name="tab" value="general">
            <div class="row g-3">
                <div class="col-md-6">
                    <label class="form-label">Site Adı</label>
                    <input type="text" class="form-control" name="site_name" value="<?= e($settings['site_name'] ?? '') ?>">
                </div>
                <div class="col-md-6">
                    <label class="form-label">Slogan</label>
                    <input type="text" class="form-control" name="site_tagline" value="<?= e($settings['site_tagline'] ?? '') ?>">
                </div>
                <div class="col-12">
                    <label class="form-label">Footer Metni</label>
                    <textarea class="form-control" name="footer_text" rows="2"><?= e($settings['footer_text'] ?? '') ?></textarea>
                </div>
                <div class="col-md-6">
                    <div class="form-check form-switch">
                        <input class="form-check-input" type="checkbox" name="maintenance_mode" id="maintenance_mode" <?= ($settings['maintenance_mode'] ?? '0') === '1' ? 'checked' : '' ?>>
                        <label class="form-check-label" for="maintenance_mode">Bakım Modu</label>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-check form-switch">
                        <input class="form-check-input" type="checkbox" name="cookie_notice" id="cookie_notice" <?= ($settings['cookie_notice'] ?? '1') === '1' ? 'checked' : '' ?>>
                        <label class="form-check-label" for="cookie_notice">Çerez Bildirimi</label>
                    </div>
                </div>
            </div>
            <button type="submit" class="btn btn-primary mt-4"><i class="bi bi-check-lg"></i> Kaydet</button>
        </form>

        <?php elseif ($tab === 'contact'): ?>
        <form method="post">
            <?= csrf_field() ?>
            <input type="hidden" name="tab" value="contact">
            <div class="row g-3">
                <div class="col-md-6">
                    <label class="form-label">Telefon</label>
                    <input type="text" class="form-control" name="phone" value="<?= e($settings['phone'] ?? '') ?>">
                </div>
                <div class="col-md-6">
                    <label class="form-label">Telefon 2</label>
                    <input type="text" class="form-control" name="phone2" value="<?= e($settings['phone2'] ?? '') ?>">
                </div>
                <div class="col-md-6">
                    <label class="form-label">WhatsApp</label>
                    <input type="text" class="form-control" name="whatsapp" value="<?= e($settings['whatsapp'] ?? '') ?>" placeholder="905550000000">
                </div>
                <div class="col-md-6">
                    <label class="form-label">E-posta</label>
                    <input type="email" class="form-control" name="email" value="<?= e($settings['email'] ?? '') ?>">
                </div>
                <div class="col-12">
                    <label class="form-label">Adres</label>
                    <textarea class="form-control" name="address" rows="2"><?= e($settings['address'] ?? '') ?></textarea>
                </div>
                <div class="col-12">
                    <label class="form-label">Çalışma Saatleri</label>
                    <input type="text" class="form-control" name="working_hours" value="<?= e($settings['working_hours'] ?? '') ?>">
                </div>
                <div class="col-12">
                    <label class="form-label">Harita Embed Kodu</label>
                    <textarea class="form-control" name="map_embed" rows="3"><?= e($settings['map_embed'] ?? '') ?></textarea>
                </div>
            </div>
            <button type="submit" class="btn btn-primary mt-4"><i class="bi bi-check-lg"></i> Kaydet</button>
        </form>

        <?php elseif ($tab === 'social'): ?>
        <form method="post">
            <?= csrf_field() ?>
            <input type="hidden" name="tab" value="social">
            <div class="row g-3">
                <?php foreach (['facebook', 'instagram', 'linkedin', 'youtube', 'twitter'] as $social): ?>
                <div class="col-md-6">
                    <label class="form-label"><?= ucfirst($social) ?> URL</label>
                    <input type="url" class="form-control" name="<?= $social ?>" value="<?= e($settings[$social] ?? '') ?>">
                </div>
                <?php endforeach; ?>
            </div>
            <button type="submit" class="btn btn-primary mt-4"><i class="bi bi-check-lg"></i> Kaydet</button>
        </form>

        <?php elseif ($tab === 'theme'): ?>
        <form method="post" enctype="multipart/form-data">
            <?= csrf_field() ?>
            <input type="hidden" name="tab" value="theme">
            <div class="row g-3">
                <div class="col-md-4">
                    <label class="form-label">Ana Renk</label>
                    <input type="color" class="form-control form-control-color w-100" name="primary_color" value="<?= e($settings['primary_color'] ?? '#1e5aa8') ?>">
                </div>
                <div class="col-md-4">
                    <label class="form-label">Koyu Renk</label>
                    <input type="color" class="form-control form-control-color w-100" name="primary_dark" value="<?= e($settings['primary_dark'] ?? '#0d3d7a') ?>">
                </div>
                <div class="col-md-4"></div>
                <div class="col-md-4">
                    <label class="form-label">Logo</label>
                    <?php if (!empty($settings['logo'])): ?>
                    <div class="mb-2"><img src="<?= e(asset_url($settings['logo'])) ?>" class="img-preview" alt="Logo"></div>
                    <?php endif; ?>
                    <input type="file" class="form-control" name="logo" accept="image/*">
                </div>
                <div class="col-md-4">
                    <label class="form-label">Logo (Koyu Tema)</label>
                    <?php if (!empty($settings['logo_dark'])): ?>
                    <div class="mb-2"><img src="<?= e(asset_url($settings['logo_dark'])) ?>" class="img-preview" alt="Logo Dark"></div>
                    <?php endif; ?>
                    <input type="file" class="form-control" name="logo_dark" accept="image/*">
                </div>
                <div class="col-md-4">
                    <label class="form-label">Favicon</label>
                    <?php if (!empty($settings['favicon'])): ?>
                    <div class="mb-2"><img src="<?= e(asset_url($settings['favicon'])) ?>" class="img-preview-sm" alt="Favicon"></div>
                    <?php endif; ?>
                    <input type="file" class="form-control" name="favicon" accept="image/*,.ico">
                </div>
            </div>
            <button type="submit" class="btn btn-primary mt-4"><i class="bi bi-check-lg"></i> Kaydet</button>
        </form>

        <?php elseif ($tab === 'seo'): ?>
        <form method="post">
            <?= csrf_field() ?>
            <input type="hidden" name="tab" value="seo">
            <div class="mb-3">
                <label class="form-label">Google Analytics ID</label>
                <input type="text" class="form-control" name="google_analytics" value="<?= e($settings['google_analytics'] ?? '') ?>" placeholder="G-XXXXXXXXXX">
            </div>
            <button type="submit" class="btn btn-primary"><i class="bi bi-check-lg"></i> Kaydet</button>
        </form>
        <?php endif; ?>
    </div>
</div>

<?php require __DIR__ . '/includes/footer.php'; ?>
