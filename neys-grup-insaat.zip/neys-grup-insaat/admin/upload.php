<?php
/**
 * Güvenli dosya yükleme handler
 */
require_once dirname(__DIR__) . '/config/bootstrap.php';
require_once __DIR__ . '/includes/helpers.php';

require_admin();

header('Content-Type: application/json; charset=utf-8');

if (!is_post()) {
    json_response(['success' => false, 'message' => 'Geçersiz istek.'], 405);
}

if (!verify_csrf(post_param('csrf_token'))) {
    json_response(['success' => false, 'message' => 'CSRF doğrulaması başarısız.'], 403);
}

$type = post_param('type', 'general');
$allowedTypes = [
    'slider'   => ['subdir' => 'sliders', 'ext' => ['jpg', 'jpeg', 'png', 'webp', 'gif']],
    'service'  => ['subdir' => 'services', 'ext' => ['jpg', 'jpeg', 'png', 'webp', 'gif']],
    'project'  => ['subdir' => 'projects', 'ext' => ['jpg', 'jpeg', 'png', 'webp', 'gif']],
    'gallery'  => ['subdir' => 'projects/gallery', 'ext' => ['jpg', 'jpeg', 'png', 'webp', 'gif']],
    'about'    => ['subdir' => 'about', 'ext' => ['jpg', 'jpeg', 'png', 'webp', 'gif']],
    'logo'     => ['subdir' => 'logos', 'ext' => ['jpg', 'jpeg', 'png', 'webp', 'svg']],
    'favicon'  => ['subdir' => 'logos', 'ext' => ['jpg', 'jpeg', 'png', 'webp', 'svg', 'ico']],
    'pdf'      => ['subdir' => 'documents', 'ext' => ['pdf']],
    'general'  => ['subdir' => 'general', 'ext' => ['jpg', 'jpeg', 'png', 'webp', 'gif', 'pdf']],
];

if (!isset($allowedTypes[$type])) {
    json_response(['success' => false, 'message' => 'Geçersiz yükleme türü.'], 400);
}

$config = $allowedTypes[$type];
$file = $_FILES['file'] ?? null;

if (!$file || $file['error'] === UPLOAD_ERR_NO_FILE) {
    json_response(['success' => false, 'message' => 'Dosya seçilmedi.'], 400);
}

try {
    $path = admin_upload_file($file, $config['subdir'], $config['ext'], $appConfig['max_upload']);
    admin_log($pdo, 'upload', 'Dosya yüklendi: ' . $path);
    json_response([
        'success' => true,
        'path'    => $path,
        'url'     => asset_url($path),
        'message' => 'Dosya başarıyla yüklendi.',
    ]);
} catch (RuntimeException $e) {
    json_response(['success' => false, 'message' => $e->getMessage()], 400);
}
