<?php
/**
 * Admin Kullanıcı Yönetimi (Sadece super_admin)
 */
require_once dirname(__DIR__) . '/config/bootstrap.php';
require_once __DIR__ . '/includes/helpers.php';

require_super_admin();

$pageTitle = 'Yönetici Kullanıcıları';
$currentAdminPage = 'admins';
$action = get_param('action', 'list');
$id = (int) get_param('id', 0);

$roles = [
    'super_admin' => 'Süper Admin',
    'admin'       => 'Admin',
    'editor'      => 'Editör',
];

if (is_post()) {
    if (!verify_csrf(post_param('csrf_token'))) {
        set_flash('danger', 'Güvenlik doğrulaması başarısız.');
        redirect('admins.php');
    }

    $postAction = post_param('action');

    if ($postAction === 'delete' && $id > 0) {
        if ($id === (int) $_SESSION['admin_id']) {
            set_flash('danger', 'Kendi hesabınızı silemezsiniz.');
            redirect('admins.php');
        }
        $admin = db_fetch($pdo, 'SELECT * FROM admins WHERE id = ?', [$id]);
        if ($admin) {
            db_execute($pdo, 'DELETE FROM admins WHERE id = ?', [$id]);
            admin_log($pdo, 'delete_admin', 'Admin silindi: ' . $admin['username']);
            set_flash('success', 'Yönetici silindi.');
        }
        redirect('admins.php');
    }

    if ($postAction === 'save') {
        $editId = (int) post_param('id', 0);
        $username = post_param('username', '');
        $email = post_param('email', '');
        $fullName = post_param('full_name', '');
        $role = post_param('role', 'admin');
        $password = $_POST['password'] ?? '';
        $isActive = isset($_POST['is_active']) ? 1 : 0;

        if (!in_array($role, ['super_admin', 'admin', 'editor'], true)) {
            $role = 'admin';
        }

        if (empty($username) || empty($email) || empty($fullName)) {
            set_flash('danger', 'Zorunlu alanları doldurun.');
            redirect('admins.php?action=' . ($editId ? 'edit&id=' . $editId : 'add'));
        }

        if (!is_valid_email($email)) {
            set_flash('danger', 'Geçerli bir e-posta adresi girin.');
            redirect('admins.php?action=' . ($editId ? 'edit&id=' . $editId : 'add'));
        }

        if ($editId > 0) {
            $existing = db_fetch($pdo, 'SELECT * FROM admins WHERE id = ?', [$editId]);
            if (!$existing) {
                set_flash('danger', 'Kullanıcı bulunamadı.');
                redirect('admins.php');
            }

            $dupUser = db_fetch($pdo, 'SELECT id FROM admins WHERE username = ? AND id != ?', [$username, $editId]);
            $dupEmail = db_fetch($pdo, 'SELECT id FROM admins WHERE email = ? AND id != ?', [$email, $editId]);
            if ($dupUser || $dupEmail) {
                set_flash('danger', 'Kullanıcı adı veya e-posta zaten kullanılıyor.');
                redirect('admins.php?action=edit&id=' . $editId);
            }

            if (!empty($password)) {
                if (strlen($password) < 8) {
                    set_flash('danger', 'Şifre en az 8 karakter olmalıdır.');
                    redirect('admins.php?action=edit&id=' . $editId);
                }
                $hash = password_hash($password, PASSWORD_DEFAULT);
                db_execute($pdo,
                    'UPDATE admins SET username = ?, email = ?, password = ?, full_name = ?, role = ?, is_active = ? WHERE id = ?',
                    [$username, $email, $hash, $fullName, $role, $isActive, $editId]
                );
            } else {
                db_execute($pdo,
                    'UPDATE admins SET username = ?, email = ?, full_name = ?, role = ?, is_active = ? WHERE id = ?',
                    [$username, $email, $fullName, $role, $isActive, $editId]
                );
            }
        } else {
            if (empty($password)) {
                set_flash('danger', 'Yeni kullanıcı için şifre zorunludur.');
                redirect('admins.php?action=add');
            }
            if (strlen($password) < 8) {
                set_flash('danger', 'Şifre en az 8 karakter olmalıdır.');
                redirect('admins.php?action=add');
            }

            $dupUser = db_fetch($pdo, 'SELECT id FROM admins WHERE username = ?', [$username]);
            $dupEmail = db_fetch($pdo, 'SELECT id FROM admins WHERE email = ?', [$email]);
            if ($dupUser || $dupEmail) {
                set_flash('danger', 'Kullanıcı adı veya e-posta zaten kullanılıyor.');
                redirect('admins.php?action=add');
            }

            $hash = password_hash($password, PASSWORD_DEFAULT);
            db_execute($pdo,
                'INSERT INTO admins (username, email, password, full_name, role, is_active) VALUES (?, ?, ?, ?, ?, ?)',
                [$username, $email, $hash, $fullName, $role, $isActive]
            );
        }

        admin_log($pdo, 'save_admin', 'Admin kaydedildi: ' . $username);
        set_flash('success', 'Yönetici başarıyla kaydedildi.');
        redirect('admins.php');
    }
}

$admin = null;
if ($action === 'edit' && $id > 0) {
    $admin = db_fetch($pdo, 'SELECT * FROM admins WHERE id = ?', [$id]);
    if (!$admin) {
        set_flash('danger', 'Kullanıcı bulunamadı.');
        redirect('admins.php');
    }
}

$admins = db_fetch_all($pdo, 'SELECT * FROM admins ORDER BY created_at DESC');

require __DIR__ . '/includes/header.php';
?>

<?php if ($action === 'add' || $action === 'edit'): ?>
<div class="admin-card">
    <div class="admin-card-header d-flex justify-content-between align-items-center">
        <h2 class="h6 mb-0"><?= $action === 'edit' ? 'Yönetici Düzenle' : 'Yeni Yönetici' ?></h2>
        <a href="admins.php" class="btn btn-sm btn-outline-secondary"><i class="bi bi-arrow-left"></i> Geri</a>
    </div>
    <div class="admin-card-body">
        <form method="post">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="save">
            <input type="hidden" name="id" value="<?= (int) ($admin['id'] ?? 0) ?>">

            <div class="row g-3">
                <div class="col-md-6">
                    <label class="form-label">Kullanıcı Adı *</label>
                    <input type="text" class="form-control" name="username" value="<?= e($admin['username'] ?? '') ?>" required>
                </div>
                <div class="col-md-6">
                    <label class="form-label">E-posta *</label>
                    <input type="email" class="form-control" name="email" value="<?= e($admin['email'] ?? '') ?>" required>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Ad Soyad *</label>
                    <input type="text" class="form-control" name="full_name" value="<?= e($admin['full_name'] ?? '') ?>" required>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Rol</label>
                    <select class="form-select" name="role">
                        <?php foreach ($roles as $val => $label): ?>
                        <option value="<?= e($val) ?>" <?= ($admin['role'] ?? 'admin') === $val ? 'selected' : '' ?>><?= e($label) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Şifre <?= $action === 'add' ? '*' : '(değiştirmek için doldurun)' ?></label>
                    <input type="password" class="form-control" name="password" <?= $action === 'add' ? 'required' : '' ?> minlength="8">
                </div>
                <div class="col-md-6 d-flex align-items-end">
                    <div class="form-check form-switch">
                        <input class="form-check-input" type="checkbox" name="is_active" id="is_active" <?= ($admin['is_active'] ?? 1) ? 'checked' : '' ?>>
                        <label class="form-check-label" for="is_active">Aktif</label>
                    </div>
                </div>
            </div>

            <button type="submit" class="btn btn-primary mt-4"><i class="bi bi-check-lg"></i> Kaydet</button>
        </form>
    </div>
</div>

<?php else: ?>
<div class="admin-card">
    <div class="admin-card-header d-flex justify-content-between align-items-center">
        <h2 class="h6 mb-0">Yönetici Listesi</h2>
        <a href="admins.php?action=add" class="btn btn-sm btn-primary"><i class="bi bi-plus-lg"></i> Yeni Yönetici</a>
    </div>
    <div class="admin-card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover mb-0">
                <thead>
                    <tr>
                        <th>Kullanıcı Adı</th>
                        <th>Ad Soyad</th>
                        <th>E-posta</th>
                        <th>Rol</th>
                        <th>Son Giriş</th>
                        <th>Durum</th>
                        <th width="120">İşlemler</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($admins as $a): ?>
                    <tr>
                        <td><?= e($a['username']) ?></td>
                        <td><?= e($a['full_name']) ?></td>
                        <td><?= e($a['email']) ?></td>
                        <td><span class="badge bg-info"><?= e($roles[$a['role']] ?? $a['role']) ?></span></td>
                        <td><?= $a['last_login'] ? format_date($a['last_login'], 'd.m.Y H:i') : '-' ?></td>
                        <td><?= $a['is_active'] ? '<span class="badge bg-success">Aktif</span>' : '<span class="badge bg-secondary">Pasif</span>' ?></td>
                        <td>
                            <a href="admins.php?action=edit&id=<?= $a['id'] ?>" class="btn btn-sm btn-outline-primary btn-action"><i class="bi bi-pencil"></i></a>
                            <?php if ($a['id'] !== (int) $_SESSION['admin_id']): ?>
                            <form method="post" action="admins.php?action=delete&id=<?= $a['id'] ?>" class="d-inline" onsubmit="return confirm('Bu yönetici silinsin mi?')">
                                <?= csrf_field() ?>
                                <input type="hidden" name="action" value="delete">
                                <button type="submit" class="btn btn-sm btn-outline-danger btn-action"><i class="bi bi-trash"></i></button>
                            </form>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php endif; ?>

<?php require __DIR__ . '/includes/footer.php'; ?>
