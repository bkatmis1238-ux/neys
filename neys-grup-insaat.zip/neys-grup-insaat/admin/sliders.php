<?php
/**
 * Slider Yönetimi
 */
require_once dirname(__DIR__) . '/config/bootstrap.php';
require_once __DIR__ . '/includes/helpers.php';

require_admin();

$pageTitle = 'Slider Yönetimi';
$currentAdminPage = 'sliders';
$languages = admin_languages($pdo);
$action = get_param('action', 'list');
$id = (int) get_param('id', 0);

if (is_post()) {
    if (!verify_csrf(post_param('csrf_token'))) {
        set_flash('danger', 'Güvenlik doğrulaması başarısız.');
        redirect('sliders.php');
    }

    $postAction = post_param('action');

    if ($postAction === 'delete' && $id > 0) {
        $slider = db_fetch($pdo, 'SELECT * FROM sliders WHERE id = ?', [$id]);
        if ($slider) {
            admin_delete_file($slider['image']);
            db_execute($pdo, 'DELETE FROM sliders WHERE id = ?', [$id]);
            admin_log($pdo, 'delete_slider', 'Slider silindi: #' . $id);
            set_flash('success', 'Slider başarıyla silindi.');
        }
        redirect('sliders.php');
    }

    if ($postAction === 'save') {
        $sortOrder = (int) post_param('sort_order', 0);
        $isActive = isset($_POST['is_active']) ? 1 : 0;
        $editId = (int) post_param('id', 0);

        try {
            $imagePath = null;
            if (!empty($_FILES['image']['name'])) {
                $imagePath = admin_upload_file($_FILES['image'], 'sliders', $appConfig['allowed_images'], $appConfig['max_upload']);
            }

            if ($editId > 0) {
                $existing = db_fetch($pdo, 'SELECT * FROM sliders WHERE id = ?', [$editId]);
                if (!$existing) {
                    set_flash('danger', 'Slider bulunamadı.');
                    redirect('sliders.php');
                }

                $finalImage = $imagePath ?? $existing['image'];
                if ($imagePath && $existing['image']) {
                    admin_delete_file($existing['image']);
                }

                db_execute($pdo,
                    'UPDATE sliders SET image = ?, sort_order = ?, is_active = ? WHERE id = ?',
                    [$finalImage, $sortOrder, $isActive, $editId]
                );
                $sliderId = $editId;
            } else {
                if (!$imagePath) {
                    set_flash('danger', 'Slider görseli zorunludur.');
                    redirect('sliders.php?action=add');
                }
                db_execute($pdo,
                    'INSERT INTO sliders (image, sort_order, is_active) VALUES (?, ?, ?)',
                    [$imagePath, $sortOrder, $isActive]
                );
                $sliderId = (int) db_last_id($pdo);
            }

            foreach ($languages as $lang) {
                $langId = (int) $lang['id'];
                $title = post_param('title_' . $langId, '');
                $subtitle = post_param('subtitle_' . $langId, '');
                $buttonText = post_param('button_text_' . $langId, '');
                $buttonLink = post_param('button_link_' . $langId, '');

                $trans = db_fetch($pdo,
                    'SELECT id FROM slider_translations WHERE slider_id = ? AND language_id = ?',
                    [$sliderId, $langId]
                );

                if ($trans) {
                    db_execute($pdo,
                        'UPDATE slider_translations SET title = ?, subtitle = ?, button_text = ?, button_link = ? WHERE id = ?',
                        [$title, $subtitle, $buttonText, $buttonLink, $trans['id']]
                    );
                } else {
                    db_execute($pdo,
                        'INSERT INTO slider_translations (slider_id, language_id, title, subtitle, button_text, button_link) VALUES (?, ?, ?, ?, ?, ?)',
                        [$sliderId, $langId, $title, $subtitle, $buttonText, $buttonLink]
                    );
                }
            }

            admin_log($pdo, 'save_slider', 'Slider kaydedildi: #' . $sliderId);
            set_flash('success', 'Slider başarıyla kaydedildi.');
            redirect('sliders.php');
        } catch (RuntimeException $e) {
            set_flash('danger', $e->getMessage());
            redirect('sliders.php?action=' . ($editId ? 'edit&id=' . $editId : 'add'));
        }
    }
}

$slider = null;
$translations = [];
if ($action === 'edit' && $id > 0) {
    $slider = db_fetch($pdo, 'SELECT * FROM sliders WHERE id = ?', [$id]);
    if (!$slider) {
        set_flash('danger', 'Slider bulunamadı.');
        redirect('sliders.php');
    }
    $transRows = db_fetch_all($pdo, 'SELECT * FROM slider_translations WHERE slider_id = ?', [$id]);
    foreach ($transRows as $row) {
        $translations[$row['language_id']] = $row;
    }
}

$sliders = db_fetch_all($pdo,
    'SELECT s.*, st.title FROM sliders s
     LEFT JOIN slider_translations st ON st.slider_id = s.id AND st.language_id = 1
     ORDER BY s.sort_order ASC, s.id ASC'
);

require __DIR__ . '/includes/header.php';
?>

<?php if ($action === 'add' || $action === 'edit'): ?>
<div class="admin-card">
    <div class="admin-card-header d-flex justify-content-between align-items-center">
        <h2 class="h6 mb-0"><?= $action === 'edit' ? 'Slider Düzenle' : 'Yeni Slider' ?></h2>
        <a href="sliders.php" class="btn btn-sm btn-outline-secondary"><i class="bi bi-arrow-left"></i> Geri</a>
    </div>
    <div class="admin-card-body">
        <form method="post" enctype="multipart/form-data">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="save">
            <input type="hidden" name="id" value="<?= (int) ($slider['id'] ?? 0) ?>">

            <div class="row g-3 mb-4">
                <div class="col-md-4">
                    <label class="form-label">Görsel <?= $action === 'add' ? '*' : '' ?></label>
                    <?php if (!empty($slider['image'])): ?>
                    <div class="mb-2"><img src="<?= e(asset_url($slider['image'])) ?>" class="img-preview" alt=""></div>
                    <?php endif; ?>
                    <input type="file" class="form-control" name="image" accept="image/*" <?= $action === 'add' ? 'required' : '' ?>>
                </div>
                <div class="col-md-4">
                    <label class="form-label">Sıra</label>
                    <input type="number" class="form-control" name="sort_order" value="<?= (int) ($slider['sort_order'] ?? 0) ?>">
                </div>
                <div class="col-md-4 d-flex align-items-end">
                    <div class="form-check form-switch">
                        <input class="form-check-input" type="checkbox" name="is_active" id="is_active" <?= ($slider['is_active'] ?? 1) ? 'checked' : '' ?>>
                        <label class="form-check-label" for="is_active">Aktif</label>
                    </div>
                </div>
            </div>

            <ul class="nav nav-tabs lang-tabs mb-3" role="tablist">
                <?php foreach ($languages as $i => $lang): ?>
                <li class="nav-item">
                    <button class="nav-link <?= $i === 0 ? 'active' : '' ?>" data-bs-toggle="tab" data-bs-target="#lang-<?= $lang['id'] ?>" type="button">
                        <?= e($lang['flag']) ?> <?= e($lang['native_name']) ?>
                    </button>
                </li>
                <?php endforeach; ?>
            </ul>

            <div class="tab-content">
                <?php foreach ($languages as $i => $lang): ?>
                <?php $t = $translations[$lang['id']] ?? []; ?>
                <div class="tab-pane fade <?= $i === 0 ? 'show active' : '' ?>" id="lang-<?= $lang['id'] ?>">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label">Başlık *</label>
                            <input type="text" class="form-control" name="title_<?= $lang['id'] ?>" value="<?= e($t['title'] ?? '') ?>" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Buton Metni</label>
                            <input type="text" class="form-control" name="button_text_<?= $lang['id'] ?>" value="<?= e($t['button_text'] ?? '') ?>">
                        </div>
                        <div class="col-12">
                            <label class="form-label">Alt Başlık</label>
                            <textarea class="form-control" name="subtitle_<?= $lang['id'] ?>" rows="2"><?= e($t['subtitle'] ?? '') ?></textarea>
                        </div>
                        <div class="col-12">
                            <label class="form-label">Buton Linki</label>
                            <input type="text" class="form-control" name="button_link_<?= $lang['id'] ?>" value="<?= e($t['button_link'] ?? '') ?>">
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>

            <div class="mt-4">
                <button type="submit" class="btn btn-primary"><i class="bi bi-check-lg"></i> Kaydet</button>
            </div>
        </form>
    </div>
</div>

<?php else: ?>
<div class="admin-card">
    <div class="admin-card-header d-flex justify-content-between align-items-center">
        <h2 class="h6 mb-0">Slider Listesi</h2>
        <a href="sliders.php?action=add" class="btn btn-sm btn-primary"><i class="bi bi-plus-lg"></i> Yeni Slider</a>
    </div>
    <div class="admin-card-body p-0">
        <?php if (empty($sliders)): ?>
        <div class="empty-state"><i class="bi bi-images d-block"></i><p>Henüz slider eklenmemiş.</p></div>
        <?php else: ?>
        <div class="table-responsive">
            <table class="table table-hover mb-0">
                <thead>
                    <tr>
                        <th>Görsel</th>
                        <th>Başlık</th>
                        <th>Sıra</th>
                        <th>Durum</th>
                        <th width="120">İşlemler</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($sliders as $s): ?>
                    <tr>
                        <td><img src="<?= e(asset_url($s['image'])) ?>" class="img-preview-sm" alt=""></td>
                        <td><?= e($s['title'] ?? '-') ?></td>
                        <td><?= (int) $s['sort_order'] ?></td>
                        <td><?= $s['is_active'] ? '<span class="badge bg-success">Aktif</span>' : '<span class="badge bg-secondary">Pasif</span>' ?></td>
                        <td>
                            <a href="sliders.php?action=edit&id=<?= $s['id'] ?>" class="btn btn-sm btn-outline-primary btn-action"><i class="bi bi-pencil"></i></a>
                            <form method="post" action="sliders.php?action=delete&id=<?= $s['id'] ?>" class="d-inline" onsubmit="return confirm('Bu slider silinsin mi?')">
                                <?= csrf_field() ?>
                                <input type="hidden" name="action" value="delete">
                                <button type="submit" class="btn btn-sm btn-outline-danger btn-action"><i class="bi bi-trash"></i></button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php endif; ?>
    </div>
</div>
<?php endif; ?>

<?php require __DIR__ . '/includes/footer.php'; ?>
