<?php
/**
 * İstatistik Yönetimi
 */
require_once dirname(__DIR__) . '/config/bootstrap.php';
require_once __DIR__ . '/includes/helpers.php';

require_admin();

$pageTitle = 'İstatistikler';
$currentAdminPage = 'statistics';
$languages = admin_languages($pdo);
$action = get_param('action', 'list');
$id = (int) get_param('id', 0);

if (is_post()) {
    if (!verify_csrf(post_param('csrf_token'))) {
        set_flash('danger', 'Güvenlik doğrulaması başarısız.');
        redirect('statistics.php');
    }

    $postAction = post_param('action');
    $editId = (int) post_param('id', 0);

    if ($postAction === 'save' && $editId > 0) {
        $statValue = (int) post_param('stat_value', 0);
        $icon = post_param('icon', 'bi-graph-up');
        $sortOrder = (int) post_param('sort_order', 0);
        $isActive = isset($_POST['is_active']) ? 1 : 0;

        db_execute($pdo,
            'UPDATE statistics SET stat_value = ?, icon = ?, sort_order = ?, is_active = ? WHERE id = ?',
            [$statValue, $icon, $sortOrder, $isActive, $editId]
        );

        foreach ($languages as $lang) {
            $langId = (int) $lang['id'];
            $label = post_param('label_' . $langId, '');

            $trans = db_fetch($pdo,
                'SELECT id FROM statistic_translations WHERE statistic_id = ? AND language_id = ?',
                [$editId, $langId]
            );

            if ($trans) {
                db_execute($pdo, 'UPDATE statistic_translations SET label = ? WHERE id = ?', [$label, $trans['id']]);
            } else {
                db_execute($pdo,
                    'INSERT INTO statistic_translations (statistic_id, language_id, label) VALUES (?, ?, ?)',
                    [$editId, $langId, $label]
                );
            }
        }

        admin_log($pdo, 'save_statistic', 'İstatistik güncellendi: #' . $editId);
        set_flash('success', 'İstatistik kaydedildi.');
        redirect('statistics.php');
    }
}

$statistic = null;
$translations = [];
if ($action === 'edit' && $id > 0) {
    $statistic = db_fetch($pdo, 'SELECT * FROM statistics WHERE id = ?', [$id]);
    if (!$statistic) {
        set_flash('danger', 'İstatistik bulunamadı.');
        redirect('statistics.php');
    }
    $transRows = db_fetch_all($pdo, 'SELECT * FROM statistic_translations WHERE statistic_id = ?', [$id]);
    foreach ($transRows as $row) {
        $translations[$row['language_id']] = $row;
    }
}

$statistics = db_fetch_all($pdo,
    'SELECT s.*, st.label FROM statistics s
     LEFT JOIN statistic_translations st ON st.statistic_id = s.id AND st.language_id = 1
     ORDER BY s.sort_order ASC'
);

require __DIR__ . '/includes/header.php';
?>

<?php if ($action === 'edit' && $statistic): ?>
<div class="admin-card">
    <div class="admin-card-header d-flex justify-content-between align-items-center">
        <h2 class="h6 mb-0">İstatistik Düzenle — <?= e($statistic['stat_key']) ?></h2>
        <a href="statistics.php" class="btn btn-sm btn-outline-secondary"><i class="bi bi-arrow-left"></i> Geri</a>
    </div>
    <div class="admin-card-body">
        <form method="post">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="save">
            <input type="hidden" name="id" value="<?= $statistic['id'] ?>">

            <div class="row g-3 mb-4">
                <div class="col-md-3">
                    <label class="form-label">Değer</label>
                    <input type="number" class="form-control" name="stat_value" value="<?= (int) $statistic['stat_value'] ?>" min="0">
                </div>
                <div class="col-md-3">
                    <label class="form-label">İkon</label>
                    <input type="text" class="form-control" name="icon" value="<?= e($statistic['icon']) ?>" placeholder="bi-check-circle">
                </div>
                <div class="col-md-3">
                    <label class="form-label">Sıra</label>
                    <input type="number" class="form-control" name="sort_order" value="<?= (int) $statistic['sort_order'] ?>">
                </div>
                <div class="col-md-3 d-flex align-items-end">
                    <div class="form-check form-switch">
                        <input class="form-check-input" type="checkbox" name="is_active" id="is_active" <?= $statistic['is_active'] ? 'checked' : '' ?>>
                        <label class="form-check-label" for="is_active">Aktif</label>
                    </div>
                </div>
            </div>

            <?php foreach ($languages as $lang): ?>
            <?php $t = $translations[$lang['id']] ?? []; ?>
            <div class="mb-3">
                <label class="form-label"><?= e($lang['flag']) ?> <?= e($lang['native_name']) ?> — Etiket</label>
                <input type="text" class="form-control" name="label_<?= $lang['id'] ?>" value="<?= e($t['label'] ?? '') ?>">
            </div>
            <?php endforeach; ?>

            <button type="submit" class="btn btn-primary"><i class="bi bi-check-lg"></i> Kaydet</button>
        </form>
    </div>
</div>

<?php else: ?>
<div class="admin-card">
    <div class="admin-card-header">
        <h2 class="h6 mb-0">İstatistik Listesi</h2>
    </div>
    <div class="admin-card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover mb-0">
                <thead>
                    <tr>
                        <th>İkon</th>
                        <th>Anahtar</th>
                        <th>Etiket</th>
                        <th>Değer</th>
                        <th>Sıra</th>
                        <th>Durum</th>
                        <th width="80">İşlem</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($statistics as $s): ?>
                    <tr>
                        <td><i class="bi <?= e($s['icon']) ?> fs-5"></i></td>
                        <td><code><?= e($s['stat_key']) ?></code></td>
                        <td><?= e($s['label'] ?? '-') ?></td>
                        <td><strong><?= number_format((int) $s['stat_value']) ?></strong></td>
                        <td><?= (int) $s['sort_order'] ?></td>
                        <td><?= $s['is_active'] ? '<span class="badge bg-success">Aktif</span>' : '<span class="badge bg-secondary">Pasif</span>' ?></td>
                        <td>
                            <a href="statistics.php?action=edit&id=<?= $s['id'] ?>" class="btn btn-sm btn-outline-primary btn-action"><i class="bi bi-pencil"></i></a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php endif; ?>

<?php require __DIR__ . '/includes/footer.php'; ?>
