<?php
/**
 * Dil Yönetimi
 */
require_once dirname(__DIR__) . '/config/bootstrap.php';
require_once __DIR__ . '/includes/helpers.php';

require_admin();

$pageTitle = 'Dil Yönetimi';
$currentAdminPage = 'languages';
$action = get_param('action', 'list');
$id = (int) get_param('id', 0);

if (is_post()) {
    if (!verify_csrf(post_param('csrf_token'))) {
        set_flash('danger', 'Güvenlik doğrulaması başarısız.');
        redirect('languages.php');
    }

    $postAction = post_param('action');

    if ($postAction === 'delete' && $id > 0) {
        $lang = db_fetch($pdo, 'SELECT * FROM languages WHERE id = ?', [$id]);
        if ($lang && !$lang['is_default']) {
            db_execute($pdo, 'DELETE FROM languages WHERE id = ?', [$id]);
            admin_log($pdo, 'delete_language', 'Dil silindi: ' . $lang['code']);
            set_flash('success', 'Dil silindi.');
        } else {
            set_flash('danger', 'Varsayılan dil silinemez.');
        }
        redirect('languages.php');
    }

    if ($postAction === 'save') {
        $editId = (int) post_param('id', 0);
        $code = strtolower(post_param('code', ''));
        $name = post_param('name', '');
        $nativeName = post_param('native_name', '');
        $flag = post_param('flag', '');
        $sortOrder = (int) post_param('sort_order', 0);
        $isActive = isset($_POST['is_active']) ? 1 : 0;
        $isDefault = isset($_POST['is_default']) ? 1 : 0;

        if (empty($code) || empty($name) || empty($nativeName)) {
            set_flash('danger', 'Tüm zorunlu alanları doldurun.');
            redirect('languages.php?action=' . ($editId ? 'edit&id=' . $editId : 'add'));
        }

        if ($isDefault) {
            db_execute($pdo, 'UPDATE languages SET is_default = 0');
        }

        if ($editId > 0) {
            db_execute($pdo,
                'UPDATE languages SET code = ?, name = ?, native_name = ?, flag = ?, is_default = ?, is_active = ?, sort_order = ? WHERE id = ?',
                [$code, $name, $nativeName, $flag, $isDefault, $isActive, $sortOrder, $editId]
            );
        } else {
            $existing = db_fetch($pdo, 'SELECT id FROM languages WHERE code = ?', [$code]);
            if ($existing) {
                set_flash('danger', 'Bu dil kodu zaten mevcut.');
                redirect('languages.php?action=add');
            }
            db_execute($pdo,
                'INSERT INTO languages (code, name, native_name, flag, is_default, is_active, sort_order) VALUES (?, ?, ?, ?, ?, ?, ?)',
                [$code, $name, $nativeName, $flag, $isDefault, $isActive, $sortOrder]
            );
        }

        admin_log($pdo, 'save_language', 'Dil kaydedildi: ' . $code);
        set_flash('success', 'Dil başarıyla kaydedildi.');
        redirect('languages.php');
    }
}

$language = null;
if ($action === 'edit' && $id > 0) {
    $language = db_fetch($pdo, 'SELECT * FROM languages WHERE id = ?', [$id]);
    if (!$language) {
        set_flash('danger', 'Dil bulunamadı.');
        redirect('languages.php');
    }
}

$languages = db_fetch_all($pdo, 'SELECT * FROM languages ORDER BY sort_order ASC, id ASC');

require __DIR__ . '/includes/header.php';
?>

<?php if ($action === 'add' || $action === 'edit'): ?>
<div class="admin-card">
    <div class="admin-card-header d-flex justify-content-between align-items-center">
        <h2 class="h6 mb-0"><?= $action === 'edit' ? 'Dil Düzenle' : 'Yeni Dil' ?></h2>
        <a href="languages.php" class="btn btn-sm btn-outline-secondary"><i class="bi bi-arrow-left"></i> Geri</a>
    </div>
    <div class="admin-card-body">
        <form method="post">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="save">
            <input type="hidden" name="id" value="<?= (int) ($language['id'] ?? 0) ?>">

            <div class="row g-3">
                <div class="col-md-3">
                    <label class="form-label">Kod *</label>
                    <input type="text" class="form-control" name="code" value="<?= e($language['code'] ?? '') ?>" required maxlength="5" placeholder="tr">
                </div>
                <div class="col-md-3">
                    <label class="form-label">Ad *</label>
                    <input type="text" class="form-control" name="name" value="<?= e($language['name'] ?? '') ?>" required>
                </div>
                <div class="col-md-3">
                    <label class="form-label">Yerel Ad *</label>
                    <input type="text" class="form-control" name="native_name" value="<?= e($language['native_name'] ?? '') ?>" required>
                </div>
                <div class="col-md-3">
                    <label class="form-label">Bayrak</label>
                    <input type="text" class="form-control" name="flag" value="<?= e($language['flag'] ?? '') ?>" placeholder="🇹🇷">
                </div>
                <div class="col-md-3">
                    <label class="form-label">Sıra</label>
                    <input type="number" class="form-control" name="sort_order" value="<?= (int) ($language['sort_order'] ?? 0) ?>">
                </div>
                <div class="col-md-3 d-flex align-items-end">
                    <div class="form-check form-switch">
                        <input class="form-check-input" type="checkbox" name="is_active" id="is_active" <?= ($language['is_active'] ?? 1) ? 'checked' : '' ?>>
                        <label class="form-check-label" for="is_active">Aktif</label>
                    </div>
                </div>
                <div class="col-md-3 d-flex align-items-end">
                    <div class="form-check form-switch">
                        <input class="form-check-input" type="checkbox" name="is_default" id="is_default" <?= ($language['is_default'] ?? 0) ? 'checked' : '' ?>>
                        <label class="form-check-label" for="is_default">Varsayılan</label>
                    </div>
                </div>
            </div>

            <button type="submit" class="btn btn-primary mt-4"><i class="bi bi-check-lg"></i> Kaydet</button>
        </form>
    </div>
</div>

<?php else: ?>
<div class="admin-card">
    <div class="admin-card-header d-flex justify-content-between align-items-center">
        <h2 class="h6 mb-0">Dil Listesi</h2>
        <a href="languages.php?action=add" class="btn btn-sm btn-primary"><i class="bi bi-plus-lg"></i> Yeni Dil</a>
    </div>
    <div class="admin-card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover mb-0">
                <thead>
                    <tr>
                        <th>Bayrak</th>
                        <th>Kod</th>
                        <th>Ad</th>
                        <th>Yerel Ad</th>
                        <th>Sıra</th>
                        <th>Varsayılan</th>
                        <th>Durum</th>
                        <th width="120">İşlemler</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($languages as $lang): ?>
                    <tr>
                        <td><?= e($lang['flag']) ?></td>
                        <td><code><?= e($lang['code']) ?></code></td>
                        <td><?= e($lang['name']) ?></td>
                        <td><?= e($lang['native_name']) ?></td>
                        <td><?= (int) $lang['sort_order'] ?></td>
                        <td><?= $lang['is_default'] ? '<span class="badge bg-primary">Varsayılan</span>' : '-' ?></td>
                        <td><?= $lang['is_active'] ? '<span class="badge bg-success">Aktif</span>' : '<span class="badge bg-secondary">Pasif</span>' ?></td>
                        <td>
                            <a href="languages.php?action=edit&id=<?= $lang['id'] ?>" class="btn btn-sm btn-outline-primary btn-action"><i class="bi bi-pencil"></i></a>
                            <?php if (!$lang['is_default']): ?>
                            <form method="post" action="languages.php?action=delete&id=<?= $lang['id'] ?>" class="d-inline" onsubmit="return confirm('Bu dil silinsin mi?')">
                                <?= csrf_field() ?>
                                <input type="hidden" name="action" value="delete">
                                <button type="submit" class="btn btn-sm btn-outline-danger btn-action"><i class="bi bi-trash"></i></button>
                            </form>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php endif; ?>

<?php require __DIR__ . '/includes/footer.php'; ?>
