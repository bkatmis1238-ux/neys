<?php
/**
 * Hizmet Yönetimi
 */
require_once dirname(__DIR__) . '/config/bootstrap.php';
require_once __DIR__ . '/includes/helpers.php';

require_admin();

$pageTitle = 'Hizmet Yönetimi';
$currentAdminPage = 'services';
$languages = admin_languages($pdo);
$action = get_param('action', 'list');
$id = (int) get_param('id', 0);

if (is_post()) {
    if (!verify_csrf(post_param('csrf_token'))) {
        set_flash('danger', 'Güvenlik doğrulaması başarısız.');
        redirect('services.php');
    }

    $postAction = post_param('action');

    if ($postAction === 'delete' && $id > 0) {
        $service = db_fetch($pdo, 'SELECT * FROM services WHERE id = ?', [$id]);
        if ($service) {
            admin_delete_file($service['image']);
            db_execute($pdo, 'DELETE FROM services WHERE id = ?', [$id]);
            admin_log($pdo, 'delete_service', 'Hizmet silindi: #' . $id);
            set_flash('success', 'Hizmet başarıyla silindi.');
        }
        redirect('services.php');
    }

    if ($postAction === 'save') {
        $icon = post_param('icon', 'bi-building');
        $sortOrder = (int) post_param('sort_order', 0);
        $isActive = isset($_POST['is_active']) ? 1 : 0;
        $editId = (int) post_param('id', 0);

        try {
            $imagePath = null;
            if (!empty($_FILES['image']['name'])) {
                $imagePath = admin_upload_file($_FILES['image'], 'services', $appConfig['allowed_images'], $appConfig['max_upload']);
            }

            if ($editId > 0) {
                $existing = db_fetch($pdo, 'SELECT * FROM services WHERE id = ?', [$editId]);
                if (!$existing) {
                    set_flash('danger', 'Hizmet bulunamadı.');
                    redirect('services.php');
                }

                $finalImage = $imagePath ?? $existing['image'];
                if ($imagePath && $existing['image']) {
                    admin_delete_file($existing['image']);
                }

                db_execute($pdo,
                    'UPDATE services SET icon = ?, image = ?, sort_order = ?, is_active = ? WHERE id = ?',
                    [$icon, $finalImage, $sortOrder, $isActive, $editId]
                );
                $serviceId = $editId;
            } else {
                db_execute($pdo,
                    'INSERT INTO services (icon, image, sort_order, is_active) VALUES (?, ?, ?, ?)',
                    [$icon, $imagePath, $sortOrder, $isActive]
                );
                $serviceId = (int) db_last_id($pdo);
            }

            foreach ($languages as $lang) {
                $langId = (int) $lang['id'];
                $title = post_param('title_' . $langId, '');
                $shortDesc = post_param('short_description_' . $langId, '');
                $description = post_param('description_' . $langId, '');
                $slug = post_param('slug_' . $langId, '') ?: create_slug($title);

                $trans = db_fetch($pdo,
                    'SELECT id FROM service_translations WHERE service_id = ? AND language_id = ?',
                    [$serviceId, $langId]
                );

                if ($trans) {
                    db_execute($pdo,
                        'UPDATE service_translations SET title = ?, short_description = ?, description = ?, slug = ? WHERE id = ?',
                        [$title, $shortDesc, $description, $slug, $trans['id']]
                    );
                } else {
                    db_execute($pdo,
                        'INSERT INTO service_translations (service_id, language_id, title, short_description, description, slug) VALUES (?, ?, ?, ?, ?, ?)',
                        [$serviceId, $langId, $title, $shortDesc, $description, $slug]
                    );
                }
            }

            admin_log($pdo, 'save_service', 'Hizmet kaydedildi: #' . $serviceId);
            set_flash('success', 'Hizmet başarıyla kaydedildi.');
            redirect('services.php');
        } catch (RuntimeException $e) {
            set_flash('danger', $e->getMessage());
            redirect('services.php?action=' . ($editId ? 'edit&id=' . $editId : 'add'));
        }
    }
}

$service = null;
$translations = [];
if ($action === 'edit' && $id > 0) {
    $service = db_fetch($pdo, 'SELECT * FROM services WHERE id = ?', [$id]);
    if (!$service) {
        set_flash('danger', 'Hizmet bulunamadı.');
        redirect('services.php');
    }
    $transRows = db_fetch_all($pdo, 'SELECT * FROM service_translations WHERE service_id = ?', [$id]);
    foreach ($transRows as $row) {
        $translations[$row['language_id']] = $row;
    }
}

$services = db_fetch_all($pdo,
    'SELECT s.*, st.title FROM services s
     LEFT JOIN service_translations st ON st.service_id = s.id AND st.language_id = 1
     ORDER BY s.sort_order ASC, s.id ASC'
);

require __DIR__ . '/includes/header.php';
?>

<?php if ($action === 'add' || $action === 'edit'): ?>
<div class="admin-card">
    <div class="admin-card-header d-flex justify-content-between align-items-center">
        <h2 class="h6 mb-0"><?= $action === 'edit' ? 'Hizmet Düzenle' : 'Yeni Hizmet' ?></h2>
        <a href="services.php" class="btn btn-sm btn-outline-secondary"><i class="bi bi-arrow-left"></i> Geri</a>
    </div>
    <div class="admin-card-body">
        <form method="post" enctype="multipart/form-data">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="save">
            <input type="hidden" name="id" value="<?= (int) ($service['id'] ?? 0) ?>">

            <div class="row g-3 mb-4">
                <div class="col-md-3">
                    <label class="form-label">İkon (Bootstrap Icons)</label>
                    <input type="text" class="form-control" name="icon" value="<?= e($service['icon'] ?? 'bi-building') ?>" placeholder="bi-building">
                </div>
                <div class="col-md-3">
                    <label class="form-label">Sıra</label>
                    <input type="number" class="form-control" name="sort_order" value="<?= (int) ($service['sort_order'] ?? 0) ?>">
                </div>
                <div class="col-md-3">
                    <label class="form-label">Görsel</label>
                    <?php if (!empty($service['image'])): ?>
                    <div class="mb-2"><img src="<?= e(asset_url($service['image'])) ?>" class="img-preview" alt=""></div>
                    <?php endif; ?>
                    <input type="file" class="form-control" name="image" accept="image/*">
                </div>
                <div class="col-md-3 d-flex align-items-end">
                    <div class="form-check form-switch">
                        <input class="form-check-input" type="checkbox" name="is_active" id="is_active" <?= ($service['is_active'] ?? 1) ? 'checked' : '' ?>>
                        <label class="form-check-label" for="is_active">Aktif</label>
                    </div>
                </div>
            </div>

            <ul class="nav nav-tabs lang-tabs mb-3" role="tablist">
                <?php foreach ($languages as $i => $lang): ?>
                <li class="nav-item">
                    <button class="nav-link <?= $i === 0 ? 'active' : '' ?>" data-bs-toggle="tab" data-bs-target="#lang-<?= $lang['id'] ?>" type="button">
                        <?= e($lang['flag']) ?> <?= e($lang['native_name']) ?>
                    </button>
                </li>
                <?php endforeach; ?>
            </ul>

            <div class="tab-content">
                <?php foreach ($languages as $i => $lang): ?>
                <?php $t = $translations[$lang['id']] ?? []; ?>
                <div class="tab-pane fade <?= $i === 0 ? 'show active' : '' ?>" id="lang-<?= $lang['id'] ?>">
                    <div class="row g-3">
                        <div class="col-md-8">
                            <label class="form-label">Başlık *</label>
                            <input type="text" class="form-control" name="title_<?= $lang['id'] ?>" value="<?= e($t['title'] ?? '') ?>" required>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Slug</label>
                            <input type="text" class="form-control" name="slug_<?= $lang['id'] ?>" value="<?= e($t['slug'] ?? '') ?>">
                        </div>
                        <div class="col-12">
                            <label class="form-label">Kısa Açıklama</label>
                            <textarea class="form-control" name="short_description_<?= $lang['id'] ?>" rows="2"><?= e($t['short_description'] ?? '') ?></textarea>
                        </div>
                        <div class="col-12">
                            <label class="form-label">Detaylı Açıklama</label>
                            <textarea class="form-control" name="description_<?= $lang['id'] ?>" rows="5"><?= e($t['description'] ?? '') ?></textarea>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>

            <div class="mt-4">
                <button type="submit" class="btn btn-primary"><i class="bi bi-check-lg"></i> Kaydet</button>
            </div>
        </form>
    </div>
</div>

<?php else: ?>
<div class="admin-card">
    <div class="admin-card-header d-flex justify-content-between align-items-center">
        <h2 class="h6 mb-0">Hizmet Listesi</h2>
        <a href="services.php?action=add" class="btn btn-sm btn-primary"><i class="bi bi-plus-lg"></i> Yeni Hizmet</a>
    </div>
    <div class="admin-card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover mb-0">
                <thead>
                    <tr>
                        <th>İkon</th>
                        <th>Başlık</th>
                        <th>Sıra</th>
                        <th>Durum</th>
                        <th width="120">İşlemler</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($services as $s): ?>
                    <tr>
                        <td><i class="bi <?= e($s['icon']) ?> fs-5"></i></td>
                        <td><?= e($s['title'] ?? '-') ?></td>
                        <td><?= (int) $s['sort_order'] ?></td>
                        <td><?= $s['is_active'] ? '<span class="badge bg-success">Aktif</span>' : '<span class="badge bg-secondary">Pasif</span>' ?></td>
                        <td>
                            <a href="services.php?action=edit&id=<?= $s['id'] ?>" class="btn btn-sm btn-outline-primary btn-action"><i class="bi bi-pencil"></i></a>
                            <form method="post" action="services.php?action=delete&id=<?= $s['id'] ?>" class="d-inline" onsubmit="return confirm('Bu hizmet silinsin mi?')">
                                <?= csrf_field() ?>
                                <input type="hidden" name="action" value="delete">
                                <button type="submit" class="btn btn-sm btn-outline-danger btn-action"><i class="bi bi-trash"></i></button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php endif; ?>

<?php require __DIR__ . '/includes/footer.php'; ?>
