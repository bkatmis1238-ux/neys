<?php
/**
 * Yasal Sayfa Yönetimi (KVKK, Gizlilik, Çerez)
 */
require_once dirname(__DIR__) . '/config/bootstrap.php';
require_once __DIR__ . '/includes/helpers.php';

require_admin();

$pageTitle = 'Yasal Sayfalar';
$currentAdminPage = 'pages';
$languages = admin_languages($pdo);
$action = get_param('action', 'list');
$id = (int) get_param('id', 0);

$pageLabels = [
    'kvkk'    => 'KVKK Aydınlatma Metni',
    'privacy' => 'Gizlilik Politikası',
    'cookie'  => 'Çerez Politikası',
];

if (is_post()) {
    if (!verify_csrf(post_param('csrf_token'))) {
        set_flash('danger', 'Güvenlik doğrulaması başarısız.');
        redirect('pages.php');
    }

    $postAction = post_param('action');
    $editId = (int) post_param('id', 0);

    if ($postAction === 'save' && $editId > 0) {
        $isActive = isset($_POST['is_active']) ? 1 : 0;
        db_execute($pdo, 'UPDATE pages SET is_active = ? WHERE id = ?', [$isActive, $editId]);

        foreach ($languages as $lang) {
            $langId = (int) $lang['id'];
            $title = post_param('title_' . $langId, '');
            $slug = post_param('slug_' . $langId, '') ?: create_slug($title);
            $content = $_POST['content_' . $langId] ?? '';
            $metaTitle = post_param('meta_title_' . $langId, '');
            $metaDesc = post_param('meta_description_' . $langId, '');
            $metaKeywords = post_param('meta_keywords_' . $langId, '');

            $trans = db_fetch($pdo,
                'SELECT id FROM page_translations WHERE page_id = ? AND language_id = ?',
                [$editId, $langId]
            );

            if ($trans) {
                db_execute($pdo,
                    'UPDATE page_translations SET title = ?, slug = ?, content = ?, meta_title = ?, meta_description = ?, meta_keywords = ? WHERE id = ?',
                    [$title, $slug, $content, $metaTitle, $metaDesc, $metaKeywords, $trans['id']]
                );
            } else {
                db_execute($pdo,
                    'INSERT INTO page_translations (page_id, language_id, title, slug, content, meta_title, meta_description, meta_keywords) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
                    [$editId, $langId, $title, $slug, $content, $metaTitle, $metaDesc, $metaKeywords]
                );
            }
        }

        admin_log($pdo, 'save_page', 'Yasal sayfa güncellendi: #' . $editId);
        set_flash('success', 'Sayfa başarıyla kaydedildi.');
        redirect('pages.php');
    }
}

$page = null;
$translations = [];
if ($action === 'edit' && $id > 0) {
    $page = db_fetch($pdo, 'SELECT * FROM pages WHERE id = ?', [$id]);
    if (!$page) {
        set_flash('danger', 'Sayfa bulunamadı.');
        redirect('pages.php');
    }
    $transRows = db_fetch_all($pdo, 'SELECT * FROM page_translations WHERE page_id = ?', [$id]);
    foreach ($transRows as $row) {
        $translations[$row['language_id']] = $row;
    }
}

$pages = db_fetch_all($pdo,
    'SELECT p.*, pt.title FROM pages p
     LEFT JOIN page_translations pt ON pt.page_id = p.id AND pt.language_id = 1
     ORDER BY p.id ASC'
);

require __DIR__ . '/includes/header.php';
?>

<?php if ($action === 'edit' && $page): ?>
<div class="admin-card">
    <div class="admin-card-header d-flex justify-content-between align-items-center">
        <h2 class="h6 mb-0"><?= e($pageLabels[$page['page_key']] ?? $page['page_key']) ?> — Düzenle</h2>
        <a href="pages.php" class="btn btn-sm btn-outline-secondary"><i class="bi bi-arrow-left"></i> Geri</a>
    </div>
    <div class="admin-card-body">
        <form method="post">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="save">
            <input type="hidden" name="id" value="<?= $page['id'] ?>">

            <div class="mb-4">
                <div class="form-check form-switch">
                    <input class="form-check-input" type="checkbox" name="is_active" id="is_active" <?= $page['is_active'] ? 'checked' : '' ?>>
                    <label class="form-check-label" for="is_active">Aktif</label>
                </div>
            </div>

            <ul class="nav nav-tabs lang-tabs mb-3" role="tablist">
                <?php foreach ($languages as $i => $lang): ?>
                <li class="nav-item">
                    <button class="nav-link <?= $i === 0 ? 'active' : '' ?>" data-bs-toggle="tab" data-bs-target="#lang-<?= $lang['id'] ?>" type="button">
                        <?= e($lang['flag']) ?> <?= e($lang['native_name']) ?>
                    </button>
                </li>
                <?php endforeach; ?>
            </ul>

            <div class="tab-content">
                <?php foreach ($languages as $i => $lang): ?>
                <?php $t = $translations[$lang['id']] ?? []; ?>
                <div class="tab-pane fade <?= $i === 0 ? 'show active' : '' ?>" id="lang-<?= $lang['id'] ?>">
                    <div class="row g-3">
                        <div class="col-md-8">
                            <label class="form-label">Başlık *</label>
                            <input type="text" class="form-control" name="title_<?= $lang['id'] ?>" value="<?= e($t['title'] ?? '') ?>" required>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Slug</label>
                            <input type="text" class="form-control" name="slug_<?= $lang['id'] ?>" value="<?= e($t['slug'] ?? '') ?>">
                        </div>
                        <div class="col-12">
                            <label class="form-label">İçerik (HTML)</label>
                            <textarea class="form-control" name="content_<?= $lang['id'] ?>" rows="12"><?= e($t['content'] ?? '') ?></textarea>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Meta Başlık</label>
                            <input type="text" class="form-control" name="meta_title_<?= $lang['id'] ?>" value="<?= e($t['meta_title'] ?? '') ?>">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Meta Açıklama</label>
                            <input type="text" class="form-control" name="meta_description_<?= $lang['id'] ?>" value="<?= e($t['meta_description'] ?? '') ?>">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Meta Anahtar Kelimeler</label>
                            <input type="text" class="form-control" name="meta_keywords_<?= $lang['id'] ?>" value="<?= e($t['meta_keywords'] ?? '') ?>">
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>

            <button type="submit" class="btn btn-primary mt-4"><i class="bi bi-check-lg"></i> Kaydet</button>
        </form>
    </div>
</div>

<?php else: ?>
<div class="admin-card">
    <div class="admin-card-header">
        <h2 class="h6 mb-0">Yasal Sayfalar</h2>
    </div>
    <div class="admin-card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover mb-0">
                <thead>
                    <tr>
                        <th>Sayfa</th>
                        <th>Başlık</th>
                        <th>Durum</th>
                        <th width="80">İşlem</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($pages as $p): ?>
                    <tr>
                        <td><?= e($pageLabels[$p['page_key']] ?? $p['page_key']) ?></td>
                        <td><?= e($p['title'] ?? '-') ?></td>
                        <td><?= $p['is_active'] ? '<span class="badge bg-success">Aktif</span>' : '<span class="badge bg-secondary">Pasif</span>' ?></td>
                        <td>
                            <a href="pages.php?action=edit&id=<?= $p['id'] ?>" class="btn btn-sm btn-outline-primary btn-action"><i class="bi bi-pencil"></i></a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php endif; ?>

<?php require __DIR__ . '/includes/footer.php'; ?>
