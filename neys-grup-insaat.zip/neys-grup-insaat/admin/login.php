<?php
/**
 * Admin Giriş
 */
require_once dirname(__DIR__) . '/config/bootstrap.php';
require_once __DIR__ . '/includes/helpers.php';

if (is_admin_logged_in()) {
    redirect('index.php');
}

$error = '';

if (is_post()) {
    if (!verify_csrf(post_param('csrf_token'))) {
        $error = 'Güvenlik doğrulaması başarısız. Lütfen tekrar deneyin.';
    } elseif (!check_rate_limit('admin_login', 5, 300)) {
        $error = 'Çok fazla deneme yaptınız. Lütfen 5 dakika bekleyin.';
    } else {
        $username = post_param('username', '');
        $password = $_POST['password'] ?? '';

        $admin = db_fetch($pdo,
            'SELECT * FROM admins WHERE username = ? AND is_active = 1',
            [$username]
        );

        if ($admin && password_verify($password, $admin['password'])) {
            session_regenerate_id(true);
            $_SESSION['admin_id'] = $admin['id'];
            $_SESSION['admin_logged_in'] = true;
            $_SESSION['admin_username'] = $admin['username'];
            $_SESSION['admin_role'] = $admin['role'];
            $_SESSION['admin_name'] = $admin['full_name'];

            db_execute($pdo, 'UPDATE admins SET last_login = NOW() WHERE id = ?', [$admin['id']]);
            admin_log($pdo, 'login', 'Admin girişi: ' . $admin['username']);

            redirect('index.php');
        } else {
            $error = 'Kullanıcı adı veya şifre hatalı.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Giriş | Neys Grup Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <link href="assets/css/admin.css" rel="stylesheet">
</head>
<body class="login-page">
<div class="login-wrapper">
    <div class="login-card">
        <div class="login-header text-center mb-4">
            <div class="login-logo">
                <i class="bi bi-building-fill-gear"></i>
            </div>
            <h1 class="h4 mb-1">Neys Grup İnşaat</h1>
            <p class="text-muted mb-0">Yönetim Paneli</p>
        </div>

        <?php if ($error): ?>
        <div class="alert alert-danger"><?= e($error) ?></div>
        <?php endif; ?>

        <form method="post" action="">
            <?= csrf_field() ?>
            <div class="mb-3">
                <label for="username" class="form-label">Kullanıcı Adı</label>
                <div class="input-group">
                    <span class="input-group-text"><i class="bi bi-person"></i></span>
                    <input type="text" class="form-control" id="username" name="username" required autofocus
                           value="<?= e(post_param('username', '')) ?>">
                </div>
            </div>
            <div class="mb-4">
                <label for="password" class="form-label">Şifre</label>
                <div class="input-group">
                    <span class="input-group-text"><i class="bi bi-lock"></i></span>
                    <input type="password" class="form-control" id="password" name="password" required>
                    <button class="btn btn-outline-secondary" type="button" id="togglePassword" tabindex="-1">
                        <i class="bi bi-eye"></i>
                    </button>
                </div>
            </div>
            <button type="submit" class="btn btn-primary w-100">
                <i class="bi bi-box-arrow-in-right"></i> Giriş Yap
            </button>
        </form>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="assets/js/admin.js"></script>
</body>
</html>
