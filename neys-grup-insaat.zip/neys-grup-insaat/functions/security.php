<?php
/**
 * Güvenlik fonksiyonları - XSS, CSRF, SQL Injection koruması
 */

declare(strict_types=1);

/**
 * XSS koruması - HTML çıktısı temizle
 */
function e(?string $string): string
{
    return htmlspecialchars($string ?? '', ENT_QUOTES | ENT_HTML5, 'UTF-8');
}

/**
 * CSRF token doğrula
 */
function verify_csrf(?string $token): bool
{
    if (empty($token) || empty($_SESSION['csrf_token'])) {
        return false;
    }
    return hash_equals($_SESSION['csrf_token'], $token);
}

/**
 * CSRF token HTML input
 */
function csrf_field(): string
{
    return '<input type="hidden" name="csrf_token" value="' . e($_SESSION['csrf_token'] ?? '') . '">';
}

/**
 * CSRF token değeri
 */
function csrf_token(): string
{
    return $_SESSION['csrf_token'] ?? '';
}

/**
 * POST isteği mi?
 */
function is_post(): bool
{
    return $_SERVER['REQUEST_METHOD'] === 'POST';
}

/**
 * GET parametresi al (güvenli)
 */
function get_param(string $key, $default = null)
{
    return isset($_GET[$key]) ? sanitize_input($_GET[$key]) : $default;
}

/**
 * POST parametresi al (güvenli)
 */
function post_param(string $key, $default = null)
{
    return isset($_POST[$key]) ? sanitize_input($_POST[$key]) : $default;
}

/**
 * Girdi temizleme
 */
function sanitize_input($input)
{
    if (is_array($input)) {
        return array_map('sanitize_input', $input);
    }
    return trim(strip_tags((string) $input));
}

/**
 * E-posta doğrula
 */
function is_valid_email(string $email): bool
{
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
}

/**
 * Slug oluştur
 */
function create_slug(string $text): string
{
    $text = mb_strtolower($text, 'UTF-8');
    $tr = ['ş'=>'s','ğ'=>'g','ü'=>'u','ö'=>'o','ç'=>'c','ı'=>'i','Ş'=>'s','Ğ'=>'g','Ü'=>'u','Ö'=>'o','Ç'=>'c','İ'=>'i'];
    $text = strtr($text, $tr);
    $text = preg_replace('/[^a-z0-9\s-]/', '', $text);
    $text = preg_replace('/[\s-]+/', '-', $text);
    return trim($text, '-');
}

/**
 * Dosya yükleme güvenliği
 */
function validate_upload(array $file, array $allowed, int $maxSize): array
{
    $errors = [];

    if ($file['error'] !== UPLOAD_ERR_OK) {
        $errors[] = 'Dosya yükleme hatası.';
        return $errors;
    }

    if ($file['size'] > $maxSize) {
        $errors[] = 'Dosya boyutu çok büyük.';
    }

    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, $allowed, true)) {
        $errors[] = 'Geçersiz dosya türü.';
    }

    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime = finfo_file($finfo, $file['tmp_name']);
    finfo_close($finfo);

    $allowedMimes = [
        'jpg' => 'image/jpeg', 'jpeg' => 'image/jpeg', 'png' => 'image/png',
        'gif' => 'image/gif', 'webp' => 'image/webp', 'svg' => 'image/svg+xml',
        'pdf' => 'application/pdf'
    ];

    if (isset($allowedMimes[$ext]) && $mime !== $allowedMimes[$ext]) {
        $errors[] = 'Dosya içeriği geçersiz.';
    }

    return $errors;
}

/**
 * Güvenli dosya adı oluştur
 */
function safe_filename(string $original): string
{
    $ext = pathinfo($original, PATHINFO_EXTENSION);
    return uniqid('file_', true) . '.' . strtolower($ext);
}

/**
 * Admin oturum kontrolü
 */
function is_admin_logged_in(): bool
{
    return !empty($_SESSION['admin_id']) && !empty($_SESSION['admin_logged_in']);
}

/**
 * Admin oturum zorunluluğu
 */
function require_admin(): void
{
    if (!is_admin_logged_in()) {
        header('Location: login.php');
        exit;
    }
}

/**
 * Rate limiting (basit spam koruması)
 */
function check_rate_limit(string $key, int $maxAttempts = 5, int $window = 300): bool
{
    $now = time();
    if (!isset($_SESSION['rate_limit'][$key])) {
        $_SESSION['rate_limit'][$key] = ['count' => 0, 'start' => $now];
    }

    $data = &$_SESSION['rate_limit'][$key];

    if ($now - $data['start'] > $window) {
        $data = ['count' => 0, 'start' => $now];
    }

    $data['count']++;

    return $data['count'] <= $maxAttempts;
}

/**
 * Honeypot spam kontrolü
 */
function is_honeypot_triggered(): bool
{
    return !empty($_POST['website_url']);
}
