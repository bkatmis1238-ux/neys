<?php
/**
 * Genel yardımcı fonksiyonlar
 */

declare(strict_types=1);

/**
 * Çeviri kısayolu
 */
function __($key, array $replacements = []): string
{
    global $translations;
    $text = $translations[$key] ?? $key;
    foreach ($replacements as $search => $replace) {
        $text = str_replace(':' . $search, $replace, $text);
    }
    return $text;
}

/**
 * Site URL oluştur
 */
function site_url(string $path = ''): string
{
    global $appConfig, $currentLang;
    $base = rtrim($appConfig['url'], '/');

    if ($currentLang !== 'tr' && $path && !str_starts_with($path, 'http')) {
        $path = $currentLang . '/' . ltrim($path, '/');
    }

    return $path ? $base . '/' . ltrim($path, '/') : $base;
}

/**
 * Asset URL
 */
function asset_url(string $path): string
{
    global $appConfig;
    return rtrim($appConfig['url'], '/') . '/' . ltrim($path, '/');
}

/**
 * Aktif sayfa kontrolü
 */
function is_active_page(string $page): bool
{
    global $currentPage;
    return ($currentPage ?? '') === $page;
}

/**
 * Tarih formatla
 */
function format_date(?string $date, string $format = 'd.m.Y'): string
{
    if (!$date) return '-';
    return date($format, strtotime($date));
}

/**
 * Metin kısalt
 */
function truncate(string $text, int $length = 150): string
{
    if (mb_strlen($text) <= $length) return $text;
    return mb_substr($text, 0, $length) . '...';
}

/**
 * Breadcrumb oluştur
 */
function breadcrumb(array $items): string
{
    $html = '<nav aria-label="breadcrumb"><ol class="breadcrumb">';
    $html .= '<li class="breadcrumb-item"><a href="' . site_url() . '">' . e(__('breadcrumb_home')) . '</a></li>';

    $count = count($items);
    foreach ($items as $i => $item) {
        if ($i === $count - 1) {
            $html .= '<li class="breadcrumb-item active" aria-current="page">' . e($item['title']) . '</li>';
        } else {
            $html .= '<li class="breadcrumb-item"><a href="' . e($item['url']) . '">' . e($item['title']) . '</a></li>';
        }
    }

    $html .= '</ol></nav>';
    return $html;
}

/**
 * Flash mesaj ayarla
 */
function set_flash(string $type, string $message): void
{
    $_SESSION['flash'] = ['type' => $type, 'message' => $message];
}

/**
 * Flash mesaj al ve temizle
 */
function get_flash(): ?array
{
    if (empty($_SESSION['flash'])) return null;
    $flash = $_SESSION['flash'];
    unset($_SESSION['flash']);
    return $flash;
}

/**
 * JSON yanıt
 */
function json_response(array $data, int $code = 200): void
{
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

/**
 * Redirect
 */
function redirect(string $url): void
{
    header('Location: ' . $url);
    exit;
}

/**
 * Schema.org Organization JSON-LD
 */
function schema_organization(): string
{
    global $settings;
    $schema = [
        '@context' => 'https://schema.org',
        '@type' => 'Organization',
        'name' => $settings['site_name'] ?? 'Neys Grup İnşaat',
        'url' => site_url(),
        'logo' => asset_url($settings['logo'] ?? ''),
        'contactPoint' => [
            '@type' => 'ContactPoint',
            'telephone' => $settings['phone'] ?? '',
            'contactType' => 'customer service',
            'email' => $settings['email'] ?? '',
        ],
        'address' => [
            '@type' => 'PostalAddress',
            'addressLocality' => 'Ankara',
            'addressCountry' => 'TR',
        ],
    ];
    return '<script type="application/ld+json">' . json_encode($schema, JSON_UNESCAPED_UNICODE) . '</script>';
}

/**
 * YouTube embed URL düzenle
 */
function youtube_embed(string $url): string
{
    if (preg_match('/(?:youtube\.com\/(?:watch\?v=|embed\/)|youtu\.be\/)([a-zA-Z0-9_-]+)/', $url, $m)) {
        return 'https://www.youtube.com/embed/' . $m[1];
    }
    return $url;
}

/**
 * Proje durumu badge
 */
function status_badge(string $category): string
{
    $class = $category === 'ongoing' ? 'badge-ongoing' : 'badge-completed';
    $text  = $category === 'ongoing' ? __('status_ongoing') : __('status_completed');
    return '<span class="project-badge ' . $class . '">' . e($text) . '</span>';
}

/**
 * Admin log kaydı
 */
function admin_log(PDO $pdo, string $action, ?string $details = null): void
{
    if (!is_admin_logged_in()) return;
    db_execute($pdo,
        'INSERT INTO admin_logs (admin_id, action, details, ip_address) VALUES (?, ?, ?, ?)',
        [$_SESSION['admin_id'], $action, $details, $_SERVER['REMOTE_ADDR'] ?? '']
    );
}
