<?php
/**
 * Veritabanı bağlantı fonksiyonları
 */

declare(strict_types=1);

/**
 * PDO veritabanı bağlantısı oluştur
 */
function db_connect(array $config): PDO
{
    $dsn = sprintf(
        'mysql:host=%s;dbname=%s;charset=%s',
        $config['host'],
        $config['dbname'],
        $config['charset']
    );

    return new PDO($dsn, $config['username'], $config['password'], $config['options']);
}

/**
 * Tek satır sorgu
 */
function db_fetch(PDO $pdo, string $sql, array $params = []): ?array
{
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $result = $stmt->fetch();
    return $result ?: null;
}

/**
 * Çoklu satır sorgu
 */
function db_fetch_all(PDO $pdo, string $sql, array $params = []): array
{
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    return $stmt->fetchAll();
}

/**
 * INSERT/UPDATE/DELETE
 */
function db_execute(PDO $pdo, string $sql, array $params = []): bool
{
    $stmt = $pdo->prepare($sql);
    return $stmt->execute($params);
}

/**
 * Son eklenen ID
 */
function db_last_id(PDO $pdo): string
{
    return $pdo->lastInsertId();
}

/**
 * Satır sayısı
 */
function db_count(PDO $pdo, string $sql, array $params = []): int
{
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    return (int) $stmt->fetchColumn();
}
