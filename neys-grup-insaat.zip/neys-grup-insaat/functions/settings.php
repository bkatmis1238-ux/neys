<?php
/**
 * Site ayarları fonksiyonları
 */

declare(strict_types=1);

/**
 * Tüm ayarları yükle
 */
function load_settings(PDO $pdo): array
{
    $rows = db_fetch_all($pdo, 'SELECT setting_key, setting_value FROM settings');
    $settings = [];
    foreach ($rows as $row) {
        $settings[$row['setting_key']] = $row['setting_value'];
    }
    return $settings;
}

/**
 * Tek ayar al
 */
function get_setting(string $key, $default = null)
{
    global $settings;
    return $settings[$key] ?? $default;
}

/**
 * Ayar güncelle
 */
function update_setting(PDO $pdo, string $key, ?string $value): bool
{
    return db_execute($pdo,
        'UPDATE settings SET setting_value = ? WHERE setting_key = ?',
        [$value, $key]
    );
}

/**
 * SEO meta bilgilerini al
 */
function get_seo(PDO $pdo, string $pageKey, int $langId): ?array
{
    return db_fetch($pdo,
        'SELECT * FROM seo WHERE page_key = ? AND language_id = ?',
        [$pageKey, $langId]
    );
}
