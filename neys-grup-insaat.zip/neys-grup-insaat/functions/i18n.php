<?php
/**
 * Çoklu dil (i18n) fonksiyonları
 */

declare(strict_types=1);

/**
 * Dil tespiti - URL, session, cookie veya varsayılan
 */
function detect_language(array $appConfig): string
{
    $supported = $appConfig['supported_langs'];
    $default   = $appConfig['default_lang'];

    // URL'den dil tespiti (/en/, /ku/)
    $uri = trim(parse_url($_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH), '/');
    $parts = explode('/', $uri);
    if (!empty($parts[0]) && in_array($parts[0], $supported, true) && $parts[0] !== $default) {
        $_SESSION['lang'] = $parts[0];
        setcookie('neys_lang', $parts[0], time() + 86400 * 365, '/');
        return $parts[0];
    }

    // GET parametresi
    if (!empty($_GET['lang']) && in_array($_GET['lang'], $supported, true)) {
        $_SESSION['lang'] = $_GET['lang'];
        setcookie('neys_lang', $_GET['lang'], time() + 86400 * 365, '/');
        return $_GET['lang'];
    }

    // Session
    if (!empty($_SESSION['lang']) && in_array($_SESSION['lang'], $supported, true)) {
        return $_SESSION['lang'];
    }

    // Cookie
    if (!empty($_COOKIE['neys_lang']) && in_array($_COOKIE['neys_lang'], $supported, true)) {
        $_SESSION['lang'] = $_COOKIE['neys_lang'];
        return $_COOKIE['neys_lang'];
    }

    return $default;
}

/**
 * Dil ID'sini al
 */
function get_language_id(PDO $pdo, string $code): int
{
    $lang = db_fetch($pdo, 'SELECT id FROM languages WHERE code = ? AND is_active = 1', [$code]);
    return $lang ? (int) $lang['id'] : 1;
}

/**
 * Tüm çevirileri yükle
 */
function load_translations(PDO $pdo, int $langId): array
{
    $rows = db_fetch_all($pdo,
        'SELECT tk.`key`, t.value
         FROM translations t
         JOIN translation_keys tk ON t.key_id = tk.id
         WHERE t.language_id = ?',
        [$langId]
    );

    $translations = [];
    foreach ($rows as $row) {
        $translations[$row['key']] = $row['value'];
    }
    return $translations;
}

/**
 * Aktif dilleri al
 */
function get_active_languages(PDO $pdo): array
{
    return db_fetch_all($pdo,
        'SELECT * FROM languages WHERE is_active = 1 ORDER BY sort_order ASC'
    );
}

/**
 * Dil değiştirme URL'si
 */
function lang_url(string $langCode): string
{
    global $appConfig, $currentPage;

    $base = rtrim($appConfig['url'], '/');
    $page = $currentPage ?? '';

    $routes = [
        'tr' => ['home'=>'', 'about'=>'hakkimizda', 'services'=>'hizmetler', 'projects'=>'projeler', 'contact'=>'iletisim'],
        'en' => ['home'=>'', 'about'=>'about', 'services'=>'services', 'projects'=>'projects', 'contact'=>'contact'],
        'ku' => ['home'=>'', 'about'=>'derbare-me', 'services'=>'xizmeten', 'projects'=>'projeyen', 'contact'=>'tekili'],
    ];

    if ($langCode === 'tr') {
        $path = $routes['tr'][$page] ?? '';
        return $path ? $base . '/' . $path : $base;
    }

    $path = $routes[$langCode][$page] ?? '';
    return $path ? $base . '/' . $langCode . '/' . $path : $base . '/' . $langCode;
}

/**
 * Sayfa rotaları
 */
function get_routes(): array
{
    return [
        'tr' => [
            ''              => 'home',
            'hakkimizda'    => 'about',
            'hizmetler'     => 'services',
            'projeler'      => 'projects',
            'projeler/devam-eden' => 'projects_ongoing',
            'projeler/tamamlanan' => 'projects_completed',
            'proje'         => 'project_detail',
            'iletisim'      => 'contact',
            'kvkk'          => 'page',
            'gizlilik-politikasi' => 'page',
            'cerez-politikasi'    => 'page',
            'arama'         => 'search',
        ],
        'en' => [
            ''              => 'home',
            'about'         => 'about',
            'services'      => 'services',
            'projects'      => 'projects',
            'projects/ongoing'    => 'projects_ongoing',
            'projects/completed'  => 'projects_completed',
            'project'       => 'project_detail',
            'contact'       => 'contact',
            'gdpr'          => 'page',
            'privacy-policy'=> 'page',
            'cookie-policy' => 'page',
            'search'        => 'search',
        ],
        'ku' => [
            ''              => 'home',
            'derbare-me'    => 'about',
            'xizmeten'      => 'services',
            'projeyen'      => 'projects',
            'projeyen/domdar'   => 'projects_ongoing',
            'projeyen/qediyayi' => 'projects_completed',
            'proje'         => 'project_detail',
            'tekili'        => 'contact',
            'kvkk-ku'       => 'page',
            'politika-nepenitiye' => 'page',
            'politika-cookie'     => 'page',
            'gere'          => 'search',
        ],
    ];
}

/**
 * URL'den sayfa tespiti
 */
function resolve_page(string $uri, string $lang): array
{
    $routes = get_routes();
    $path = trim(parse_url($uri, PHP_URL_PATH), '/');

    // Dil prefix kaldır
    if ($lang !== 'tr' && str_starts_with($path, $lang . '/')) {
        $path = substr($path, strlen($lang) + 1);
    } elseif ($lang !== 'tr' && $path === $lang) {
        $path = '';
    }

    $langRoutes = $routes[$lang] ?? $routes['tr'];

    // Proje detay: proje/slug veya project/slug
    if (preg_match('#^(proje|project)/([a-z0-9-]+)$#', $path, $m)) {
        return ['page' => 'project_detail', 'slug' => $m[2]];
    }

    // Sayfa slug
    if (isset($langRoutes[$path])) {
        return ['page' => $langRoutes[$path], 'slug' => $path];
    }

    return ['page' => '404', 'slug' => ''];
}
