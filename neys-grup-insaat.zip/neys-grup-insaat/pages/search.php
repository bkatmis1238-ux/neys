<?php
/**
 * Arama Sayfası
 */
$query = get_param('q', '');
$results = [];

if (strlen($query) >= 2) {
    $like = '%' . $query . '%';
    $results = array_merge(
        db_fetch_all($pdo,
            'SELECT pt.title, pt.slug, pt.short_description, "project" as type
             FROM project_translations pt
             JOIN projects p ON pt.project_id = p.id
             WHERE pt.language_id = ? AND p.is_active = 1
             AND (pt.title LIKE ? OR pt.short_description LIKE ? OR pt.description LIKE ?)',
            [$langId, $like, $like, $like]
        ),
        db_fetch_all($pdo,
            'SELECT st.title, st.slug, st.short_description, "service" as type
             FROM service_translations st
             JOIN services s ON st.service_id = s.id
             WHERE st.language_id = ? AND s.is_active = 1
             AND (st.title LIKE ? OR st.short_description LIKE ? OR st.description LIKE ?)',
            [$langId, $like, $like, $like]
        )
    );
}

require INCLUDES_PATH . '/head.php';
require INCLUDES_PATH . '/header.php';
?>

<section class="page-hero">
    <div class="container">
        <?= breadcrumb([['title' => __('search_placeholder'), 'url' => '#']]) ?>
        <h1><?= e(__('search_placeholder')) ?></h1>
        <form action="" method="GET" class="search-form mt-4">
            <div class="input-group input-group-lg">
                <input type="text" name="q" class="form-control" value="<?= e($query) ?>" placeholder="<?= e(__('search_placeholder')) ?>">
                <button class="btn btn-primary" type="submit"><i class="bi bi-search"></i></button>
            </div>
        </form>
    </div>
</section>

<section class="section">
    <div class="container">
        <?php if ($query && empty($results)): ?>
        <p class="text-center text-muted"><?= e(__('search_no_results')) ?></p>
        <?php elseif ($results): ?>
        <div class="row g-4">
            <?php foreach ($results as $item): ?>
            <div class="col-md-6">
                <div class="search-result-card">
                    <span class="badge bg-primary mb-2"><?= $item['type'] === 'project' ? e(__('nav_projects')) : e(__('nav_services')) ?></span>
                    <h4><?= e($item['title']) ?></h4>
                    <p><?= e(truncate($item['short_description'] ?? '', 150)) ?></p>
                    <?php if ($item['type'] === 'project'): ?>
                    <a href="<?= site_url(($currentLang === 'en' ? 'project' : 'proje') . '/' . $item['slug']) ?>" class="btn btn-sm btn-outline-primary"><?= e(__('btn_view_details')) ?></a>
                    <?php else: ?>
                    <a href="<?= site_url($currentLang === 'en' ? 'services' : ($currentLang === 'ku' ? 'xizmeten' : 'hizmetler')) ?>" class="btn btn-sm btn-outline-primary"><?= e(__('btn_view_details')) ?></a>
                    <?php endif; ?>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>
    </div>
</section>

<?php require INCLUDES_PATH . '/footer.php'; ?>
