<?php
/**
 * İletişim Formu Partial
 */
$flash = get_flash();
?>
<?php if ($flash): ?>
<div class="alert alert-<?= $flash['type'] === 'success' ? 'success' : 'danger' ?> alert-dismissible fade show">
    <?= e($flash['message']) ?>
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
<?php endif; ?>
<form action="<?= site_url('api/contact.php') ?>" method="POST" class="contact-form" id="contactForm">
    <?= csrf_field() ?>
    <input type="text" name="website_url" class="d-none" tabindex="-1" autocomplete="off">
    <div class="row g-3">
        <div class="col-md-6">
            <input type="text" name="name" class="form-control" placeholder="<?= e(__('form_name')) ?> *" required>
        </div>
        <div class="col-md-6">
            <input type="email" name="email" class="form-control" placeholder="<?= e(__('form_email')) ?> *" required>
        </div>
        <div class="col-md-6">
            <input type="tel" name="phone" class="form-control" placeholder="<?= e(__('form_phone')) ?>">
        </div>
        <div class="col-md-6">
            <input type="text" name="subject" class="form-control" placeholder="<?= e(__('form_subject')) ?>">
        </div>
        <div class="col-12">
            <textarea name="message" class="form-control" rows="4" placeholder="<?= e(__('form_message')) ?> *" required></textarea>
        </div>
        <div class="col-12">
            <button type="submit" class="btn btn-primary w-100"><?= e(__('btn_send_message')) ?> <i class="bi bi-send"></i></button>
        </div>
    </div>
</form>
