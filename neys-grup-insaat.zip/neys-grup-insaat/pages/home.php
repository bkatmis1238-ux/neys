<?php
/**
 * Ana Sayfa
 */

// Slider verileri
$sliders = db_fetch_all($pdo,
    'SELECT s.*, st.title, st.subtitle, st.button_text, st.button_link
     FROM sliders s
     JOIN slider_translations st ON s.id = st.slider_id
     WHERE s.is_active = 1 AND st.language_id = ?
     ORDER BY s.sort_order ASC',
    [$langId]
);

// Hakkımızda kısa
$aboutHome = db_fetch($pdo,
    'SELECT at.title, at.content, a.image, a.video_url
     FROM about_sections a
     JOIN about_translations at ON a.id = at.section_id
     WHERE a.section_key = "story" AND at.language_id = ?',
    [$langId]
);

// Hizmetler
$services = db_fetch_all($pdo,
    'SELECT s.*, st.title, st.short_description, st.slug
     FROM services s
     JOIN service_translations st ON s.id = st.service_id
     WHERE s.is_active = 1 AND st.language_id = ?
     ORDER BY s.sort_order ASC LIMIT 6',
    [$langId]
);

// Anasayfa projeleri
$projects = db_fetch_all($pdo,
    'SELECT p.*, pt.title, pt.slug, pt.short_description
     FROM projects p
     JOIN project_translations pt ON p.id = pt.project_id
     WHERE p.is_active = 1 AND p.show_homepage = 1 AND pt.language_id = ?
     ORDER BY p.sort_order ASC LIMIT 6',
    [$langId]
);

// İstatistikler
$statistics = db_fetch_all($pdo,
    'SELECT s.*, st.label
     FROM statistics s
     JOIN statistic_translations st ON s.id = st.statistic_id
     WHERE s.is_active = 1 AND st.language_id = ?
     ORDER BY s.sort_order ASC',
    [$langId]
);

require INCLUDES_PATH . '/head.php';
require INCLUDES_PATH . '/header.php';
?>

<!-- Hero Slider -->
<section class="hero-slider">
    <div id="heroCarousel" class="carousel slide carousel-fade" data-bs-ride="carousel" data-bs-interval="6000">
        <?php if (count($sliders) > 1): ?>
        <div class="carousel-indicators">
            <?php foreach ($sliders as $i => $slide): ?>
            <button type="button" data-bs-target="#heroCarousel" data-bs-slide-to="<?= $i ?>" <?= $i === 0 ? 'class="active"' : '' ?>></button>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>
        <div class="carousel-inner">
            <?php foreach ($sliders as $i => $slide): ?>
            <div class="carousel-item <?= $i === 0 ? 'active' : '' ?>">
                <div class="slide-bg" style="background-image: url('<?= asset_url($slide['image']) ?>')"></div>
                <div class="slide-overlay"></div>
                <div class="container">
                    <div class="slide-content" data-aos="fade-up">
                        <h1><?= e($slide['title']) ?></h1>
                        <p><?= e($slide['subtitle']) ?></p>
                        <?php if ($slide['button_text']): ?>
                        <a href="<?= site_url(ltrim($slide['button_link'], '/')) ?>" class="btn btn-primary btn-lg"><?= e($slide['button_text']) ?></a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        <?php if (count($sliders) > 1): ?>
        <button class="carousel-control-prev" type="button" data-bs-target="#heroCarousel" data-bs-slide="prev">
            <span class="carousel-control-prev-icon"></span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#heroCarousel" data-bs-slide="next">
            <span class="carousel-control-next-icon"></span>
        </button>
        <?php endif; ?>
    </div>
</section>

<!-- Hakkımızda Kısa -->
<?php if ($aboutHome): ?>
<section class="section about-preview">
    <div class="container">
        <div class="row align-items-center g-5">
            <div class="col-lg-6" data-aos="fade-right">
                <span class="section-subtitle"><?= e($settings['site_name'] ?? '') ?></span>
                <h2 class="section-title"><?= e($aboutHome['title']) ?></h2>
                <p class="lead"><?= e(truncate(strip_tags($aboutHome['content']), 300)) ?></p>
                <a href="<?= site_url($currentLang === 'en' ? 'about' : ($currentLang === 'ku' ? 'derbare-me' : 'hakkimizda')) ?>" class="btn btn-outline-primary"><?= e(__('btn_read_more')) ?> <i class="bi bi-arrow-right"></i></a>
            </div>
            <div class="col-lg-6" data-aos="fade-left">
                <div class="about-media">
                    <?php if (!empty($aboutHome['video_url'])): ?>
                    <div class="ratio ratio-16x9 rounded-4 overflow-hidden shadow-lg">
                        <iframe src="<?= e(youtube_embed($aboutHome['video_url'])) ?>" allowfullscreen loading="lazy"></iframe>
                    </div>
                    <?php else: ?>
                    <img src="<?= asset_url($aboutHome['image'] ?? 'assets/images/about/about-main.svg') ?>" alt="<?= e($aboutHome['title']) ?>" class="img-fluid rounded-4 shadow-lg" loading="lazy">
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</section>
<?php endif; ?>

<!-- Hizmetler -->
<section class="section services-section bg-light">
    <div class="container">
        <div class="section-header text-center" data-aos="fade-up">
            <span class="section-subtitle"><?= e($settings['site_name'] ?? '') ?></span>
            <h2 class="section-title"><?= e(__('home_services_title')) ?></h2>
            <p><?= e(__('home_services_subtitle')) ?></p>
        </div>
        <div class="row g-4">
            <?php foreach ($services as $service): ?>
            <div class="col-lg-4 col-md-6" data-aos="fade-up" data-aos-delay="<?= ($service['sort_order'] ?? 0) * 50 ?>">
                <div class="service-card">
                    <div class="service-icon"><i class="bi <?= e($service['icon']) ?>"></i></div>
                    <?php if ($service['image']): ?>
                    <div class="service-image">
                        <img src="<?= asset_url($service['image']) ?>" alt="<?= e($service['title']) ?>" loading="lazy">
                    </div>
                    <?php endif; ?>
                    <div class="service-body">
                        <h3><?= e($service['title']) ?></h3>
                        <p><?= e($service['short_description']) ?></p>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        <div class="text-center mt-5" data-aos="fade-up">
            <a href="<?= site_url($currentLang === 'en' ? 'services' : ($currentLang === 'ku' ? 'xizmeten' : 'hizmetler')) ?>" class="btn btn-primary"><?= e(__('btn_all_services')) ?></a>
        </div>
    </div>
</section>

<!-- Projeler -->
<section class="section projects-section">
    <div class="container">
        <div class="section-header text-center" data-aos="fade-up">
            <span class="section-subtitle"><?= e($settings['site_name'] ?? '') ?></span>
            <h2 class="section-title"><?= e(__('home_projects_title')) ?></h2>
            <p><?= e(__('home_projects_subtitle')) ?></p>
        </div>
        <div class="row g-4">
            <?php foreach ($projects as $project): ?>
            <div class="col-lg-4 col-md-6" data-aos="zoom-in">
                <div class="project-card">
                    <div class="project-image">
                        <img src="<?= asset_url($project['cover_image']) ?>" alt="<?= e($project['title']) ?>" loading="lazy">
                        <?= status_badge($project['category']) ?>
                    </div>
                    <div class="project-body">
                        <h3><?= e($project['title']) ?></h3>
                        <p class="project-location"><i class="bi bi-geo-alt"></i> <?= e($project['location']) ?></p>
                        <p><?= e(truncate($project['short_description'] ?? '', 100)) ?></p>
                        <a href="<?= site_url(($currentLang === 'en' ? 'project' : 'proje') . '/' . $project['slug']) ?>" class="btn btn-sm btn-outline-primary"><?= e(__('btn_view_details')) ?></a>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        <div class="text-center mt-5">
            <a href="<?= site_url($currentLang === 'en' ? 'projects' : ($currentLang === 'ku' ? 'projeyen' : 'projeler')) ?>" class="btn btn-primary"><?= e(__('btn_all_projects')) ?></a>
        </div>
    </div>
</section>

<!-- İstatistikler -->
<section class="section stats-section">
    <div class="container">
        <div class="row g-4">
            <?php foreach ($statistics as $stat): ?>
            <div class="col-lg-3 col-md-6" data-aos="fade-up">
                <div class="stat-card text-center">
                    <div class="stat-icon"><i class="bi <?= e($stat['icon']) ?>"></i></div>
                    <div class="stat-number" data-count="<?= (int)$stat['stat_value'] ?>">0</div>
                    <div class="stat-label"><?= e($stat['label']) ?></div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- İletişim Özeti -->
<section class="section contact-preview bg-light">
    <div class="container">
        <div class="row align-items-center g-5">
            <div class="col-lg-6" data-aos="fade-right">
                <span class="section-subtitle"><?= e(__('nav_contact')) ?></span>
                <h2 class="section-title"><?= e(__('home_contact_title')) ?></h2>
                <p><?= e(__('home_contact_subtitle')) ?></p>
                <ul class="contact-info-list">
                    <li><i class="bi bi-telephone"></i><div><strong><?= e(__('phone_label')) ?></strong><span><?= e($settings['phone'] ?? '') ?></span></div></li>
                    <li><i class="bi bi-envelope"></i><div><strong><?= e(__('email_label')) ?></strong><span><?= e($settings['email'] ?? '') ?></span></div></li>
                    <li><i class="bi bi-geo-alt"></i><div><strong><?= e(__('address_label')) ?></strong><span><?= e($settings['address'] ?? '') ?></span></div></li>
                </ul>
                <a href="<?= site_url($currentLang === 'en' ? 'contact' : ($currentLang === 'ku' ? 'tekili' : 'iletisim')) ?>" class="btn btn-primary"><?= e(__('btn_contact_us')) ?></a>
            </div>
            <div class="col-lg-6" data-aos="fade-left">
                <div class="contact-quick-card">
                    <h4><?= e(__('form_message')) ?></h4>
                    <?php include PAGES_PATH . '/partials/contact-form.php'; ?>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Harita -->
<section class="section map-section p-0">
    <div class="map-container">
        <?= $settings['map_embed'] ?? '' ?>
    </div>
    <div class="container py-4">
        <p class="text-center text-muted mb-0" data-aos="fade-up"><?= e(__('home_map_text')) ?></p>
    </div>
</section>

<?php require INCLUDES_PATH . '/footer.php'; ?>
