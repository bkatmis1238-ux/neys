<?php
/**
 * Hakkımızda Sayfası
 */
$sections = db_fetch_all($pdo,
    'SELECT a.*, at.title, at.content
     FROM about_sections a
     JOIN about_translations at ON a.id = at.section_id
     WHERE a.is_active = 1 AND at.language_id = ?
     ORDER BY a.sort_order ASC',
    [$langId]
);

$timeline = db_fetch_all($pdo,
    'SELECT t.*, tt.title, tt.description
     FROM timeline_items t
     JOIN timeline_translations tt ON t.id = tt.timeline_id
     WHERE t.is_active = 1 AND tt.language_id = ?
     ORDER BY t.sort_order ASC',
    [$langId]
);

require INCLUDES_PATH . '/head.php';
require INCLUDES_PATH . '/header.php';
?>

<section class="page-hero">
    <div class="container">
        <?= breadcrumb([['title' => __('nav_about'), 'url' => '#']]) ?>
        <h1 data-aos="fade-up"><?= e(__('nav_about')) ?></h1>
    </div>
</section>

<?php foreach ($sections as $i => $section): ?>
<section class="section <?= $i % 2 === 1 ? 'bg-light' : '' ?>">
    <div class="container">
        <div class="row align-items-center g-5 <?= $i % 2 === 1 ? 'flex-row-reverse' : '' ?>">
            <div class="col-lg-6" data-aos="fade-<?= $i % 2 === 0 ? 'right' : 'left' ?>">
                <h2 class="section-title"><?= e($section['title']) ?></h2>
                <div class="content-text"><?= $section['content'] ?></div>
            </div>
            <?php if ($section['image']): ?>
            <div class="col-lg-6" data-aos="fade-<?= $i % 2 === 0 ? 'left' : 'right' ?>">
                <img src="<?= asset_url($section['image']) ?>" alt="<?= e($section['title']) ?>" class="img-fluid rounded-4 shadow" loading="lazy">
            </div>
            <?php endif; ?>
        </div>
    </div>
</section>
<?php endforeach; ?>

<!-- Timeline -->
<?php if ($timeline): ?>
<section class="section timeline-section bg-light">
    <div class="container">
        <div class="section-header text-center mb-5" data-aos="fade-up">
            <h2 class="section-title"><?= e(__('about_timeline')) ?></h2>
        </div>
        <div class="timeline">
            <?php foreach ($timeline as $item): ?>
            <div class="timeline-item" data-aos="fade-up">
                <div class="timeline-year"><?= e($item['year']) ?></div>
                <div class="timeline-content">
                    <h4><?= e($item['title']) ?></h4>
                    <p><?= e($item['description']) ?></p>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>
<?php endif; ?>

<?php require INCLUDES_PATH . '/footer.php'; ?>
