<?php
/**
 * Devam Eden Projeler
 */
$filter = 'ongoing';
require PAGES_PATH . '/projects.php';
