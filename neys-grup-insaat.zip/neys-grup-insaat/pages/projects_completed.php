<?php
/**
 * Tamamlanan Projeler
 */
$filter = 'completed';
require PAGES_PATH . '/projects.php';
