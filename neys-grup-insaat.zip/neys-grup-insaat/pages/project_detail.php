<?php
/**
 * Proje Detay Sayfası
 */
$slug = $pageSlug;
if (strpos($slug, '/') !== false) {
    $parts = explode('/', $slug);
    $slug = end($parts);
}

$project = db_fetch($pdo,
    'SELECT p.*, pt.title, pt.slug, pt.short_description, pt.description, pt.meta_title, pt.meta_description
     FROM projects p
     JOIN project_translations pt ON p.id = pt.project_id
     WHERE pt.slug = ? AND pt.language_id = ? AND p.is_active = 1',
    [$slug, $langId]
);

if (!$project) {
    $currentPage = '404';
    require PAGES_PATH . '/404.php';
    exit;
}

// Görüntülenme sayısı artır
db_execute($pdo, 'UPDATE projects SET views = views + 1 WHERE id = ?', [$project['id']]);

// Galeri
$gallery = db_fetch_all($pdo,
    'SELECT * FROM project_images WHERE project_id = ? ORDER BY sort_order ASC',
    [$project['id']]
);

// SEO override
if ($project['meta_title']) $seo['meta_title'] = $project['meta_title'];
if ($project['meta_description']) $seo['meta_description'] = $project['meta_description'];

require INCLUDES_PATH . '/head.php';
require INCLUDES_PATH . '/header.php';
?>

<section class="page-hero project-hero" style="background-image: url('<?= asset_url($project['cover_image']) ?>')">
    <div class="hero-overlay"></div>
    <div class="container">
        <?= breadcrumb([
            ['title' => __('nav_projects'), 'url' => site_url($currentLang === 'en' ? 'projects' : ($currentLang === 'ku' ? 'projeyen' : 'projeler'))],
            ['title' => $project['title'], 'url' => '#']
        ]) ?>
        <h1 data-aos="fade-up"><?= e($project['title']) ?></h1>
        <p class="project-hero-location" data-aos="fade-up" data-aos-delay="100"><i class="bi bi-geo-alt"></i> <?= e($project['location']) ?></p>
        <div data-aos="fade-up" data-aos-delay="200"><?= status_badge($project['category']) ?></div>
    </div>
</section>

<section class="section">
    <div class="container">
        <div class="row g-5">
            <div class="col-lg-8">
                <!-- Galeri Slider -->
                <?php if ($gallery): ?>
                <div id="projectGallery" class="carousel slide project-gallery mb-4" data-bs-ride="carousel">
                    <div class="carousel-inner rounded-4 overflow-hidden">
                        <?php foreach ($gallery as $i => $img): ?>
                        <div class="carousel-item <?= $i === 0 ? 'active' : '' ?>">
                            <img src="<?= asset_url($img['image']) ?>" class="d-block w-100" alt="<?= e($project['title']) ?>" loading="lazy">
                        </div>
                        <?php endforeach; ?>
                    </div>
                    <?php if (count($gallery) > 1): ?>
                    <button class="carousel-control-prev" type="button" data-bs-target="#projectGallery" data-bs-slide="prev"><span class="carousel-control-prev-icon"></span></button>
                    <button class="carousel-control-next" type="button" data-bs-target="#projectGallery" data-bs-slide="next"><span class="carousel-control-next-icon"></span></button>
                    <?php endif; ?>
                </div>
                <?php endif; ?>

                <h3><?= e(__('project_description')) ?></h3>
                <div class="content-text"><?= $project['description'] ?></div>

                <!-- Video -->
                <?php if ($project['video_url']): ?>
                <div class="mt-4">
                    <h4><?= e(__('project_video')) ?></h4>
                    <div class="ratio ratio-16x9 rounded-4 overflow-hidden">
                        <iframe src="<?= e(youtube_embed($project['video_url'])) ?>" allowfullscreen loading="lazy"></iframe>
                    </div>
                </div>
                <?php endif; ?>

                <!-- Thumbnail Galeri -->
                <?php if (count($gallery) > 1): ?>
                <div class="mt-4">
                    <h4><?= e(__('project_gallery')) ?></h4>
                    <div class="row g-2">
                        <?php foreach ($gallery as $img): ?>
                        <div class="col-3">
                            <img src="<?= asset_url($img['image']) ?>" class="img-fluid rounded gallery-thumb" alt="" loading="lazy">
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                <?php endif; ?>
            </div>

            <div class="col-lg-4">
                <div class="project-info-card" data-aos="fade-left">
                    <h4><?= e($project['title']) ?></h4>
                    <ul class="project-info-list">
                        <li><span><?= e(__('project_location')) ?></span><strong><?= e($project['location']) ?></strong></li>
                        <li><span><?= e(__('project_start_date')) ?></span><strong><?= format_date($project['start_date']) ?></strong></li>
                        <li><span><?= e(__('project_end_date')) ?></span><strong><?= format_date($project['end_date']) ?></strong></li>
                        <?php if ($project['area_sqm']): ?>
                        <li><span><?= e(__('project_area')) ?></span><strong><?= number_format((float)$project['area_sqm'], 0, ',', '.') ?> m²</strong></li>
                        <?php endif; ?>
                        <li><span><?= e(__('project_status')) ?></span><strong><?= $project['category'] === 'ongoing' ? e(__('status_ongoing')) : e(__('status_completed')) ?></strong></li>
                    </ul>
                    <?php if ($project['pdf_brochure']): ?>
                    <a href="<?= asset_url($project['pdf_brochure']) ?>" class="btn btn-outline-primary w-100 mt-3" target="_blank"><i class="bi bi-file-pdf"></i> <?= e(__('project_brochure')) ?></a>
                    <?php endif; ?>
                    <a href="<?= site_url($currentLang === 'en' ? 'contact' : ($currentLang === 'ku' ? 'tekili' : 'iletisim')) ?>" class="btn btn-primary w-100 mt-2"><?= e(__('btn_contact_us')) ?></a>
                </div>

                <?php if ($project['map_embed']): ?>
                <div class="project-map mt-4 rounded-4 overflow-hidden">
                    <?= $project['map_embed'] ?>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>

<?php require INCLUDES_PATH . '/footer.php'; ?>
