<?php
/**
 * Projeler Sayfası
 */
$filter = $filter ?? get_param('filter', 'all');
$category = null;
if ($filter === 'ongoing') $category = 'ongoing';
if ($filter === 'completed') $category = 'completed';

$sql = 'SELECT p.*, pt.title, pt.slug, pt.short_description
        FROM projects p
        JOIN project_translations pt ON p.id = pt.project_id
        WHERE p.is_active = 1 AND pt.language_id = ?';
$params = [$langId];

if ($category) {
    $sql .= ' AND p.category = ?';
    $params[] = $category;
}
$sql .= ' ORDER BY p.sort_order ASC';

$projects = db_fetch_all($pdo, $sql, $params);

require INCLUDES_PATH . '/head.php';
require INCLUDES_PATH . '/header.php';
?>

<section class="page-hero">
    <div class="container">
        <?= breadcrumb([['title' => __('nav_projects'), 'url' => '#']]) ?>
        <h1 data-aos="fade-up"><?= e(__('nav_projects')) ?></h1>
        <p data-aos="fade-up" data-aos-delay="100"><?= e(__('home_projects_subtitle')) ?></p>
    </div>
</section>

<section class="section">
    <div class="container">
        <!-- Filtre -->
        <div class="project-filters text-center mb-5" data-aos="fade-up">
            <a href="?filter=all" class="filter-btn <?= $filter === 'all' ? 'active' : '' ?>"><?= e(__('filter_all')) ?></a>
            <a href="?filter=ongoing" class="filter-btn <?= $filter === 'ongoing' ? 'active' : '' ?>"><?= e(__('filter_ongoing')) ?></a>
            <a href="?filter=completed" class="filter-btn <?= $filter === 'completed' ? 'active' : '' ?>"><?= e(__('filter_completed')) ?></a>
        </div>

        <div class="row g-4">
            <?php if (empty($projects)): ?>
            <div class="col-12 text-center py-5">
                <p class="text-muted"><?= e(__('search_no_results')) ?></p>
            </div>
            <?php else: ?>
            <?php foreach ($projects as $project): ?>
            <div class="col-lg-4 col-md-6" data-aos="zoom-in">
                <div class="project-card">
                    <div class="project-image">
                        <img src="<?= asset_url($project['cover_image']) ?>" alt="<?= e($project['title']) ?>" loading="lazy">
                        <?= status_badge($project['category']) ?>
                    </div>
                    <div class="project-body">
                        <h3><?= e($project['title']) ?></h3>
                        <p class="project-location"><i class="bi bi-geo-alt"></i> <?= e($project['location']) ?></p>
                        <p><?= e(truncate($project['short_description'] ?? '', 120)) ?></p>
                        <a href="<?= site_url(($currentLang === 'en' ? 'project' : 'proje') . '/' . $project['slug']) ?>" class="btn btn-sm btn-outline-primary"><?= e(__('btn_view_details')) ?></a>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
</section>

<?php require INCLUDES_PATH . '/footer.php'; ?>
