<?php
/**
 * Hizmetler Sayfası
 */
$services = db_fetch_all($pdo,
    'SELECT s.*, st.title, st.short_description, st.description, st.slug
     FROM services s
     JOIN service_translations st ON s.id = st.service_id
     WHERE s.is_active = 1 AND st.language_id = ?
     ORDER BY s.sort_order ASC',
    [$langId]
);

require INCLUDES_PATH . '/head.php';
require INCLUDES_PATH . '/header.php';
?>

<section class="page-hero">
    <div class="container">
        <?= breadcrumb([['title' => __('nav_services'), 'url' => '#']]) ?>
        <h1 data-aos="fade-up"><?= e(__('nav_services')) ?></h1>
        <p data-aos="fade-up" data-aos-delay="100"><?= e(__('home_services_subtitle')) ?></p>
    </div>
</section>

<section class="section">
    <div class="container">
        <div class="row g-4">
            <?php foreach ($services as $i => $service): ?>
            <div class="col-lg-6" data-aos="fade-up" data-aos-delay="<?= $i * 50 ?>">
                <div class="service-detail-card">
                    <div class="row g-0">
                        <?php if ($service['image']): ?>
                        <div class="col-md-5">
                            <img src="<?= asset_url($service['image']) ?>" alt="<?= e($service['title']) ?>" class="service-detail-img" loading="lazy">
                        </div>
                        <?php endif; ?>
                        <div class="col-md-<?= $service['image'] ? '7' : '12' ?>">
                            <div class="service-detail-body">
                                <div class="service-icon-lg"><i class="bi <?= e($service['icon']) ?>"></i></div>
                                <h3><?= e($service['title']) ?></h3>
                                <p class="text-muted"><?= e($service['short_description']) ?></p>
                                <div class="content-text"><?= $service['description'] ?></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<?php require INCLUDES_PATH . '/footer.php'; ?>
