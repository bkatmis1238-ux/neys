<?php
/**
 * Statik Sayfa (KVKK, Gizlilik, Çerez)
 */
$pageData = db_fetch($pdo,
    'SELECT pt.title, pt.content, pt.meta_title, pt.meta_description
     FROM page_translations pt
     JOIN pages p ON pt.page_id = p.id
     WHERE pt.slug = ? AND pt.language_id = ? AND p.is_active = 1',
    [$pageSlug, $langId]
);

if (!$pageData) {
    require PAGES_PATH . '/404.php';
    exit;
}

if ($pageData['meta_title']) $seo['meta_title'] = $pageData['meta_title'];
if ($pageData['meta_description']) $seo['meta_description'] = $pageData['meta_description'];

require INCLUDES_PATH . '/head.php';
require INCLUDES_PATH . '/header.php';
?>

<section class="page-hero">
    <div class="container">
        <?= breadcrumb([['title' => $pageData['title'], 'url' => '#']]) ?>
        <h1><?= e($pageData['title']) ?></h1>
    </div>
</section>

<section class="section">
    <div class="container">
        <div class="content-text legal-content" data-aos="fade-up">
            <?= $pageData['content'] ?>
        </div>
    </div>
</section>

<?php require INCLUDES_PATH . '/footer.php'; ?>
