<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= e(__('maintenance_title')) ?> | Neys Grup İnşaat</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { min-height: 100vh; display: flex; align-items: center; justify-content: center; background: #f8f9fa; font-family: 'Inter', sans-serif; }
        .maintenance-box { text-align: center; max-width: 500px; padding: 3rem; }
        .maintenance-icon { font-size: 4rem; color: #1e5aa8; margin-bottom: 1.5rem; }
    </style>
</head>
<body>
    <div class="maintenance-box">
        <div class="maintenance-icon">🔧</div>
        <h1><?= e(__('maintenance_title')) ?></h1>
        <p class="text-muted"><?= e(__('maintenance_text')) ?></p>
    </div>
</body>
</html>
