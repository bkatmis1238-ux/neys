<?php
/**
 * 404 Sayfası
 */
http_response_code(404);
require INCLUDES_PATH . '/head.php';
require INCLUDES_PATH . '/header.php';
?>

<section class="section error-page text-center">
    <div class="container">
        <div class="error-content" data-aos="zoom-in">
            <h1 class="error-code">404</h1>
            <h2><?= e(__('404_title')) ?></h2>
            <p class="text-muted"><?= e(__('404_text')) ?></p>
            <a href="<?= site_url() ?>" class="btn btn-primary"><?= e(__('404_btn')) ?></a>
        </div>
    </div>
</section>

<?php require INCLUDES_PATH . '/footer.php'; ?>
