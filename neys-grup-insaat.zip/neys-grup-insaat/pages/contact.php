<?php
/**
 * İletişim Sayfası
 */
require INCLUDES_PATH . '/head.php';
require INCLUDES_PATH . '/header.php';
?>

<section class="page-hero">
    <div class="container">
        <?= breadcrumb([['title' => __('nav_contact'), 'url' => '#']]) ?>
        <h1 data-aos="fade-up"><?= e(__('nav_contact')) ?></h1>
        <p data-aos="fade-up" data-aos-delay="100"><?= e(__('home_contact_subtitle')) ?></p>
    </div>
</section>

<section class="section">
    <div class="container">
        <div class="row g-5">
            <div class="col-lg-5" data-aos="fade-right">
                <div class="contact-info-card">
                    <h3><?= e(__('footer_contact')) ?></h3>
                    <ul class="contact-info-list">
                        <li><i class="bi bi-telephone"></i><div><strong><?= e(__('phone_label')) ?></strong><a href="tel:<?= e(preg_replace('/[^0-9+]/', '', $settings['phone'] ?? '')) ?>"><?= e($settings['phone'] ?? '') ?></a></div></li>
                        <?php if (!empty($settings['whatsapp'])): ?>
                        <li><i class="bi bi-whatsapp"></i><div><strong><?= e(__('whatsapp_label')) ?></strong><a href="https://wa.me/<?= e($settings['whatsapp']) ?>" target="_blank"><?= e($settings['phone'] ?? '') ?></a></div></li>
                        <?php endif; ?>
                        <li><i class="bi bi-envelope"></i><div><strong><?= e(__('email_label')) ?></strong><a href="mailto:<?= e($settings['email'] ?? '') ?>"><?= e($settings['email'] ?? '') ?></a></div></li>
                        <li><i class="bi bi-geo-alt"></i><div><strong><?= e(__('address_label')) ?></strong><span><?= e($settings['address'] ?? '') ?></span></div></li>
                        <li><i class="bi bi-clock"></i><div><strong><?= e(__('working_hours_label')) ?></strong><span><?= e($settings['working_hours'] ?? '') ?></span></div></li>
                    </ul>
                </div>
            </div>
            <div class="col-lg-7" data-aos="fade-left">
                <div class="contact-form-card">
                    <h3><?= e(__('form_message')) ?></h3>
                    <?php include PAGES_PATH . '/partials/contact-form.php'; ?>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="section map-section p-0">
    <div class="map-container"><?= $settings['map_embed'] ?? '' ?></div>
</section>

<?php require INCLUDES_PATH . '/footer.php'; ?>
