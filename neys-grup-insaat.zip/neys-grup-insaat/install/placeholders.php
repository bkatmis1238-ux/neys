<?php
/**
 * Placeholder görsel oluşturucu - Kurulum sonrası bir kez çalıştırın
 * php install/placeholders.php
 */
$dirs = [
    'assets/images/slider',
    'assets/images/about',
    'assets/images/services',
    'assets/images/projects',
];
$root = dirname(__DIR__);

foreach ($dirs as $dir) {
    $path = $root . '/' . $dir;
    if (!is_dir($path)) mkdir($path, 0755, true);
}

function createPlaceholder(string $path, int $w, int $h, string $text, string $color = '1e5aa8'): void
{
    if (file_exists($path)) return;
    if (!function_exists('imagecreatetruecolor')) {
        // GD yoksa SVG oluştur
        $svgPath = preg_replace('/\.(jpg|jpeg|png)$/', '.svg', $path);
        $svg = '<svg xmlns="http://www.w3.org/2000/svg" width="' . $w . '" height="' . $h . '">
            <defs><linearGradient id="g" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" style="stop-color:#' . $color . '"/>
            <stop offset="100%" style="stop-color:#0d3d7a"/></linearGradient></defs>
            <rect width="100%" height="100%" fill="url(#g)"/>
            <text x="50%" y="50%" font-family="Arial" font-size="24" fill="white" text-anchor="middle" dominant-baseline="middle">' . htmlspecialchars($text) . '</text>
        </svg>';
        file_put_contents($svgPath, $svg);
        return;
    }
    $img = imagecreatetruecolor($w, $h);
    $bg = imagecolorallocate($img, 30, 90, 168);
    $bg2 = imagecolorallocate($img, 13, 61, 122);
    imagefilledrectangle($img, 0, 0, $w, $h, $bg);
    imagefilledrectangle($img, 0, (int)($h * 0.6), $w, $h, $bg2);
    $white = imagecolorallocate($img, 255, 255, 255);
    imagestring($img, 5, (int)($w / 2 - strlen($text) * 4), (int)($h / 2 - 10), $text, $white);
    imagejpeg($img, $path, 85);
    imagedestroy($img);
}

$images = [
    ['assets/images/slider/slider-1.jpg', 1920, 1080, 'Neys Grup Insaat'],
    ['assets/images/slider/slider-2.jpg', 1920, 1080, 'Kalite ve Guven'],
    ['assets/images/slider/slider-3.jpg', 1920, 1080, 'Guvenli Yasam'],
    ['assets/images/about/about-main.jpg', 800, 600, 'Hakkimizda'],
    ['assets/images/about/why-us.jpg', 800, 600, 'Neden Biz'],
    ['assets/images/services/konut.jpg', 600, 400, 'Konut'],
    ['assets/images/services/villa.jpg', 600, 400, 'Villa'],
    ['assets/images/services/taahhut.jpg', 600, 400, 'Taahhut'],
    ['assets/images/services/anahtar.jpg', 600, 400, 'Anahtar Teslim'],
    ['assets/images/services/muhendislik.jpg', 600, 400, 'Muhendislik'],
    ['assets/images/services/mimarlik.jpg', 600, 400, 'Mimarlik'],
    ['assets/images/services/danismanlik.jpg', 600, 400, 'Danismanlik'],
    ['assets/images/projects/project-1.jpg', 800, 600, 'Proje 1'],
    ['assets/images/projects/project-1b.jpg', 800, 600, 'Proje 1B'],
    ['assets/images/projects/project-2.jpg', 800, 600, 'Proje 2'],
    ['assets/images/projects/project-3.jpg', 800, 600, 'Proje 3'],
    ['assets/images/projects/project-4.jpg', 800, 600, 'Proje 4'],
    ['assets/images/projects/project-5.jpg', 800, 600, 'Proje 5'],
    ['assets/images/projects/project-6.jpg', 800, 600, 'Proje 6'],
];

foreach ($images as [$file, $w, $h, $text]) {
    createPlaceholder($root . '/' . $file, $w, $h, $text);
}

echo "Placeholder gorseller olusturuldu.\n";
