<?php
/**
 * Admin şifresi kurulum scripti
 * php install/set_admin_password.php
 */
require_once dirname(__DIR__) . '/config/bootstrap.php';

$password = 'Admin@2026!';
$hash = password_hash($password, PASSWORD_DEFAULT);

db_execute($pdo, 'UPDATE admins SET password = ? WHERE username = ?', [$hash, 'admin']);

echo "Admin sifresi guncellendi.\n";
echo "Kullanici: admin\n";
echo "Sifre: Admin@2026!\n";
echo "Hash: $hash\n";
