-- Admin şifresini Admin@2026! olarak güncelle
-- 1) Terminalde çalıştır: php -r "echo password_hash('Admin@2026!', PASSWORD_DEFAULT);"
-- 2) Aşağıdaki <HASH> yerine çıkan değeri yapıştır ve çalıştır:

-- UPDATE admins SET password = '<HASH>' WHERE username = 'admin';
