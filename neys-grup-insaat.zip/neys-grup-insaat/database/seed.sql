-- Neys Grup İnşaat - Başlangıç Verileri
USE neys_grup_insaat;

-- Admin (şifre: Admin@2026!)
-- Mevcut hash eski seed'den geliyorsa güncellemek için:
-- php -r "echo password_hash('Admin@2026!', PASSWORD_DEFAULT);"
-- UPDATE admins SET password = '<hash>' WHERE username = 'admin';
INSERT INTO admins (username, email, password, full_name, role) VALUES
('admin', 'info@neysgrupinsaat.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Site Yöneticisi', 'super_admin');

-- Diller
INSERT INTO languages (code, name, native_name, flag, is_default, sort_order) VALUES
('tr', 'Turkish', 'Türkçe', '🇹🇷', 1, 1),
('en', 'English', 'English', '🇬🇧', 0, 2),
('ku', 'Kurdish', 'Kurdî', '🇹🇯', 0, 3);

-- Site Ayarları
INSERT INTO settings (setting_key, setting_value, setting_type, group_name) VALUES
('site_name', 'Neys Grup İnşaat', 'text', 'general'),
('site_tagline', 'Geleceği Birlikte İnşa Ediyoruz', 'text', 'general'),
('logo', 'assets/images/logo-placeholder.svg', 'file', 'theme'),
('logo_dark', 'assets/images/logo-placeholder-white.svg', 'file', 'theme'),
('favicon', 'assets/images/favicon.svg', 'file', 'theme'),
('primary_color', '#1e5aa8', 'text', 'theme'),
('primary_dark', '#0d3d7a', 'text', 'theme'),
('phone', '+90 (312) 000 00 00', 'text', 'contact'),
('phone2', '', 'text', 'contact'),
('whatsapp', '905550000000', 'text', 'contact'),
('email', 'info@neysgrupinsaat.com', 'text', 'contact'),
('address', 'Çankaya, Ankara, Türkiye', 'textarea', 'contact'),
('map_embed', '<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3060.0!2d32.8597!3d39.9334!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMznCsDU2JzAwLjIiTiAzMsKwNTEnMzQuOSJF!5e0!3m2!1str!2str!4v1" width="100%" height="450" style="border:0;" allowfullscreen="" loading="lazy"></iframe>', 'textarea', 'contact'),
('working_hours', 'Pazartesi - Cuma: 09:00 - 18:00', 'text', 'contact'),
('footer_text', 'Neys Grup İnşaat - Kalite ve güvenin adresi', 'textarea', 'general'),
('facebook', 'https://facebook.com/neysgrupinsaat', 'text', 'social'),
('instagram', 'https://instagram.com/neysgrupinsaat', 'text', 'social'),
('linkedin', 'https://linkedin.com/company/neysgrupinsaat', 'text', 'social'),
('youtube', 'https://youtube.com/@neysgrupinsaat', 'text', 'social'),
('twitter', '', 'text', 'social'),
('google_analytics', '', 'text', 'seo'),
('maintenance_mode', '0', 'boolean', 'general'),
('cookie_notice', '1', 'boolean', 'general');

-- Genel çeviri anahtarları
INSERT INTO translation_keys (`key`, group_name, description) VALUES
('nav_home', 'menu', 'Ana Sayfa menü'),
('nav_about', 'menu', 'Hakkımızda menü'),
('nav_services', 'menu', 'Hizmetler menü'),
('nav_projects', 'menu', 'Projeler menü'),
('nav_ongoing', 'menu', 'Devam Eden Projeler'),
('nav_completed', 'menu', 'Tamamlanan Projeler'),
('nav_contact', 'menu', 'İletişim menü'),
('btn_read_more', 'buttons', 'Devamını Oku'),
('btn_view_details', 'buttons', 'Detayları Gör'),
('btn_contact_us', 'buttons', 'Bize Ulaşın'),
('btn_send_message', 'buttons', 'Mesaj Gönder'),
('btn_all_projects', 'buttons', 'Tüm Projeler'),
('btn_all_services', 'buttons', 'Tüm Hizmetler'),
('status_ongoing', 'projects', 'Devam Ediyor'),
('status_completed', 'projects', 'Tamamlandı'),
('home_about_title', 'home', 'Ana sayfa hakkımızda başlık'),
('home_about_text', 'home', 'Ana sayfa hakkımızda metin'),
('home_services_title', 'home', 'Hizmetler başlık'),
('home_services_subtitle', 'home', 'Hizmetler alt başlık'),
('home_projects_title', 'home', 'Projeler başlık'),
('home_projects_subtitle', 'home', 'Projeler alt başlık'),
('home_contact_title', 'home', 'İletişim başlık'),
('home_contact_subtitle', 'home', 'İletişim alt başlık'),
('home_map_text', 'home', 'Harita alt metin'),
('footer_quick_links', 'footer', 'Hızlı Linkler'),
('footer_contact', 'footer', 'İletişim'),
('footer_follow_us', 'footer', 'Bizi Takip Edin'),
('footer_copyright', 'footer', 'Telif hakkı'),
('search_placeholder', 'general', 'Arama placeholder'),
('search_no_results', 'general', 'Sonuç bulunamadı'),
('breadcrumb_home', 'general', 'Breadcrumb ana sayfa'),
('back_to_top', 'general', 'Yukarı çık'),
('cookie_title', 'cookie', 'Çerez başlık'),
('cookie_text', 'cookie', 'Çerez metin'),
('cookie_accept', 'cookie', 'Çerez kabul'),
('cookie_decline', 'cookie', 'Çerez red'),
('form_name', 'form', 'Ad Soyad'),
('form_email', 'form', 'E-posta'),
('form_phone', 'form', 'Telefon'),
('form_subject', 'form', 'Konu'),
('form_message', 'form', 'Mesaj'),
('form_success', 'form', 'Başarı mesajı'),
('form_error', 'form', 'Hata mesajı'),
('404_title', 'errors', '404 başlık'),
('404_text', 'errors', '404 metin'),
('404_btn', 'errors', '404 buton'),
('project_location', 'projects', 'Lokasyon'),
('project_start_date', 'projects', 'Başlangıç'),
('project_end_date', 'projects', 'Teslim'),
('project_area', 'projects', 'Metrekare'),
('project_status', 'projects', 'Durum'),
('project_gallery', 'projects', 'Galeri'),
('project_video', 'projects', 'Video'),
('project_brochure', 'projects', 'Broşür'),
('project_description', 'projects', 'Açıklama'),
('filter_all', 'projects', 'Tümü'),
('filter_ongoing', 'projects', 'Devam Eden'),
('filter_completed', 'projects', 'Tamamlanan'),
('about_vision', 'about', 'Vizyon'),
('about_mission', 'about', 'Misyon'),
('about_quality', 'about', 'Kalite Politikası'),
('about_values', 'about', 'Değerlerimiz'),
('about_why_us', 'about', 'Neden Biz'),
('about_timeline', 'about', 'Tarihçe'),
('about_story', 'about', 'Hikayemiz'),
('maintenance_title', 'maintenance', 'Bakım başlık'),
('maintenance_text', 'maintenance', 'Bakım metin'),
('loading', 'general', 'Yükleniyor'),
('phone_label', 'contact', 'Telefon'),
('email_label', 'contact', 'E-posta'),
('address_label', 'contact', 'Adres'),
('whatsapp_label', 'contact', 'WhatsApp'),
('working_hours_label', 'contact', 'Çalışma Saatleri');

-- Türkçe çeviriler
INSERT INTO translations (key_id, language_id, value)
SELECT tk.id, 1,
CASE tk.`key`
  WHEN 'nav_home' THEN 'Ana Sayfa'
  WHEN 'nav_about' THEN 'Hakkımızda'
  WHEN 'nav_services' THEN 'Hizmetlerimiz'
  WHEN 'nav_projects' THEN 'Projeler'
  WHEN 'nav_ongoing' THEN 'Devam Eden Projeler'
  WHEN 'nav_completed' THEN 'Tamamlanan Projeler'
  WHEN 'nav_contact' THEN 'İletişim'
  WHEN 'btn_read_more' THEN 'Devamını Oku'
  WHEN 'btn_view_details' THEN 'Detayları Gör'
  WHEN 'btn_contact_us' THEN 'Bize Ulaşın'
  WHEN 'btn_send_message' THEN 'Mesaj Gönder'
  WHEN 'btn_all_projects' THEN 'Tüm Projeler'
  WHEN 'btn_all_services' THEN 'Tüm Hizmetler'
  WHEN 'status_ongoing' THEN 'Devam Ediyor'
  WHEN 'status_completed' THEN 'Tamamlandı'
  WHEN 'home_about_title' THEN 'Neys Grup İnşaat Hakkında'
  WHEN 'home_about_text' THEN 'Neys Grup İnşaat, konut projelerinden villa inşaatına, taahhüt işlerinden anahtar teslim projelere kadar geniş bir yelpazede kalite, güven ve profesyonellik anlayışıyla hizmet vermektedir. Modern mühendislik ve mimarlık çözümleriyle geleceğin yaşam alanlarını inşa ediyoruz.'
  WHEN 'home_services_title' THEN 'Hizmetlerimiz'
  WHEN 'home_services_subtitle' THEN 'Profesyonel inşaat çözümleri'
  WHEN 'home_projects_title' THEN 'Projelerimiz'
  WHEN 'home_projects_subtitle' THEN 'Güven ve kalitenin somut yansıması'
  WHEN 'home_contact_title' THEN 'Projenizi Birlikte Hayata Geçirelim'
  WHEN 'home_contact_subtitle' THEN 'Uzman ekibimiz tüm sorularınız için hazır'
  WHEN 'home_map_text' THEN 'Neys Grup İnşaat merkez ofisimiz Ankara''da hizmet vermektedir. Projeleriniz için bizimle iletişime geçebilirsiniz.'
  WHEN 'footer_quick_links' THEN 'Hızlı Linkler'
  WHEN 'footer_contact' THEN 'İletişim'
  WHEN 'footer_follow_us' THEN 'Bizi Takip Edin'
  WHEN 'footer_copyright' THEN '© 2026 Neys Grup İnşaat. Tüm hakları saklıdır.'
  WHEN 'search_placeholder' THEN 'Site içinde ara...'
  WHEN 'search_no_results' THEN 'Aradığınız kriterlere uygun sonuç bulunamadı.'
  WHEN 'breadcrumb_home' THEN 'Ana Sayfa'
  WHEN 'back_to_top' THEN 'Yukarı'
  WHEN 'cookie_title' THEN 'Çerez Kullanımı'
  WHEN 'cookie_text' THEN 'Web sitemizde deneyiminizi geliştirmek için çerezler kullanıyoruz. Devam ederek çerez politikamızı kabul etmiş olursunuz.'
  WHEN 'cookie_accept' THEN 'Kabul Et'
  WHEN 'cookie_decline' THEN 'Reddet'
  WHEN 'form_name' THEN 'Ad Soyad'
  WHEN 'form_email' THEN 'E-posta'
  WHEN 'form_phone' THEN 'Telefon'
  WHEN 'form_subject' THEN 'Konu'
  WHEN 'form_message' THEN 'Mesajınız'
  WHEN 'form_success' THEN 'Mesajınız başarıyla iletildi. En kısa sürede size dönüş yapacağız.'
  WHEN 'form_error' THEN 'Mesaj gönderilirken bir hata oluştu. Lütfen tekrar deneyin.'
  WHEN '404_title' THEN 'Sayfa Bulunamadı'
  WHEN '404_text' THEN 'Aradığınız sayfa taşınmış, silinmiş veya hiç var olmamış olabilir.'
  WHEN '404_btn' THEN 'Ana Sayfaya Dön'
  WHEN 'project_location' THEN 'Lokasyon'
  WHEN 'project_start_date' THEN 'Başlangıç Tarihi'
  WHEN 'project_end_date' THEN 'Teslim Tarihi'
  WHEN 'project_area' THEN 'Metrekare'
  WHEN 'project_status' THEN 'Durum'
  WHEN 'project_gallery' THEN 'Fotoğraf Galerisi'
  WHEN 'project_video' THEN 'Proje Videosu'
  WHEN 'project_brochure' THEN 'PDF Broşür'
  WHEN 'project_description' THEN 'Proje Açıklaması'
  WHEN 'filter_all' THEN 'Tümü'
  WHEN 'filter_ongoing' THEN 'Devam Eden'
  WHEN 'filter_completed' THEN 'Tamamlanan'
  WHEN 'about_vision' THEN 'Vizyonumuz'
  WHEN 'about_mission' THEN 'Misyonumuz'
  WHEN 'about_quality' THEN 'Kalite Politikamız'
  WHEN 'about_values' THEN 'Değerlerimiz'
  WHEN 'about_why_us' THEN 'Neden Neys Grup?'
  WHEN 'about_timeline' THEN 'Tarihçemiz'
  WHEN 'about_story' THEN 'Hikayemiz'
  WHEN 'maintenance_title' THEN 'Bakım Modu'
  WHEN 'maintenance_text' THEN 'Sitemiz şu anda bakım çalışması nedeniyle geçici olarak kapalıdır.'
  WHEN 'loading' THEN 'Yükleniyor...'
  WHEN 'phone_label' THEN 'Telefon'
  WHEN 'email_label' THEN 'E-posta'
  WHEN 'address_label' THEN 'Adres'
  WHEN 'whatsapp_label' THEN 'WhatsApp'
  WHEN 'working_hours_label' THEN 'Çalışma Saatleri'
END
FROM translation_keys tk;

-- İngilizce çeviriler
INSERT INTO translations (key_id, language_id, value)
SELECT tk.id, 2,
CASE tk.`key`
  WHEN 'nav_home' THEN 'Home'
  WHEN 'nav_about' THEN 'About Us'
  WHEN 'nav_services' THEN 'Services'
  WHEN 'nav_projects' THEN 'Projects'
  WHEN 'nav_ongoing' THEN 'Ongoing Projects'
  WHEN 'nav_completed' THEN 'Completed Projects'
  WHEN 'nav_contact' THEN 'Contact'
  WHEN 'btn_read_more' THEN 'Read More'
  WHEN 'btn_view_details' THEN 'View Details'
  WHEN 'btn_contact_us' THEN 'Contact Us'
  WHEN 'btn_send_message' THEN 'Send Message'
  WHEN 'btn_all_projects' THEN 'All Projects'
  WHEN 'btn_all_services' THEN 'All Services'
  WHEN 'status_ongoing' THEN 'Ongoing'
  WHEN 'status_completed' THEN 'Completed'
  WHEN 'home_about_title' THEN 'About Neys Grup Construction'
  WHEN 'home_about_text' THEN 'Neys Grup Construction provides quality, trust and professionalism across residential projects, villa construction, contracting and turnkey solutions. We build the living spaces of the future with modern engineering and architectural solutions.'
  WHEN 'home_services_title' THEN 'Our Services'
  WHEN 'home_services_subtitle' THEN 'Professional construction solutions'
  WHEN 'home_projects_title' THEN 'Our Projects'
  WHEN 'home_projects_subtitle' THEN 'The tangible reflection of trust and quality'
  WHEN 'home_contact_title' THEN 'Let''s Bring Your Project to Life'
  WHEN 'home_contact_subtitle' THEN 'Our expert team is ready for all your questions'
  WHEN 'home_map_text' THEN 'Neys Grup Construction serves from our headquarters in Ankara. Contact us for your projects.'
  WHEN 'footer_quick_links' THEN 'Quick Links'
  WHEN 'footer_contact' THEN 'Contact'
  WHEN 'footer_follow_us' THEN 'Follow Us'
  WHEN 'footer_copyright' THEN '© 2026 Neys Grup Construction. All rights reserved.'
  WHEN 'search_placeholder' THEN 'Search the site...'
  WHEN 'search_no_results' THEN 'No results found matching your criteria.'
  WHEN 'breadcrumb_home' THEN 'Home'
  WHEN 'back_to_top' THEN 'Top'
  WHEN 'cookie_title' THEN 'Cookie Usage'
  WHEN 'cookie_text' THEN 'We use cookies to improve your experience on our website. By continuing, you accept our cookie policy.'
  WHEN 'cookie_accept' THEN 'Accept'
  WHEN 'cookie_decline' THEN 'Decline'
  WHEN 'form_name' THEN 'Full Name'
  WHEN 'form_email' THEN 'Email'
  WHEN 'form_phone' THEN 'Phone'
  WHEN 'form_subject' THEN 'Subject'
  WHEN 'form_message' THEN 'Your Message'
  WHEN 'form_success' THEN 'Your message has been sent successfully. We will get back to you shortly.'
  WHEN 'form_error' THEN 'An error occurred while sending your message. Please try again.'
  WHEN '404_title' THEN 'Page Not Found'
  WHEN '404_text' THEN 'The page you are looking for may have been moved, deleted or never existed.'
  WHEN '404_btn' THEN 'Back to Home'
  WHEN 'project_location' THEN 'Location'
  WHEN 'project_start_date' THEN 'Start Date'
  WHEN 'project_end_date' THEN 'Delivery Date'
  WHEN 'project_area' THEN 'Square Meters'
  WHEN 'project_status' THEN 'Status'
  WHEN 'project_gallery' THEN 'Photo Gallery'
  WHEN 'project_video' THEN 'Project Video'
  WHEN 'project_brochure' THEN 'PDF Brochure'
  WHEN 'project_description' THEN 'Project Description'
  WHEN 'filter_all' THEN 'All'
  WHEN 'filter_ongoing' THEN 'Ongoing'
  WHEN 'filter_completed' THEN 'Completed'
  WHEN 'about_vision' THEN 'Our Vision'
  WHEN 'about_mission' THEN 'Our Mission'
  WHEN 'about_quality' THEN 'Quality Policy'
  WHEN 'about_values' THEN 'Our Values'
  WHEN 'about_why_us' THEN 'Why Neys Grup?'
  WHEN 'about_timeline' THEN 'Our History'
  WHEN 'about_story' THEN 'Our Story'
  WHEN 'maintenance_title' THEN 'Maintenance Mode'
  WHEN 'maintenance_text' THEN 'Our website is temporarily unavailable due to maintenance work.'
  WHEN 'loading' THEN 'Loading...'
  WHEN 'phone_label' THEN 'Phone'
  WHEN 'email_label' THEN 'Email'
  WHEN 'address_label' THEN 'Address'
  WHEN 'whatsapp_label' THEN 'WhatsApp'
  WHEN 'working_hours_label' THEN 'Working Hours'
END
FROM translation_keys tk;

-- Kürtçe çeviriler
INSERT INTO translations (key_id, language_id, value)
SELECT tk.id, 3,
CASE tk.`key`
  WHEN 'nav_home' THEN 'Serûpel'
  WHEN 'nav_about' THEN 'Derbarê Me'
  WHEN 'nav_services' THEN 'Xizmetên Me'
  WHEN 'nav_projects' THEN 'Projeyên'
  WHEN 'nav_ongoing' THEN 'Projeyên Domdar'
  WHEN 'nav_completed' THEN 'Projeyên Qediyayî'
  WHEN 'nav_contact' THEN 'Têkilî'
  WHEN 'btn_read_more' THEN 'Zêdetir Bixwîne'
  WHEN 'btn_view_details' THEN 'Detayan Bibîne'
  WHEN 'btn_contact_us' THEN 'Bi Me re Têkilî Daynin'
  WHEN 'btn_send_message' THEN 'Peyam Bişîne'
  WHEN 'btn_all_projects' THEN 'Hemû Projeyên'
  WHEN 'btn_all_services' THEN 'Hemû Xizmetên'
  WHEN 'status_ongoing' THEN 'Domdar e'
  WHEN 'status_completed' THEN 'Qediyaye'
  WHEN 'home_about_title' THEN 'Derbarê Neys Grup Avahîkariyê'
  WHEN 'home_about_text' THEN 'Neys Grup Avahîkariyê bi taybetmendî, bawerî û profesyonelî li ser projeyên niştecîh, avakirina villa, peymana avahîkariyê û çareseriyên bi kilîtê radest dike.'
  WHEN 'home_services_title' THEN 'Xizmetên Me'
  WHEN 'home_services_subtitle' THEN 'Çareseriyên avahîkariyê yên profesyonel'
  WHEN 'home_projects_title' THEN 'Projeyên Me'
  WHEN 'home_projects_subtitle' THEN 'Nîşana bawerî û taybetmendiyê'
  WHEN 'home_contact_title' THEN 'Bi Hev re Projeya We Biafirînin'
  WHEN 'home_contact_subtitle' THEN 'Tîma me ya pispor amade ye ji bo hemû pirsên we'
  WHEN 'home_contact_title' THEN 'Bi Hev re Projeya We Biafirînin'
  WHEN 'home_map_text' THEN 'Neys Grup Avahîkariyê ji navenda xwe li Ankara xizmetê dide.'
  WHEN 'footer_quick_links' THEN 'Girêdanên Lez'
  WHEN 'footer_contact' THEN 'Têkilî'
  WHEN 'footer_follow_us' THEN 'Me Bişopînin'
  WHEN 'footer_copyright' THEN '© 2026 Neys Grup Avahîkariyê. Hemû maf parastî ne.'
  WHEN 'search_placeholder' THEN 'Li malperê bigere...'
  WHEN 'search_no_results' THEN 'Encam nehat dîtin.'
  WHEN 'breadcrumb_home' THEN 'Serûpel'
  WHEN 'back_to_top' THEN 'Jor'
  WHEN 'cookie_title' THEN 'Bikaranîna Cookie'
  WHEN 'cookie_text' THEN 'Em cookie bikar tînin da ku ezmûna we baştir bikin.'
  WHEN 'cookie_accept' THEN 'Qebûl Bike'
  WHEN 'cookie_decline' THEN 'Red Bike'
  WHEN 'form_name' THEN 'Nav û Paşnav'
  WHEN 'form_email' THEN 'E-posta'
  WHEN 'form_phone' THEN 'Telefon'
  WHEN 'form_subject' THEN 'Mijar'
  WHEN 'form_message' THEN 'Peyama We'
  WHEN 'form_success' THEN 'Peyama we bi serkeftî hat şandin.'
  WHEN 'form_error' THEN 'Di şandina peyamê de çewtî derket.'
  WHEN '404_title' THEN 'Rûpel Nehat Dîtin'
  WHEN '404_text' THEN 'Rûpela ku hûn lê digerin dibe ku nehatiye dîtin.'
  WHEN '404_btn' THEN 'Vegere Serûpelê'
  WHEN 'project_location' THEN 'Cih'
  WHEN 'project_start_date' THEN 'Dîroka Destpêkê'
  WHEN 'project_end_date' THEN 'Dîroka Radestkirinê'
  WHEN 'project_area' THEN 'Metrekare'
  WHEN 'project_status' THEN 'Rewş'
  WHEN 'project_gallery' THEN 'Galeriya Wêneyan'
  WHEN 'project_video' THEN 'Vîdyoya Projeyê'
  WHEN 'project_brochure' THEN 'Broşûra PDF'
  WHEN 'project_description' THEN 'Danasîna Projeyê'
  WHEN 'filter_all' THEN 'Hemû'
  WHEN 'filter_ongoing' THEN 'Domdar'
  WHEN 'filter_completed' THEN 'Qediyayî'
  WHEN 'about_vision' THEN 'Dîtina Me'
  WHEN 'about_mission' THEN 'Mîsyona Me'
  WHEN 'about_quality' THEN 'Polîtîkaya Taybetmendiyê'
  WHEN 'about_values' THEN 'Nirxên Me'
  WHEN 'about_why_us' THEN 'Çima Neys Grup?'
  WHEN 'about_timeline' THEN 'Dîrok'
  WHEN 'about_story' THEN 'Çîroka Me'
  WHEN 'maintenance_title' THEN 'Moda Parastinê'
  WHEN 'maintenance_text' THEN 'Malpera me demkî girtî ye ji ber karên parastinê.'
  WHEN 'loading' THEN 'Tê barkirin...'
  WHEN 'phone_label' THEN 'Telefon'
  WHEN 'email_label' THEN 'E-posta'
  WHEN 'address_label' THEN 'Navnîşan'
  WHEN 'whatsapp_label' THEN 'WhatsApp'
  WHEN 'working_hours_label' THEN 'Saetên Xebatê'
END
FROM translation_keys tk;

-- Slider
INSERT INTO sliders (image, sort_order) VALUES
('assets/images/slider/slider-1.svg', 1),
('assets/images/slider/slider-2.svg', 2),
('assets/images/slider/slider-3.svg', 3);

INSERT INTO slider_translations (slider_id, language_id, title, subtitle, button_text, button_link) VALUES
(1, 1, 'Geleceği Birlikte İnşa Ediyoruz', 'Konut projelerinden anahtar teslim çözümlere kadar profesyonel hizmet', 'Projelerimiz', '/projeler'),
(1, 2, 'Building the Future Together', 'Professional service from residential projects to turnkey solutions', 'Our Projects', '/en/projects'),
(1, 3, 'Pêşerojê Bi Hev re Avadikin', 'Xizmeta profesyonel ji projeyên niştecîh heta çareseriyên bi kilîtê', 'Projeyên Me', '/ku/projeyen'),
(2, 1, 'Kalite ve Güven ile', 'Modern mühendislik ve mimarlık standartlarında projeler', 'Hizmetlerimiz', '/hizmetler'),
(2, 2, 'With Quality and Trust', 'Projects with modern engineering and architectural standards', 'Our Services', '/en/services'),
(2, 3, 'Bi Taybetmendî û Bawerî', 'Projeyên bi standardên modern', 'Xizmetên Me', '/ku/xizmeten'),
(3, 1, 'Güvenli Yaşam Alanları', 'Deprem dayanıklı, sürdürülebilir yapılar inşa ediyoruz', 'Bize Ulaşın', '/iletisim'),
(3, 2, 'Safe Living Spaces', 'We build earthquake-resistant, sustainable structures', 'Contact Us', '/en/contact'),
(3, 3, 'Cihên Jiyanê yên Ewle', 'Em avahiyên domdar avadikin', 'Bi Me re Têkilî', '/ku/tekili');

-- Hakkımızda bölümleri
INSERT INTO about_sections (section_key, image, video_url, sort_order) VALUES
('story', 'assets/images/about/about-main.svg', 'https://www.youtube.com/embed/dQw4w9WgXcQ', 1),
('vision', NULL, NULL, 2),
('mission', NULL, NULL, 3),
('quality', NULL, NULL, 4),
('values', NULL, NULL, 5),
('why_us', 'assets/images/about/why-us.svg', NULL, 6);

INSERT INTO about_translations (section_id, language_id, title, content) VALUES
(1, 1, 'Hikayemiz', 'Neys Grup İnşaat, inşaat sektöründe yılların deneyimi ve uzman kadrosuyla Türkiye''nin önde gelen inşaat firmalarından biri haline gelmiştir. Konut projelerinden villa inşaatına, taahhüt işlerinden anahtar teslim projelere kadar geniş bir yelpazede faaliyet göstermekteyiz.'),
(1, 2, 'Our Story', 'Neys Grup Construction has become one of Turkey''s leading construction companies with years of experience and an expert team in the construction sector.'),
(1, 3, 'Çîroka Me', 'Neys Grup Avahîkariyê bi salan tecrûbe û tîma pispor bûye yek ji pargîdaniyên sereke yên avahîkariyê li Tirkiyeyê.'),
(2, 1, 'Vizyonumuz', 'İnşaat sektöründe yenilikçi çözümlerle öncü olmak, sürdürülebilir ve güvenli yaşam alanları oluşturarak geleceğe değer katmak.'),
(2, 2, 'Our Vision', 'To be a pioneer in the construction sector with innovative solutions and add value to the future by creating sustainable and safe living spaces.'),
(2, 3, 'Dîtina Me', 'Di sektora avahîkariyê de bi çareseriyên nûjen pêşeng bibe.'),
(3, 1, 'Misyonumuz', 'Müşteri memnuniyetini ön planda tutarak, kaliteli, güvenilir ve zamanında teslim edilen projeler üretmek.'),
(3, 2, 'Our Mission', 'To produce quality, reliable and on-time delivered projects by prioritizing customer satisfaction.'),
(3, 3, 'Mîsyona Me', 'Bi pêşîgirtina razîbûna xerîdar, projeyên bi taybetmendî û bi wextê radest bikin.'),
(4, 1, 'Kalite Politikamız', 'Tüm projelerimizde ulusal ve uluslararası standartlara uygunluk, sürekli iyileştirme ve müşteri odaklılık temel prensiplerimizdir.'),
(4, 2, 'Quality Policy', 'Compliance with national and international standards, continuous improvement and customer focus are our fundamental principles.'),
(4, 3, 'Polîtîkaya Taybetmendiyê', 'Li hemû projeyên me standardên neteweyî û navneteweyî têne rêzkirin.'),
(5, 1, 'Değerlerimiz', 'Dürüstlük, şeffaflık, kalite, güvenilirlik, takım çalışması ve sürdürülebilirlik temel değerlerimizdir.'),
(5, 2, 'Our Values', 'Honesty, transparency, quality, reliability, teamwork and sustainability are our core values.'),
(5, 3, 'Nirxên Me', 'Rastî, zelalî, taybetmendî, bawerî û domdarî nirxên me yên bingehîn in.'),
(6, 1, 'Neden Neys Grup?', 'Deneyimli kadro, modern ekipman, zamanında teslimat, rekabetçi fiyatlar ve müşteri odaklı yaklaşımımızla fark yaratıyoruz.'),
(6, 2, 'Why Neys Grup?', 'We make a difference with our experienced team, modern equipment, on-time delivery and customer-focused approach.'),
(6, 3, 'Çima Neys Grup?', 'Em bi tîma xwe ya bi tecrûbe û nêzîkatiya xerîdar cudahî diafirînin.');

-- Timeline
INSERT INTO timeline_items (year, sort_order) VALUES ('2010', 1), ('2015', 2), ('2020', 3), ('2026', 4);
INSERT INTO timeline_translations (timeline_id, language_id, title, description) VALUES
(1, 1, 'Kuruluş', 'Neys Grup İnşaat Ankara''da kuruldu.'),
(1, 2, 'Foundation', 'Neys Grup Construction was founded in Ankara.'),
(1, 3, 'Damezrandin', 'Neys Grup li Ankara hate damezrandin.'),
(2, 1, 'Büyüme', '100+ konut projesi tamamlandı.'),
(2, 2, 'Growth', '100+ residential projects completed.'),
(2, 3, 'Mezinbûn', '100+ projeyên niştecîh qediyane.'),
(3, 1, 'Genişleme', 'Villa ve taahhüt departmanları kuruldu.'),
(3, 2, 'Expansion', 'Villa and contracting departments established.'),
(3, 3, 'Firehkirin', 'Beşên villa û peyman hatin avakirin.'),
(4, 1, 'Bugün', 'Türkiye genelinde aktif projeler.'),
(4, 2, 'Today', 'Active projects across Turkey.'),
(4, 3, 'Îro', 'Projeyên çalak li Tirkiyeyê.');

-- Hizmetler
INSERT INTO services (icon, image, sort_order) VALUES
('bi-house-door', 'assets/images/services/konut.svg', 1),
('bi-building', 'assets/images/services/villa.svg', 2),
('bi-hammer', 'assets/images/services/taahhut.svg', 3),
('bi-key', 'assets/images/services/anahtar.svg', 4),
('bi-gear', 'assets/images/services/muhendislik.svg', 5),
('bi-pencil-square', 'assets/images/services/mimarlik.svg', 6),
('bi-chat-dots', 'assets/images/services/danismanlik.svg', 7);

INSERT INTO service_translations (service_id, language_id, title, short_description, description, slug) VALUES
(1, 1, 'Konut Projeleri', 'Modern ve güvenli konut projeleri', 'Toplu konut, site ve rezidans projelerinde anahtar teslim çözümler sunuyoruz.', 'konut-projeleri'),
(1, 2, 'Residential Projects', 'Modern and safe residential projects', 'We offer turnkey solutions in mass housing, site and residence projects.', 'residential-projects'),
(1, 3, 'Projeyên Niştecîh', 'Projeyên niştecîh yên modern', 'Em çareseriyên bi kilîtê radest dikin.', 'projeyen-nistecih'),
(2, 1, 'Villa İnşaatı', 'Lüks villa projeleri', 'Özel tasarım villa projelerinde mimari ve mühendislik uzmanlığı.', 'villa-insaati'),
(2, 2, 'Villa Construction', 'Luxury villa projects', 'Architectural and engineering expertise in custom villa projects.', 'villa-construction'),
(2, 3, 'Avakirina Villa', 'Projeyên villa yên luks', 'Pisporiya mimarî û endezyarî.', 'avakirina-villa'),
(3, 1, 'Taahhüt İşleri', 'Kapsamlı taahhüt hizmetleri', 'Altyapıdan üstyapıya tüm inşaat taahhüt işlerinde deneyimli ekibimizle hizmetinizdeyiz.', 'taahhut-isleri'),
(3, 2, 'Contracting', 'Comprehensive contracting services', 'We serve with our experienced team in all construction contracting works.', 'contracting'),
(3, 3, 'Peymana Avahîkariyê', 'Xizmetên peymanê yên berfireh', 'Em bi tîma xwe ya bi tecrûbe xizmetê dikin.', 'peymana-avahikariye'),
(4, 1, 'Anahtar Teslim', 'Baştan sona proje yönetimi', 'Projelerinizi tasarımdan teslimata kadar tek elden yönetiyoruz.', 'anahtar-teslim'),
(4, 2, 'Turnkey', 'End-to-end project management', 'We manage your projects from design to delivery.', 'turnkey'),
(4, 3, 'Bi Kilîtê Radest', 'Rêveberiya projeyê ji destpêkê heta dawiyê', 'Em projeyên we bi kilîtê radest dikin.', 'bi-kilite-radest'),
(5, 1, 'Mühendislik', 'Profesyonel mühendislik hizmetleri', 'Statik, mekanik ve elektrik mühendisliği alanlarında uzman kadro.', 'muhendislik'),
(5, 2, 'Engineering', 'Professional engineering services', 'Expert team in structural, mechanical and electrical engineering.', 'engineering'),
(5, 3, 'Endezyarî', 'Xizmetên endezyariyê yên profesyonel', 'Tîma pispor li statîk, mekanîk û elektrîkê.', 'endezyari'),
(6, 1, 'Mimarlık', 'Yaratıcı mimari tasarımlar', 'Estetik ve fonksiyonel mimari projeler tasarlıyoruz.', 'mimarlik'),
(6, 2, 'Architecture', 'Creative architectural designs', 'We design aesthetic and functional architectural projects.', 'architecture'),
(6, 3, 'Mimarî', 'Sêwirana mimari ya afirîner', 'Em projeyên estetîk û fonksîonal sêwir dikin.', 'mimari'),
(7, 1, 'İnşaat Danışmanlığı', 'Uzman danışmanlık hizmetleri', 'Proje fizibilitesi, maliyet analizi ve süreç yönetimi danışmanlığı.', 'insaat-danismanligi'),
(7, 2, 'Construction Consulting', 'Expert consulting services', 'Project feasibility, cost analysis and process management consulting.', 'construction-consulting'),
(7, 3, 'Şêwirmendiya Avahîkariyê', 'Xizmetên şêwirmendiyê yên pispor', 'Fizîbilîte, analîza lêçûnê û şêwirmendiya prosesê.', 'sewirmendiya-avahikariye');

-- İstatistikler
INSERT INTO statistics (stat_key, stat_value, icon, sort_order) VALUES
('completed_projects', 150, 'bi-check-circle', 1),
('ongoing_projects', 12, 'bi-arrow-repeat', 2),
('happy_clients', 500, 'bi-people', 3),
('years_experience', 15, 'bi-calendar-check', 4);

INSERT INTO statistic_translations (statistic_id, language_id, label) VALUES
(1, 1, 'Tamamlanan Proje'), (1, 2, 'Completed Projects'), (1, 3, 'Projeyên Qediyayî'),
(2, 1, 'Devam Eden Proje'), (2, 2, 'Ongoing Projects'), (2, 3, 'Projeyên Domdar'),
(3, 1, 'Mutlu Müşteri'), (3, 2, 'Happy Clients'), (3, 3, 'Xerîdarên Kêfxweş'),
(4, 1, 'Yıllık Deneyim'), (4, 2, 'Years of Experience'), (4, 3, 'Sal Tecrûbe');

-- Örnek Projeler
INSERT INTO projects (cover_image, category, location, start_date, end_date, area_sqm, sort_order, is_featured, show_homepage) VALUES
('assets/images/projects/project-1.svg', 'ongoing', 'Ankara, Çankaya', '2024-01-15', '2026-06-30', 45000.00, 1, 1, 1),
('assets/images/projects/project-2.svg', 'ongoing', 'İstanbul, Ümraniye', '2023-06-01', '2025-12-31', 32000.00, 2, 1, 1),
('assets/images/projects/project-3.svg', 'completed', 'Ankara, Etimesgut', '2021-03-01', '2023-08-15', 28000.00, 3, 1, 1),
('assets/images/projects/project-4.svg', 'completed', 'Antalya, Alanya', '2019-05-10', '2022-11-20', 15000.00, 4, 0, 1),
('assets/images/projects/project-5.svg', 'completed', 'İzmir, Bornova', '2020-01-20', '2022-05-30', 22000.00, 5, 0, 1),
('assets/images/projects/project-6.svg', 'ongoing', 'Bursa, Nilüfer', '2024-09-01', '2027-03-31', 55000.00, 6, 0, 1);

INSERT INTO project_translations (project_id, language_id, title, slug, short_description, description, meta_title, meta_description) VALUES
(1, 1, 'Çankaya Lüks Konut Projesi', 'cankaya-luks-konut', 'Ankara Çankaya''da 120 daireli lüks konut projesi', 'Modern mimari anlayışla tasarlanan 120 daireli lüks konut projemiz, sosyal alanlar, kapalı otopark ve yeşil alanlarıyla öne çıkmaktadır.', 'Çankaya Lüks Konut Projesi | Neys Grup', 'Ankara Çankaya lüks konut projesi'),
(1, 2, 'Cankaya Luxury Residence', 'cankaya-luxury-residence', '120-unit luxury residential project in Ankara', 'Our 120-unit luxury residential project stands out with social areas, indoor parking and green spaces.', 'Cankaya Luxury Residence | Neys Grup', 'Luxury residential project in Ankara'),
(1, 3, 'Projeya Niştecîh a Luks a Çankaya', 'cankaya-luks-nistecih', 'Projeya 120 xaniyan li Ankara', 'Projeya me ya 120 xaniyan bi aliyên civakî û otoparka girtî.', 'Projeya Luks | Neys Grup', 'Projeya niştecîh li Ankara'),
(2, 1, 'Ümraniye Modern Site', 'umraniye-modern-site', 'İstanbul Ümraniye''de 200 daireli modern site projesi', '200 daireli modern site projemiz, aile dostu tasarımı ve geniş yeşil alanlarıyla dikkat çekiyor.', 'Ümraniye Modern Site | Neys Grup', 'Modern site projesi İstanbul'),
(2, 2, 'Umraniye Modern Site', 'umraniye-modern-site-en', '200-unit modern site project in Istanbul', 'Our 200-unit modern site project stands out with family-friendly design.', 'Umraniye Modern Site | Neys Grup', 'Modern site project Istanbul'),
(2, 3, 'Siteya Modern a Ümraniye', 'umraniye-modern-site-ku', 'Projeya 200 xaniyan li Stenbolê', 'Projeya me ya 200 xaniyan bi sêwirana malbatê.', 'Siteya Modern | Neys Grup', 'Projeya site li Stenbolê'),
(3, 1, 'Etimesgut Konut Kompleksi', 'etimesgut-konut', 'Ankara Etimesgut''ta tamamlanan 85 daireli konut kompleksi', '85 daireli konut kompleksimiz başarıyla tamamlanmış ve teslim edilmiştir.', 'Etimesgut Konut | Neys Grup', 'Tamamlanan konut projesi'),
(3, 2, 'Etimesgut Housing Complex', 'etimesgut-housing', 'Completed 85-unit housing complex in Ankara', 'Our 85-unit housing complex has been successfully completed and delivered.', 'Etimesgut Housing | Neys Grup', 'Completed housing project'),
(3, 3, 'Kompleksa Niştecîh a Etimesgut', 'etimesgut-nistecih', 'Kompleksa 85 xaniyan li Ankara', 'Kompleksa me bi serkeftî qediyaye.', 'Etimesgut | Neys Grup', 'Projeya qediyayî'),
(4, 1, 'Alanya Villa Projesi', 'alanya-villa', 'Antalya Alanya''da 12 villa projesi', 'Deniz manzaralı 12 lüks villa projemiz tamamlanmıştır.', 'Alanya Villa | Neys Grup', 'Villa projesi Antalya'),
(4, 2, 'Alanya Villa Project', 'alanya-villa-en', '12 villa project in Antalya', 'Our 12 luxury villa project with sea view has been completed.', 'Alanya Villa | Neys Grup', 'Villa project Antalya'),
(4, 3, 'Projeya Villa ya Alanya', 'alanya-villa-ku', 'Projeya 12 villa li Antalya', 'Projeya me ya 12 villa qediyaye.', 'Alanya Villa | Neys Grup', 'Projeya villa'),
(5, 1, 'Bornova Ticari Merkez', 'bornova-ticari', 'İzmir Bornova ticari merkez projesi', 'Modern ticari merkez projemiz bölgeye değer katmıştır.', 'Bornova Ticari | Neys Grup', 'Ticari merkez İzmir'),
(5, 2, 'Bornova Commercial Center', 'bornova-commercial', 'Commercial center project in Izmir', 'Our modern commercial center project has added value to the region.', 'Bornova Commercial | Neys Grup', 'Commercial center Izmir'),
(5, 3, 'Navenda Bazirganî ya Bornova', 'bornova-bazirgani', 'Projeya navenda bazirganî li Îzmîrê', 'Projeya me qediyaye.', 'Bornova | Neys Grup', 'Navenda bazirganî'),
(6, 1, 'Nilüfer Mega Proje', 'nilufer-mega-proje', 'Bursa Nilüfer''de 350 daireli mega proje', '350 daireli mega projemiz inşaat aşamasındadır.', 'Nilüfer Mega Proje | Neys Grup', 'Mega proje Bursa'),
(6, 2, 'Nilufer Mega Project', 'nilufer-mega-project', '350-unit mega project in Bursa', 'Our 350-unit mega project is under construction.', 'Nilufer Mega | Neys Grup', 'Mega project Bursa'),
(6, 3, 'Projeya Mega ya Nilüfer', 'nilufer-mega-ku', 'Projeya 350 xaniyan li Bursa', 'Projeya me di avakirinê de ye.', 'Nilüfer Mega | Neys Grup', 'Projeya mega');

-- Proje görselleri
INSERT INTO project_images (project_id, image, sort_order) VALUES
(1, 'assets/images/projects/project-1.svg', 1),
(1, 'assets/images/projects/project-1b.svg', 2),
(2, 'assets/images/projects/project-2.svg', 1),
(3, 'assets/images/projects/project-3.svg', 1),
(4, 'assets/images/projects/project-4.svg', 1),
(5, 'assets/images/projects/project-5.svg', 1),
(6, 'assets/images/projects/project-6.svg', 1);

-- Yasal sayfalar
INSERT INTO pages (page_key) VALUES ('kvkk'), ('privacy'), ('cookie');
INSERT INTO page_translations (page_id, language_id, title, slug, content, meta_title, meta_description) VALUES
(1, 1, 'KVKK Aydınlatma Metni', 'kvkk', '<h2>Kişisel Verilerin Korunması</h2><p>Neys Grup İnşaat olarak kişisel verilerinizin güvenliği bizim için önemlidir. 6698 sayılı KVKK kapsamında verileriniz korunmaktadır.</p>', 'KVKK | Neys Grup İnşaat', 'KVKK aydınlatma metni'),
(1, 2, 'GDPR Information', 'gdpr', '<h2>Personal Data Protection</h2><p>As Neys Grup Construction, the security of your personal data is important to us.</p>', 'GDPR | Neys Grup', 'GDPR information'),
(1, 3, 'Agahdarkirina KVKK', 'kvkk-ku', '<h2>Parastina Daneyên Kesane</h2><p>Neys Grup wek pargîdanî ewlehiya daneyên we girîng e.</p>', 'KVKK | Neys Grup', 'Agahdarkirina KVKK'),
(2, 1, 'Gizlilik Politikası', 'gizlilik-politikasi', '<h2>Gizlilik Politikası</h2><p>Web sitemizi kullanırken gizliliğiniz bizim için önemlidir.</p>', 'Gizlilik Politikası | Neys Grup', 'Gizlilik politikası'),
(2, 2, 'Privacy Policy', 'privacy-policy', '<h2>Privacy Policy</h2><p>Your privacy is important to us when using our website.</p>', 'Privacy Policy | Neys Grup', 'Privacy policy'),
(2, 3, 'Polîtîkaya Nepenîtiyê', 'politika-nepenitiye', '<h2>Polîtîkaya Nepenîtiyê</h2><p>Nepeniya we girîng e.</p>', 'Nepenîtî | Neys Grup', 'Polîtîkaya nepenîtiyê'),
(3, 1, 'Çerez Politikası', 'cerez-politikasi', '<h2>Çerez Politikası</h2><p>Web sitemizde çerezler kullanılmaktadır.</p>', 'Çerez Politikası | Neys Grup', 'Çerez politikası'),
(3, 2, 'Cookie Policy', 'cookie-policy', '<h2>Cookie Policy</h2><p>Cookies are used on our website.</p>', 'Cookie Policy | Neys Grup', 'Cookie policy'),
(3, 3, 'Polîtîkaya Cookie', 'politika-cookie', '<h2>Polîtîkaya Cookie</h2><p>Cookie li malpera me têne bikaranîn.</p>', 'Cookie | Neys Grup', 'Polîtîkaya cookie');

-- SEO
INSERT INTO seo (page_key, language_id, meta_title, meta_description, meta_keywords, og_title, og_description) VALUES
('home', 1, 'Neys Grup İnşaat | Ankara İnşaat Firması', 'Neys Grup İnşaat - Konut, villa, taahhüt ve anahtar teslim projeler. Ankara merkezli profesyonel inşaat firması.', 'inşaat, konut, villa, anahtar teslim, ankara inşaat', 'Neys Grup İnşaat', 'Profesyonel inşaat çözümleri'),
('home', 2, 'Neys Grup Construction | Ankara Construction Company', 'Neys Grup Construction - Residential, villa, contracting and turnkey projects.', 'construction, residential, villa, turnkey, ankara', 'Neys Grup Construction', 'Professional construction solutions'),
('home', 3, 'Neys Grup Avahîkariyê | Pargîdaniya Avahîkariyê', 'Neys Grup - Projeyên niştecîh, villa û bi kilîtê radest.', 'avahîkariyê, niştecîh, villa, ankara', 'Neys Grup', 'Çareseriyên avahîkariyê'),
('about', 1, 'Hakkımızda | Neys Grup İnşaat', 'Neys Grup İnşaat hakkında bilgi edinin.', 'hakkımızda, neys grup, inşaat firması', 'Hakkımızda', 'Neys Grup İnşaat hakkında'),
('about', 2, 'About Us | Neys Grup Construction', 'Learn about Neys Grup Construction.', 'about, neys grup, construction', 'About Us', 'About Neys Grup'),
('about', 3, 'Derbarê Me | Neys Grup', 'Derbarê Neys Grup bibihîsin.', 'derbar, neys grup', 'Derbarê Me', 'Derbarê Neys Grup'),
('services', 1, 'Hizmetlerimiz | Neys Grup İnşaat', 'Konut, villa, taahhüt, anahtar teslim hizmetlerimiz.', 'hizmetler, inşaat hizmetleri', 'Hizmetlerimiz', 'Profesyonel inşaat hizmetleri'),
('services', 2, 'Services | Neys Grup Construction', 'Our residential, villa, contracting services.', 'services, construction services', 'Services', 'Professional construction services'),
('services', 3, 'Xizmetên Me | Neys Grup', 'Xizmetên me yên avahîkariyê.', 'xizmet, avahîkariyê', 'Xizmetên Me', 'Xizmetên profesyonel'),
('projects', 1, 'Projelerimiz | Neys Grup İnşaat', 'Devam eden ve tamamlanan projelerimiz.', 'projeler, inşaat projeleri', 'Projelerimiz', 'İnşaat projelerimiz'),
('projects', 2, 'Projects | Neys Grup Construction', 'Our ongoing and completed projects.', 'projects, construction projects', 'Projects', 'Our construction projects'),
('projects', 3, 'Projeyên Me | Neys Grup', 'Projeyên domdar û qediyayî.', 'projey, avahîkariyê', 'Projeyên Me', 'Projeyên me'),
('contact', 1, 'İletişim | Neys Grup İnşaat', 'Bizimle iletişime geçin.', 'iletişim, telefon, adres', 'İletişim', 'Bize ulaşın'),
('contact', 2, 'Contact | Neys Grup Construction', 'Get in touch with us.', 'contact, phone, address', 'Contact', 'Contact us'),
('contact', 3, 'Têkilî | Neys Grup', 'Bi me re têkilî daynin.', 'têkilî, telefon', 'Têkilî', 'Bi me re têkilî');
