<?php
/**
 * Site Header - Sticky navigation
 */
$languages = get_active_languages($pdo);
$logoSrc = asset_url($settings['logo'] ?? 'assets/images/logo-placeholder.svg');
?>
<!-- Top Bar -->
<div class="top-bar d-none d-lg-block">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-md-8">
                <ul class="top-bar-info list-unstyled mb-0 d-flex gap-4">
                    <li><i class="bi bi-telephone"></i> <a href="tel:<?= e(preg_replace('/[^0-9+]/', '', $settings['phone'] ?? '')) ?>"><?= e($settings['phone'] ?? '') ?></a></li>
                    <li><i class="bi bi-envelope"></i> <a href="mailto:<?= e($settings['email'] ?? '') ?>"><?= e($settings['email'] ?? '') ?></a></li>
                    <li><i class="bi bi-geo-alt"></i> <?= e($settings['address'] ?? '') ?></li>
                </ul>
            </div>
            <div class="col-md-4 text-end">
                <div class="top-bar-actions d-flex justify-content-end align-items-center gap-3">
                    <!-- Dil Seçici -->
                    <div class="lang-selector dropdown">
                        <button class="btn btn-sm btn-lang dropdown-toggle" type="button" data-bs-toggle="dropdown">
                            <?php foreach ($languages as $l): if ($l['code'] === $currentLang): ?>
                                <?= e($l['flag']) ?> <?= e($l['native_name']) ?>
                            <?php endif; endforeach; ?>
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <?php foreach ($languages as $l): ?>
                            <li><a class="dropdown-item <?= $l['code'] === $currentLang ? 'active' : '' ?>" href="<?= e(lang_url($l['code'])) ?>"><?= e($l['flag']) ?> <?= e($l['native_name']) ?></a></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                    <!-- Tema Toggle -->
                    <button class="btn btn-sm btn-theme-toggle" id="themeToggle" aria-label="Tema değiştir">
                        <i class="bi bi-moon-fill theme-icon-dark"></i>
                        <i class="bi bi-sun-fill theme-icon-light d-none"></i>
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Main Header -->
<header class="site-header sticky-top" id="siteHeader">
    <nav class="navbar navbar-expand-lg">
        <div class="container">
            <!-- Logo -->
            <a class="navbar-brand" href="<?= site_url() ?>">
                <img src="<?= e($logoSrc) ?>" alt="<?= e($settings['site_name'] ?? 'Neys Grup İnşaat') ?>" class="logo-img" height="50">
            </a>

            <!-- Mobile Actions -->
            <div class="d-flex d-lg-none align-items-center gap-2 ms-auto me-2">
                <button class="btn btn-sm btn-theme-toggle" id="themeToggleMobile" aria-label="Tema">
                    <i class="bi bi-moon-fill"></i>
                </button>
                <div class="dropdown">
                    <button class="btn btn-sm btn-lang dropdown-toggle" data-bs-toggle="dropdown">
                        <?php foreach ($languages as $l): if ($l['code'] === $currentLang): echo e($l['flag']); endif; endforeach; ?>
                    </button>
                    <ul class="dropdown-menu dropdown-menu-end">
                        <?php foreach ($languages as $l): ?>
                        <li><a class="dropdown-item" href="<?= e(lang_url($l['code'])) ?>"><?= e($l['flag']) ?> <?= e($l['native_name']) ?></a></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            </div>

            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNav" aria-controls="mainNav" aria-expanded="false" aria-label="Menü">
                <span class="navbar-toggler-icon"></span>
            </button>

            <!-- Navigation -->
            <div class="collapse navbar-collapse" id="mainNav">
                <ul class="navbar-nav ms-auto align-items-lg-center">
                    <li class="nav-item">
                        <a class="nav-link <?= is_active_page('home') ? 'active' : '' ?>" href="<?= site_url() ?>"><?= e(__('nav_home')) ?></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?= is_active_page('about') ? 'active' : '' ?>" href="<?= site_url($currentLang === 'en' ? 'about' : ($currentLang === 'ku' ? 'derbare-me' : 'hakkimizda')) ?>"><?= e(__('nav_about')) ?></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?= is_active_page('services') ? 'active' : '' ?>" href="<?= site_url($currentLang === 'en' ? 'services' : ($currentLang === 'ku' ? 'xizmeten' : 'hizmetler')) ?>"><?= e(__('nav_services')) ?></a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle <?= in_array($currentPage, ['projects','projects_ongoing','projects_completed','project_detail']) ? 'active' : '' ?>" href="#" role="button" data-bs-toggle="dropdown"><?= e(__('nav_projects')) ?></a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="<?= site_url($currentLang === 'en' ? 'projects/ongoing' : ($currentLang === 'ku' ? 'projeyen/domdar' : 'projeler/devam-eden')) ?>"><?= e(__('nav_ongoing')) ?></a></li>
                            <li><a class="dropdown-item" href="<?= site_url($currentLang === 'en' ? 'projects/completed' : ($currentLang === 'ku' ? 'projeyen/qediyayi' : 'projeler/tamamlanan')) ?>"><?= e(__('nav_completed')) ?></a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="<?= site_url($currentLang === 'en' ? 'projects' : ($currentLang === 'ku' ? 'projeyen' : 'projeler')) ?>"><?= e(__('btn_all_projects')) ?></a></li>
                        </ul>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?= is_active_page('contact') ? 'active' : '' ?>" href="<?= site_url($currentLang === 'en' ? 'contact' : ($currentLang === 'ku' ? 'tekili' : 'iletisim')) ?>"><?= e(__('nav_contact')) ?></a>
                    </li>
                    <li class="nav-item d-none d-lg-block ms-2">
                        <form class="header-search" action="<?= site_url($currentLang === 'en' ? 'search' : ($currentLang === 'ku' ? 'gere' : 'arama')) ?>" method="GET">
                            <div class="input-group input-group-sm">
                                <input type="text" name="q" class="form-control" placeholder="<?= e(__('search_placeholder')) ?>" value="<?= e(get_param('q', '')) ?>">
                                <button class="btn btn-primary" type="submit"><i class="bi bi-search"></i></button>
                            </div>
                        </form>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
</header>

<main id="mainContent">
