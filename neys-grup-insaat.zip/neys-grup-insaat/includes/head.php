<?php
/**
 * HTML Head - Meta, SEO, CSS
 */
$pageTitle = $seo['meta_title'] ?? ($settings['site_name'] ?? 'Neys Grup İnşaat');
$pageDesc  = $seo['meta_description'] ?? ($settings['site_tagline'] ?? '');
$pageKeys  = $seo['meta_keywords'] ?? '';
$ogTitle   = $seo['og_title'] ?? $pageTitle;
$ogDesc    = $seo['og_description'] ?? $pageDesc;
$ogImage   = $seo['og_image'] ?? asset_url($settings['logo'] ?? 'assets/images/logo-placeholder.svg');
$canonical = $seo['canonical_url'] ?? site_url($currentPage === 'home' ? '' : ($pageSlug ?: $currentPage));
?>
<!DOCTYPE html>
<html lang="<?= e($currentLang) ?>" data-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <title><?= e($pageTitle) ?></title>
    <meta name="description" content="<?= e($pageDesc) ?>">
    <?php if ($pageKeys): ?><meta name="keywords" content="<?= e($pageKeys) ?>"><?php endif; ?>
    <meta name="author" content="Neys Grup İnşaat">
    <meta name="robots" content="index, follow">
    <link rel="canonical" href="<?= e($canonical) ?>">

    <!-- Open Graph -->
    <meta property="og:type" content="website">
    <meta property="og:title" content="<?= e($ogTitle) ?>">
    <meta property="og:description" content="<?= e($ogDesc) ?>">
    <meta property="og:image" content="<?= e($ogImage) ?>">
    <meta property="og:url" content="<?= e($canonical) ?>">
    <meta property="og:locale" content="<?= $currentLang === 'tr' ? 'tr_TR' : ($currentLang === 'ku' ? 'ku_TR' : 'en_US') ?>">

    <!-- Twitter Card -->
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="<?= e($ogTitle) ?>">
    <meta name="twitter:description" content="<?= e($ogDesc) ?>">
    <meta name="twitter:image" content="<?= e($ogImage) ?>">

    <!-- Favicon -->
    <link rel="icon" type="image/svg+xml" href="<?= asset_url($settings['favicon'] ?? 'assets/images/favicon.svg') ?>">

    <!-- Bootstrap 5 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <!-- AOS Animation -->
    <link href="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.css" rel="stylesheet">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="<?= asset_url('assets/css/style.css') ?>?v=1.0">
    <link rel="stylesheet" href="<?= asset_url('assets/css/dark.css') ?>?v=1.0">

    <?php if (!empty($settings['google_analytics'])): ?>
    <!-- Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=<?= e($settings['google_analytics']) ?>"></script>
    <script>window.dataLayer=window.dataLayer||[];function gtag(){dataLayer.push(arguments);}gtag('js',new Date());gtag('config','<?= e($settings['google_analytics']) ?>');</script>
    <?php endif; ?>

    <?= schema_organization() ?>
</head>
<body>

<!-- Preloader -->
<div id="preloader">
    <div class="preloader-inner">
        <div class="preloader-spinner"></div>
        <span><?= e(__('loading')) ?></span>
    </div>
</div>
