</main>

<!-- Footer -->
<footer class="site-footer">
    <div class="footer-top">
        <div class="container">
            <div class="row g-4">
                <div class="col-lg-4 col-md-6">
                    <div class="footer-brand">
                        <img src="<?= asset_url($settings['logo'] ?? 'assets/images/logo-placeholder.svg') ?>" alt="<?= e($settings['site_name'] ?? '') ?>" height="45" class="mb-3">
                        <p><?= e($settings['footer_text'] ?? '') ?></p>
                        <div class="social-links">
                            <?php if (!empty($settings['facebook'])): ?><a href="<?= e($settings['facebook']) ?>" target="_blank" rel="noopener"><i class="bi bi-facebook"></i></a><?php endif; ?>
                            <?php if (!empty($settings['instagram'])): ?><a href="<?= e($settings['instagram']) ?>" target="_blank" rel="noopener"><i class="bi bi-instagram"></i></a><?php endif; ?>
                            <?php if (!empty($settings['linkedin'])): ?><a href="<?= e($settings['linkedin']) ?>" target="_blank" rel="noopener"><i class="bi bi-linkedin"></i></a><?php endif; ?>
                            <?php if (!empty($settings['youtube'])): ?><a href="<?= e($settings['youtube']) ?>" target="_blank" rel="noopener"><i class="bi bi-youtube"></i></a><?php endif; ?>
                            <?php if (!empty($settings['twitter'])): ?><a href="<?= e($settings['twitter']) ?>" target="_blank" rel="noopener"><i class="bi bi-twitter-x"></i></a><?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="col-lg-2 col-md-6">
                    <h5><?= e(__('footer_quick_links')) ?></h5>
                    <ul class="footer-links">
                        <li><a href="<?= site_url() ?>"><?= e(__('nav_home')) ?></a></li>
                        <li><a href="<?= site_url($currentLang === 'en' ? 'about' : ($currentLang === 'ku' ? 'derbare-me' : 'hakkimizda')) ?>"><?= e(__('nav_about')) ?></a></li>
                        <li><a href="<?= site_url($currentLang === 'en' ? 'services' : ($currentLang === 'ku' ? 'xizmeten' : 'hizmetler')) ?>"><?= e(__('nav_services')) ?></a></li>
                        <li><a href="<?= site_url($currentLang === 'en' ? 'projects' : ($currentLang === 'ku' ? 'projeyen' : 'projeler')) ?>"><?= e(__('nav_projects')) ?></a></li>
                        <li><a href="<?= site_url($currentLang === 'en' ? 'contact' : ($currentLang === 'ku' ? 'tekili' : 'iletisim')) ?>"><?= e(__('nav_contact')) ?></a></li>
                    </ul>
                </div>
                <div class="col-lg-3 col-md-6">
                    <h5><?= e(__('footer_contact')) ?></h5>
                    <ul class="footer-contact">
                        <li><i class="bi bi-telephone"></i> <?= e($settings['phone'] ?? '') ?></li>
                        <li><i class="bi bi-envelope"></i> <?= e($settings['email'] ?? '') ?></li>
                        <li><i class="bi bi-geo-alt"></i> <?= e($settings['address'] ?? '') ?></li>
                        <li><i class="bi bi-clock"></i> <?= e($settings['working_hours'] ?? '') ?></li>
                    </ul>
                </div>
                <div class="col-lg-3 col-md-6">
                    <h5><?= e(__('footer_follow_us')) ?></h5>
                    <p class="text-muted-sm"><?= e($settings['site_tagline'] ?? '') ?></p>
                    <ul class="footer-links">
                        <li><a href="<?= site_url($currentLang === 'en' ? 'privacy-policy' : ($currentLang === 'ku' ? 'politika-nepenitiye' : 'gizlilik-politikasi')) ?>"><?= $currentLang === 'en' ? 'Privacy Policy' : ($currentLang === 'ku' ? 'Polîtîkaya Nepenîtiyê' : 'Gizlilik Politikası') ?></a></li>
                        <li><a href="<?= site_url($currentLang === 'en' ? 'cookie-policy' : ($currentLang === 'ku' ? 'politika-cookie' : 'cerez-politikasi')) ?>"><?= $currentLang === 'en' ? 'Cookie Policy' : ($currentLang === 'ku' ? 'Polîtîkaya Cookie' : 'Çerez Politikası') ?></a></li>
                        <li><a href="<?= site_url($currentLang === 'en' ? 'gdpr' : ($currentLang === 'ku' ? 'kvkk-ku' : 'kvkk')) ?>">KVKK</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="footer-bottom">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-6">
                    <p class="mb-0"><?= e(__('footer_copyright')) ?></p>
                </div>
                <div class="col-md-6 text-md-end">
                    <p class="mb-0"><?= e($settings['site_name'] ?? 'Neys Grup İnşaat') ?></p>
                </div>
            </div>
        </div>
    </div>
</footer>

<!-- WhatsApp Button -->
<?php if (!empty($settings['whatsapp'])): ?>
<a href="https://wa.me/<?= e($settings['whatsapp']) ?>" class="whatsapp-float" target="_blank" rel="noopener" aria-label="WhatsApp">
    <i class="bi bi-whatsapp"></i>
</a>
<?php endif; ?>

<!-- Back to Top -->
<button class="back-to-top" id="backToTop" aria-label="<?= e(__('back_to_top')) ?>">
    <i class="bi bi-arrow-up"></i>
</button>

<!-- Cookie Notice -->
<?php if (($settings['cookie_notice'] ?? '1') === '1'): ?>
<div class="cookie-notice" id="cookieNotice">
    <div class="cookie-content">
        <h6><?= e(__('cookie_title')) ?></h6>
        <p><?= e(__('cookie_text')) ?></p>
        <div class="cookie-actions">
            <button class="btn btn-primary btn-sm" id="cookieAccept"><?= e(__('cookie_accept')) ?></button>
            <button class="btn btn-outline-secondary btn-sm" id="cookieDecline"><?= e(__('cookie_decline')) ?></button>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- Scripts -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.js"></script>
<script src="<?= asset_url('assets/js/main.js') ?>?v=1.0"></script>
</body>
</html>
