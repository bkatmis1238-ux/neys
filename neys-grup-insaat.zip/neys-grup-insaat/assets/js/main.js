/**
 * Neys Grup İnşaat - Ana JavaScript
 */

document.addEventListener('DOMContentLoaded', function () {
    initPreloader();
    initTheme();
    initAOS();
    initHeader();
    initBackToTop();
    initCookieNotice();
    initCounters();
    initLazyLoad();
});

/** Preloader */
function initPreloader() {
    const preloader = document.getElementById('preloader');
    if (!preloader) return;
    window.addEventListener('load', function () {
        setTimeout(function () {
            preloader.classList.add('hidden');
            setTimeout(function () { preloader.remove(); }, 500);
        }, 500);
    });
}

/** Dark/Light Mode */
function initTheme() {
    const saved = localStorage.getItem('neys_theme') || 'light';
    document.documentElement.setAttribute('data-theme', saved);
    updateThemeIcons(saved);

    function toggleTheme() {
        const current = document.documentElement.getAttribute('data-theme');
        const next = current === 'dark' ? 'light' : 'dark';
        document.documentElement.setAttribute('data-theme', next);
        localStorage.setItem('neys_theme', next);
        updateThemeIcons(next);
    }

    document.getElementById('themeToggle')?.addEventListener('click', toggleTheme);
    document.getElementById('themeToggleMobile')?.addEventListener('click', toggleTheme);
}

function updateThemeIcons(theme) {
    document.querySelectorAll('.theme-icon-dark, .theme-icon-light').forEach(function (el) {
        if (el.classList.contains('theme-icon-dark')) {
            el.classList.toggle('d-none', theme === 'dark');
        }
        if (el.classList.contains('theme-icon-light')) {
            el.classList.toggle('d-none', theme === 'light');
        }
    });
    document.querySelectorAll('#themeToggleMobile i, .btn-theme-toggle i').forEach(function (icon) {
        if (icon.classList.contains('theme-icon-dark') || icon.classList.contains('theme-icon-light')) return;
        icon.className = theme === 'dark' ? 'bi bi-sun-fill' : 'bi bi-moon-fill';
    });
}

/** AOS Animasyon */
function initAOS() {
    if (typeof AOS !== 'undefined') {
        AOS.init({ duration: 800, easing: 'ease-out-cubic', once: true, offset: 50 });
    }
}

/** Sticky Header Scroll Efekti */
function initHeader() {
    const header = document.getElementById('siteHeader');
    if (!header) return;
    window.addEventListener('scroll', function () {
        header.classList.toggle('scrolled', window.scrollY > 50);
    });
}

/** Back to Top */
function initBackToTop() {
    const btn = document.getElementById('backToTop');
    if (!btn) return;
    window.addEventListener('scroll', function () {
        btn.classList.toggle('visible', window.scrollY > 400);
    });
    btn.addEventListener('click', function () {
        window.scrollTo({ top: 0, behavior: 'smooth' });
    });
}

/** Cookie Bildirimi */
function initCookieNotice() {
    const notice = document.getElementById('cookieNotice');
    if (!notice) return;
    if (!localStorage.getItem('neys_cookie')) {
        setTimeout(function () { notice.classList.add('show'); }, 1500);
    }
    document.getElementById('cookieAccept')?.addEventListener('click', function () {
        localStorage.setItem('neys_cookie', 'accepted');
        notice.classList.remove('show');
    });
    document.getElementById('cookieDecline')?.addEventListener('click', function () {
        localStorage.setItem('neys_cookie', 'declined');
        notice.classList.remove('show');
    });
}

/** Sayaç Animasyonu */
function initCounters() {
    const counters = document.querySelectorAll('[data-count]');
    if (!counters.length) return;

    const observer = new IntersectionObserver(function (entries) {
        entries.forEach(function (entry) {
            if (entry.isIntersecting) {
                animateCounter(entry.target);
                observer.unobserve(entry.target);
            }
        });
    }, { threshold: 0.5 });

    counters.forEach(function (c) { observer.observe(c); });
}

function animateCounter(el) {
    const target = parseInt(el.getAttribute('data-count'), 10);
    const duration = 2000;
    const start = performance.now();

    function update(now) {
        const progress = Math.min((now - start) / duration, 1);
        const eased = 1 - Math.pow(1 - progress, 3);
        el.textContent = Math.floor(eased * target).toLocaleString('tr-TR');
        if (progress < 1) requestAnimationFrame(update);
    }
    requestAnimationFrame(update);
}

/** Lazy Loading */
function initLazyLoad() {
    if ('loading' in HTMLImageElement.prototype) return;
    const images = document.querySelectorAll('img[loading="lazy"]');
    const observer = new IntersectionObserver(function (entries) {
        entries.forEach(function (entry) {
            if (entry.isIntersecting) {
                const img = entry.target;
                if (img.dataset.src) { img.src = img.dataset.src; }
                observer.unobserve(img);
            }
        });
    });
    images.forEach(function (img) { observer.observe(img); });
}

/** Smooth scroll for anchor links */
document.querySelectorAll('a[href^="#"]').forEach(function (anchor) {
    anchor.addEventListener('click', function (e) {
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            e.preventDefault();
            target.scrollIntoView({ behavior: 'smooth' });
        }
    });
});
