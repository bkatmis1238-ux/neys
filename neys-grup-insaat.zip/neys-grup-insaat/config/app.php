<?php
/**
 * Uygulama Genel Ayarları
 */

return [
    'name'           => 'Neys Grup İnşaat',
    'url'            => 'http://localhost/neys-grup-insaat',
    'timezone'       => 'Europe/Istanbul',
    'default_lang'   => 'tr',
    'supported_langs'=> ['tr', 'en', 'ku'],
    'upload_path'    => __DIR__ . '/../assets/uploads/',
    'upload_url'     => 'assets/uploads/',
    'max_upload'     => 5 * 1024 * 1024, // 5MB
    'allowed_images' => ['jpg', 'jpeg', 'png', 'gif', 'webp', 'svg'],
    'allowed_docs'   => ['pdf'],
    'session_name'   => 'NEYS_SESSION',
    'admin_prefix'   => 'admin',
    'items_per_page' => 12,
    'cache_enabled'  => true,
    'cache_ttl'      => 3600,
    'mail_from'      => 'noreply@neysgrupinsaat.com',
    'mail_from_name' => 'Neys Grup İnşaat',
];
