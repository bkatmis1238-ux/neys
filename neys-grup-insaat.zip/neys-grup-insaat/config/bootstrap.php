<?php
/**
 * Bootstrap - Tüm sayfalar için başlangıç dosyası
 */

declare(strict_types=1);

// Hata raporlama (production'da kapatın)
error_reporting(E_ALL);
ini_set('display_errors', '0');
ini_set('log_errors', '1');

// Oturum başlat
if (session_status() === PHP_SESSION_NONE) {
    session_name('NEYS_SESSION');
    session_start();
}

// Temel sabitler
define('ROOT_PATH', dirname(__DIR__));
define('CONFIG_PATH', ROOT_PATH . '/config');
define('INCLUDES_PATH', ROOT_PATH . '/includes');
define('FUNCTIONS_PATH', ROOT_PATH . '/functions');
define('PAGES_PATH', ROOT_PATH . '/pages');
define('ADMIN_PATH', ROOT_PATH . '/admin');
define('ASSETS_PATH', ROOT_PATH . '/assets');
define('UPLOAD_PATH', ROOT_PATH . '/assets/uploads');

// Yapılandırma dosyalarını yükle
$appConfig = require CONFIG_PATH . '/app.php';
$dbConfig  = require CONFIG_PATH . '/database.php';

// Zaman dilimi
date_default_timezone_set($appConfig['timezone']);

// Fonksiyon dosyalarını yükle
require_once FUNCTIONS_PATH . '/database.php';
require_once FUNCTIONS_PATH . '/security.php';
require_once FUNCTIONS_PATH . '/helpers.php';
require_once FUNCTIONS_PATH . '/i18n.php';
require_once FUNCTIONS_PATH . '/settings.php';

// Veritabanı bağlantısı
try {
    $pdo = db_connect($dbConfig);
} catch (PDOException $e) {
    die('Veritabanı bağlantı hatası. Lütfen config/database.php dosyasını kontrol edin.');
}

// Site ayarlarını yükle
$settings = load_settings($pdo);

// Dil tespiti ve yükleme
$currentLang = detect_language($appConfig);
$langId      = get_language_id($pdo, $currentLang);
$translations = load_translations($pdo, $langId);

// CSRF token oluştur
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// Bakım modu kontrolü (admin hariç)
$isAdminRoute = strpos($_SERVER['REQUEST_URI'] ?? '', '/admin') !== false;
if (($settings['maintenance_mode'] ?? '0') === '1' && !$isAdminRoute && !is_admin_logged_in()) {
    http_response_code(503);
    require PAGES_PATH . '/maintenance.php';
    exit;
}
