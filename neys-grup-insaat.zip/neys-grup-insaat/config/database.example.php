<?php
/**
 * Veritabanı Bağlantı Ayarları - Örnek
 * Bu dosyayı database.php olarak kopyalayın ve bilgilerinizi girin
 */

return [
    'host'     => 'localhost',
    'dbname'   => 'neys_grup_insaat',
    'username' => 'DB_KULLANICI',
    'password' => 'DB_SIFRE',
    'charset'  => 'utf8mb4',
    'options'  => [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ],
];
