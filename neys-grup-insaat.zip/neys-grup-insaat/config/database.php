<?php
/**
 * Veritabanı Bağlantı Ayarları
 * NATRO hosting için bu dosyayı düzenleyin
 */

return [
    'host'     => 'localhost',
    'dbname'   => 'neys_grup_insaat',
    'username' => 'root',
    'password' => '',
    'charset'  => 'utf8mb4',
    'options'  => [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ],
];
