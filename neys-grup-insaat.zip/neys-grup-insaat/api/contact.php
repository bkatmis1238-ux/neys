<?php
/**
 * İletişim Formu API
 */
require_once dirname(__DIR__) . '/config/bootstrap.php';

if (!is_post()) {
    redirect(site_url($currentLang === 'en' ? 'contact' : ($currentLang === 'ku' ? 'tekili' : 'iletisim')));
}

// Güvenlik kontrolleri
if (!verify_csrf(post_param('csrf_token'))) {
    set_flash('error', __('form_error'));
    redirect(site_url($currentLang === 'en' ? 'contact' : ($currentLang === 'ku' ? 'tekili' : 'iletisim')));
}

if (is_honeypot_triggered()) {
    redirect(site_url());
}

if (!check_rate_limit('contact_form', 3, 600)) {
    set_flash('error', __('form_error'));
    redirect(site_url($currentLang === 'en' ? 'contact' : ($currentLang === 'ku' ? 'tekili' : 'iletisim')));
}

$name    = post_param('name');
$email   = post_param('email');
$phone   = post_param('phone');
$subject = post_param('subject');
$message = post_param('message');

if (empty($name) || empty($email) || empty($message) || !is_valid_email($email)) {
    set_flash('error', __('form_error'));
    redirect(site_url($currentLang === 'en' ? 'contact' : ($currentLang === 'ku' ? 'tekili' : 'iletisim')));
}

// Veritabanına kaydet
db_execute($pdo,
    'INSERT INTO messages (name, email, phone, subject, message, ip_address) VALUES (?, ?, ?, ?, ?, ?)',
    [$name, $email, $phone, $subject, $message, $_SERVER['REMOTE_ADDR'] ?? '']
);

// E-posta gönder
$to = $settings['email'] ?? 'info@neysgrupinsaat.com';
$mailSubject = '[Neys Grup İnşaat] ' . ($subject ?: 'İletişim Formu');
$mailBody = "Ad: $name\nE-posta: $email\nTelefon: $phone\nKonu: $subject\n\nMesaj:\n$message";
$headers = "From: {$appConfig['mail_from']}\r\nReply-To: $email\r\nContent-Type: text/plain; charset=UTF-8";

@mail($to, $mailSubject, $mailBody, $headers);

set_flash('success', __('form_success'));
redirect(site_url($currentLang === 'en' ? 'contact' : ($currentLang === 'ku' ? 'tekili' : 'iletisim')));
